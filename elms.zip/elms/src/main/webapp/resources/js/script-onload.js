$(function () {
    
    var drawCharts = function (finalPushArray){
        $('#expatriateDashboardChart').highcharts({
        chart: {
            type: 'column'
        },
        title: {
            text: 'Month wise Report'
        },
        xAxis: {
            categories: ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
        },
        yAxis: {
            min: 0,
            stackLabels: {
                enabled: true,
                style: {
                    fontWeight: 'bold',
                    color: (Highcharts.theme && Highcharts.theme.textColor) || 'gray'
                }
            },
            title: {
                enabled: true,
                text: 'Leaves/Trips Count',
                style: {
                    fontWeight: 'bold'
                }
            }
        },legend: {
                align: 'center',
                verticalAlign: 'bottom',
                x: 0,
                y: 10
            },
        tooltip: {
            headerFormat: '<b>{point.key}</b><br>',
            pointFormat: '<span style="color:{series.color}">\u25CF</span> {series.name}: {point.y} / {point.stackTotal}'
        },
        plotOptions: {
            column: {
                stacking: 'normal',
                /*dataLabels: {enabled: true,color:  'white',style: {textShadow: '0 0 3px black'}}*/
            }
        },
        series: finalPushArray
            
        });
    };
    var checkifless = function (number){
        var fullnumber = number;
        if(number < 10){
            fullnumber = "0"+number;
        }
        return fullnumber;
    };
    var validateAndCountDaysPerMonth = function (dateFrom,dateTo){
        var fromDtSplit = dateFrom.split("-");
        var toDtSplit = dateTo.split("-");
        var fromDt = new Date(fromDtSplit[0],fromDtSplit[1]-1,fromDtSplit[2],0,0,0,1);
        var toDt = new Date(toDtSplit[0],toDtSplit[1]-1,toDtSplit[2],23,59,59,999);
        var dateCount = (toDt - fromDt)/(86400*1000);
        var counts = 0;
        var monthsArray = [[],[],[],[],[],[],[],[],[],[],[],[]];
        if(fromDtSplit[1] === toDtSplit[1]){
            fromDt = new Date(fromDtSplit[0],fromDtSplit[1]-1,fromDtSplit[2],0,0,0,1);
            toDt = new Date(toDtSplit[0],toDtSplit[1]-1,toDtSplit[2],23,59,59,999);
            for(var i = 0; i< dateCount;i++){
                var dateNowCurrentIteration = fromDt.getFullYear()+"-"+checkifless((fromDt.getMonth()+1))+"-"+checkifless(fromDt.getDate());
                var getDay = fromDt.getDay();
                if(getDay !== 0 && getDay !== 6 && $.inArray(dateNowCurrentIteration,holidaysArray) === -1){
                    counts = counts + 1;
                }
                fromDt.setDate(fromDt.getDate()+1);
            }
            monthsArray[parseInt(fromDtSplit[1])-1].push(counts);
        }else{
            fromDt = new Date(fromDtSplit[0],fromDtSplit[1]-1,fromDtSplit[2],0,0,0,1);
            toDt = new Date(toDtSplit[0],toDtSplit[1]-1,toDtSplit[2],23,59,59,999);
            var datesCountElseCase = 0;var currentMonth = -1;var iterationMonths = 0;
            for(var j = 0 ; j< dateCount; j++){
                var dateNowCurrentIteration = fromDt.getFullYear()+"-"+checkifless((fromDt.getMonth()+1))+"-"+checkifless(fromDt.getDate());                
                if(currentMonth === fromDt.getMonth()){
                    var getDay = fromDt.getDay();
                    if(getDay !== 0 && getDay !== 6 && $.inArray(dateNowCurrentIteration,holidaysArray) === -1){
                        datesCountElseCase = datesCountElseCase +1;
                        monthsArray[iterationMonths-1][0] = datesCountElseCase;
                    }
                    fromDt.setDate(fromDt.getDate()+1);
                }else{
                    iterationMonths = iterationMonths +1;
                    datesCountElseCase = 0;
                    currentMonth = fromDt.getMonth();
                    var getDay = fromDt.getDay();
                    if(getDay !== 0 && getDay !== 6 && $.inArray(dateNowCurrentIteration,holidaysArray) === -1){
                        monthsArray[iterationMonths-1].push(datesCountElseCase++);
                    }else{
                        monthsArray[iterationMonths-1].push(datesCountElseCase);
                    }
                    fromDt.setDate(fromDt.getDate()+1);
                }
            }
        }
        return monthsArray;
    };
    var createExpatriateCharts = function (){
        var LeaveTypesArray = [];var finalPushArray = [];
        $(".getIds").each(function (){
            LeaveTypesArray.push($(this).attr("data-id"));
            finalPushArray.push({color:$(this).attr("data-color"),name: $(this).find(".type-name").text(),data: [0,0,0,0,0,0,0,0,0,0,0,0]});
        });
        $.get("getExpatriatesChartDashboard",function (data,status){
            var getLength = data.length;
            for(var i =0; i< getLength; i++){
                var holderArray = validateAndCountDaysPerMonth(data[i][0],data[i][1]);
                var inarrayCheck = $.inArray(data[i][4],LeaveTypesArray);
                finalPushArray[inarrayCheck].color = data[i][3];
                finalPushArray[inarrayCheck].name = data[i][2];
                for(var j =0 ; j < finalPushArray[inarrayCheck].data.length;j++){
                    if(holderArray[j].length !== 0){
                        finalPushArray[inarrayCheck].data[j] = finalPushArray[inarrayCheck].data[j]+holderArray[j][0];
                    }
                }
            }
            drawCharts(finalPushArray);
        });
        
        
    };
    var drawPiechart = function (data){
        $('#serviceConsumeChart').highcharts({
            colors:["#90ed7d","#7cb5ec","#d44660"],
             chart: {
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: true,
                type: 'pie'
            },
            title: {
                text: ''
            },
            tooltip: {
                pointFormat: '{point.name} {point.y} days(<b>{point.percentage:.0f}%</b>)'
            },
            legend: {
                align: 'center',
                verticalAlign: 'bottom',
                x: 0,
                y: 10
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    dataLabels: {
                        enabled: false
                    },
                    showInLegend: true
                }
            },
            series: [{
                colorByPoint: true,
                data: data
            }]
        });
    };
    var generateDataForPie = function (){
        var fromDtSplit = $("#startDateHidden").val().split("-");
        var toDtSplit = $("#endDateHidden").val().split("-");
        var fromDt = new Date(fromDtSplit[0],fromDtSplit[1]-1,fromDtSplit[2],0,0,0,1);
        var toDt = new Date(toDtSplit[0],toDtSplit[1]-1,toDtSplit[2],23,59,59,999);
        var dateCount = (toDt - fromDt)/(86400*1000);
        var today = new Date();today.setHours(0);today.setMinutes(0),today.setSeconds(1);
        var dateWorked = Math.floor((today - fromDt)/(86400*1000));
        var datesBalance = Math.ceil(dateCount-dateWorked);
        var datesOnLeave = parseInt($(".percentageCalculator").eq(0).attr("data-total"));
        var dataParam = [];
        var workeds = {name:'Worked',y:dateWorked};
        var balances = {name:'Balance',y:datesBalance};
        dataParam.push(workeds);
        dataParam.push(balances);
        $("#ApplyLeaveColumn .info-box").each(function (ind,inx){
            var key = $(this).find(".type-name").text();
            var value = parseInt($(this).find(".calc").text());
            var color = $(this).attr("data-color");
			if(value !== 0){
				var arrays  = {color:color,name:key,y:value};
			}
            dataParam.push(arrays);
        });
        drawPiechart(dataParam);
        //var dataParam = [['Worked',dateWorked],['Balance',datesBalance],['On Leave',datesOnLeave]];
        
    };
    if($(".isexpatDashboard").text() === "1"){
        createExpatriateCharts();
        generateDataForPie();
        
    }
    var drawChartsAdminDashboardChart2 = function (data1){
        $('#AdminLeaveTypesCharts').highcharts({
            colors:["#4389bc","#d44660","#f4e834","#00d1e7","#ca8ad7","#5ad379","#ff6cd9"],
            chart: {
                type: 'column'
            },
            title: {
                text: $("#AdminLeaveTypesCharts").attr("data-title")
            },xAxis: {
                categories: ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
            },
            yAxis: {
                allowDecimals: false,
                min: 0,
                stackLabels: {
                    enabled: true,
                    style: {
                        fontWeight: 'bold',
                        color: (Highcharts.theme && Highcharts.theme.textColor) || 'gray'
                    }
                },
                title: {
                    enabled: true,
                    text: 'Future Leave Counts',
                    style: {
                        fontWeight: 'bold'
                    }
                }
            },
            tooltip: {
                formatter: function () {
                    return '<b>' + this.x + '</b><br/>' +
                        this.series.name + ': ' + this.y + '<br/>' +
                        'Total: ' + this.point.stackTotal;
                }
            },
            legend: {
                align: 'center',
                verticalAlign: 'bottom',
                x: 0,
                y: 10
            },
            plotOptions: {
                column: {
                    stacking: 'normal',
                    dataLabels: {
                        enabled: true,
                        formatter:function() {
                            if(this.y !== 0) {
                              return this.y;
                            }
                        }
                    }
                }  
            },
            series: data1
        });
    };
    var drawChartsAdminDashboard = function (data){
        $('#AdminExpatriateChart').highcharts({
            colors:["#4389bc","#d44660","#f4e834","#00d1e7","#ca8ad7","#5ad379","#ff6cd9"],
            chart: {
                type: 'column'
            },
            title: {
                text: $("#AdminExpatriateChart").attr("data-title")
            },
            xAxis: {
                categories: ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
            },
            yAxis: {
                allowDecimals: false,
                min: 0,
                stackLabels: {
                    enabled: true,
                    style: {
                        fontWeight: 'bold',
                        color: (Highcharts.theme && Highcharts.theme.textColor) || 'gray'
                    }
                },
                title: {
                    enabled: true,
                    text: 'Leaves/Trips Count',
                    style: {
                        fontWeight: 'bold'
                    }
                }
            },
            tooltip: {
                formatter: function () {
                    return '<b>' + this.x + '</b><br/>' +
                        this.series.name + ': ' + this.y + '<br/>' +
                        'Total: ' + this.point.stackTotal;
                }
            },
            legend: {
                align: 'center',
                verticalAlign: 'bottom',
                x: 0,
                y: 10
            },
            plotOptions: {
                column: {
                    stacking: 'normal',
                    dataLabels: {
                        enabled: true,
                        formatter:function() {
                            if(this.y !== 0) {
                              return this.y;
                            }
                        }
                    }
                }  
            },
            series: data
        });
    };
    var getDataForAdminDashboardExpatriates = function (year,monthsCount){
        $.get("getExpatriatesChartAdminDashboard?year="+year+"&months="+monthsCount,function (data,status){
            drawChartsAdminDashboard(data);
        });
    };
    var getDataForAdminDashboardExpatriatesChart2 = function (mc){
        var from,till;
        var dummyFrom = new Date();
        var dummyTo = new Date(dummyFrom.getFullYear(),(dummyFrom.getMonth()),1,0,0,0,1);
        dummyTo.setMonth(dummyTo.getMonth()+12);
        from = new Date(dummyFrom.getFullYear(),(dummyFrom.getMonth()),1,0,0,1);
        till = new Date(dummyTo.getFullYear(),(dummyTo.getMonth()),1,0,0,0,1);
        from = from.getFullYear()+"-"+from.getMonth()+"-1";
        till = till.getFullYear()+"-"+till.getMonth()+"-1";
        $.get("getExpatriatesLeavesChartAdminDashboard?from="+from+"&till="+till+"&mc="+mc,function (data,status){
        	drawChartsAdminDashboardChart2(data);
        });
    };
    $(".changemc").change(function (){
       getDataForAdminDashboardExpatriatesChart2($(this).val());
    });
    
    var generateSelectYear = function (){
        $.get("getMinimumYear",function (data,status){
            var selectString = "<select class='selects selectsGen'>";
            var datenew =  new Date();
            datenew.setHours(0);
            datenew.setMinutes(0);
            datenew.setSeconds(0);
            datenew.setMilliseconds(1);
            var currentYearChart = datenew.getFullYear();
            var deviation = (currentYearChart - data)+1;
            for(var i =0 ; i< deviation;i++){
                selectString += "<option value='"+(currentYearChart-i)+"'>"+(currentYearChart-i)+"</option>";
            }
            selectString += "</select>";
            $(".selectApp").append(selectString);
            $(".selectApp1").append(selectString);
            $(".selectsGen").select2();
            $(".selectApp .selectsGen").on("change",function (){
                var year = $(this).val();
                var monthsCount  = 12;
                if(parseInt(year) === parseInt(currentYearChart)){
                    monthsCount = (datenew.getMonth()+1);
                }
                getDataForAdminDashboardExpatriates(year,monthsCount);
            });
            $(".selectApp select.selectsGen").trigger("change");
        });
    };
    
    if($(".isAdminDash").val() === "adminDash"){
        generateSelectYear();
        if($(".changemc").length){
        	$(".changemc").change();
        }else{
        	getDataForAdminDashboardExpatriatesChart2("none");
        }
        
    }

});    


/**********Expatriate************/
/*chart: {
            type: 'column',
            options3d: {
                enabled: true,
                alpha: 15,
                beta: 15,
                viewDistance: 25,
                depth: 40
            },
            marginTop: 80,
            marginRight: 40
        },

        title: {
            text: 'Month wise Report'
        },

        xAxis: {
            categories: ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
        },

        yAxis: {
            allowDecimals: false,
            min: 0,
            title: {
                text: 'Number of leaves'
            }
        },

        tooltip: {
            headerFormat: '<b>{point.key}</b><br>',
            pointFormat: '<span style="color:{series.color}">\u25CF</span> {series.name}: {point.y} / {point.stackTotal}'
        },

        plotOptions: {
            column: {
                stacking: 'normal',
                depth: 40
            }
        },

        series: finalPushArray*/
/*********************Admin expatriates**********************/
/*data: {
                table: 'table1-Expatriate-count'
            },
            chart: {
                type: "column",
                options3d: {
                    enabled: true,
                    alpha: 15,
                    beta: 15,
                    viewDistance: 25,
                    depth: 40
                },
                marginTop: 80,
                marginRight: 40
            },

            title: {
                text: $("#AdminExpatriateChart").attr("data-title")
            },
            yAxis: {
            allowDecimals: false,
            min: 0,
            title: {
                text: 'Units'
            }
            },
            plotOptions: {
                column: {
                    stacking: 'normal',
                    depth: 40
                }
            },
            series: [{
                 showInLegend: true
            }]*/