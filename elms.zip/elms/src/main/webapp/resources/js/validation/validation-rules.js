$(document).ready(function (){
    $("#LoginForm").validate({
        rules: {
            username:{
                required:true
            },
            password:{
                required:true
            }
        }
    });
    $("#changepasswordform").validate({
        rules: {
            password:{
                required:true
            },
            newpassword:{
                required:true,
                minlength: 7
            },
            confirmpassword:{
                required:true,
                equalTo: "password"
            }
        }
    });
    $("#AddExpatriatesFrorm").validate({
        rules: {
            firstName: {
                required: true
            },
            lastName: {
                required: true
            },
            rnNumber: {
                required: true
            },
            username: {
                required: true
            },
            email: {
                required: true,
                email:true
            },
            mainCategory: {
                required: true
            },
            category: {
                required: true
            },
            designation: {
                required: true
            },
            department: {
                required: true
            },
            assignmentFrom: {
                required: true
            },
            assignmentTo: {
                required: true
            },
            homeCountry: {
                required: true
            },
            approvalManager: {
                required: true
            },
            approvalManagerEmail: {
                required: true,
                email:true
            },
            leaveCount: {
                required: true,
                number:true
            },
            enabled: {
                required: true
            }
        }
    });
    $("#AddHolidayForm").validate({
        rules: {
            holidayName:{
                required:true
            },
            holidayDate:{
                required:true
            },
            status:{
                required:true
            },
            holidayDescription:{
                required:true
            }
        }
    });
    $("#AddLeaveTypesForm").validate({
        rules: {
            category:{
                required:true
            },
            maincategory:{
                required:true
            },
            leavetype:{
                required:true
            },
            maxCount:{
                required:true,
                number:true
            },
            allowedCount:{
                required:true,
                number:true
            },
            allowAfter:{
                required:true
            },
            status:{
                required:true
            },
            leaveDetails:{
                required:true
            },
            color:{
                required:true
            },
            icon:{
                required:true
            }
        }
    });
    $("#addAdminForm").validate({
        rules: {
            username:{
                required:true
            },
            firstName:{
                required:true
            },
            lastName:{
                required:true
            },
            email:{
                required:true,
                email:true
            },
            rnNumber:{
                required:true
            },
            enabled:{
                required:true
            }
        }
    });
    
    $("#addMainCategoryForm").validate({
        rules: {
            mainCategory:{
                required:true
            },
            mainCategoryLocation:{
                required:true
            },
            mainCategoryDetails:{
                required:true
            }
        }
    });
    $("#addSubCategory").validate({
        rules: {
            mainCategory:{
                required:true
            },
            category:{
                required:true
            },
            mainCategoryDetails:{
                required:true
            }
        }
    });
    $("#OJFForm").validate({
        rules: {
            username:{
                required:true,
                email:true
            }
        }
    });
    /************************************************User Module*****************************************/
    $("#applyLeaveForm").validate({
        rules: {
            leaveType:{
                required:true
            },
            leaveFrom:{
                required:true
            },
            leaveTo:{
                required:true
            },
            leaveReason:{
                required:true,
                maxlength:400
            }
        }
    });
    
});
