$(document).ready(function (){
    /*************************************Calculate Percentage***********************************************/
    $(".percentageCalculator").each(function (){
        var getGrandTotal = parseInt($(this).attr("data-total"));
        var valueOfCalculator = parseInt($(this).find(".calc").text());
        var Outputs = 0;
        if(valueOfCalculator === 0){
            Outputs = 0;
        }else{
            Outputs = (valueOfCalculator/getGrandTotal)* 100;
            Outputs = Outputs.toPrecision(4);
        }
        $(this).closest(".info-box-content").find(".progress-bar").attr("style","width:"+Outputs+"%;");
        $(this).closest(".info-box-content").find(".per").text(Outputs);
    });
    
    //$("#messageTo").select2();
    /*************************************Init tooltips***********************************************/
    $('input[rel="txtTooltip"]').tooltip();
    $(".tools").tooltip();
    $(".test").popover("show");
    /*************************************Data tables***********************************************/
    $('#myTable').DataTable();
    $('#myTable1').DataTable();
    $('#myTable2').DataTable();
    $('#myTableTabs').DataTable();
    
    $(".searchmock").keyup(function (){
        $("#myTableInbox_filter input").val($(this).val()).trigger("keyup");
    });
   /*************************************Select2 Box***********************************************/
   $(".selects").select2();
   /*************************************Download as Excel***********************************************/
   /*$(".table2excel").table2excel({
        exclude: ".noExl",
        name: "Report",
        filename: "",
        headerColor:"#4d8ad4",
        nameId : "myTable"
    });*/
    /*************************************Track Input sizes***********************************************/
    var countCheck = function (thisElem){
      if(thisElem.val().length < 400 ){
            thisElem.parent().find(".reducttext").text(400-(thisElem.val().length));
            if(thisElem.val().length > 380){
                thisElem.parent().find(".reducttext").addClass("text-red");
            }else{
                thisElem.parent().find(".reducttext").removeClass("text-red");
            }
        }  
    };
   $(".reducttext-area").keyup(function (){
        countCheck($(this));
   });
   /*************************************Get Current Year***********************************************/
   $(".currentYear").text(new Date().getFullYear());
   /*************************************Apply leave datepickers***********************************************/
   var editLeaveCloneFD = $(".datepicker1").clone();
   var editLeaveCloneTD = $(".datepicker2").clone();
   $(".editLeave").click(function(){
        $.get("editLeave?id="+$(this).attr("data-id"), function(data, status){
            var field = $("#applyleave");
            field.find("input[name='id']").val(data.id);
            field.find("input[name='leaveFrom']").val(data.leaveFrom);
            field.find("input[name='leaveTo']").val(data.leaveTo);
            field.find("input[name='leaveType']").val(data.leaveType);
            field.find("textarea[name='leaveReason']").val(data.leaveReason);
            countCheck($("textarea[name='leaveReason']"));
            $(".datepicker1,.datepicker2").datepicker("remove");
            $("#applyleave").modal("show");
        });
    });
    $("#ApplyLeaveColumn .info-box").click(function (){
        var totals = parseInt($(this).find(".totaltimes").text());
        var availableTimes =  parseInt($(this).find(".availabletimes").text());
        var leaveTotal = parseInt($(".balance-leave").text());
        var isDeduct = parseInt($(this).attr("data-deducts"));
        if(totals === availableTimes && isDeduct !== 4){
            $(".reason-reject").text("Sorry, apply limit for "+$(".type-name").text() +" exceeded!");
            $("#noleaveFound").modal("show");
        }else if(leaveTotal === 0 && isDeduct !== 4){
            $(".reason-reject").text("You have no leave balance available to apply.");
            $("#noleaveFound").modal("show");
        }else{
            $(".append-start-date").html(editLeaveCloneFD);
            $(".append-end-date").html(editLeaveCloneTD);
            var passedValue = $(this).attr("data-id");
            var textvalue = $(this).find(".info-box-text .type-name").text();
            $("#applyleave .apply-leave-type").find("option").removeAttr("selected");
            $("#applyleave .apply-leave-type").val(passedValue);
            $("#applyleave .apply-leave-type").find("option").each(function (){
                if($(this).val() === passedValue){
                    $(this).attr("selected","selected");
                    $(".select2-container.selects.apply-leave-type").find(".select2-choice .select2-chosen").text(textvalue);
                }
            });
            $("#apply-leave-type-id").trigger("change");
            $("#applyleave").modal("show");
        }
    });
    /**************************Leave Type******************************/
    $(".color-box").click(function (){
        $(".color-box").find(".color-box-check").remove();
        $(this).append("<i class='fa fa-check color-box-check'></i>");
        $(".color-hidden").val($(this).attr("data-color"));
    });
    $(".icon-chooser").click(function (){
        var classNameArray = $(this).attr("class").split(" ");
        $(".icon-hidden").val(classNameArray[0]+" "+classNameArray[1]);
        $(".icon-chooser").removeClass("icon-chooser-active");
        $(this).addClass("icon-chooser-active");
    });
    /*******************************************File Upload***********************************************/
    var canvas = new fabric.Canvas('canvas');
    function addimagetocanvas(resImage){
        fabric.Image.fromURL(resImage, function(image) {
            image.set({
              left: 0,
              top: 0,
              width:190,
              height:190
            })
            .scale(1)
            .setCoords();
            canvas.add(image);
        });
    };
    var flagUpload = 0;
    function addImage() {
        if ( this.files && this.files[0] ) {
            var FR = new FileReader();
            FR.onload = function(e) {
                canvas.clear().renderAll();
                addimagetocanvas(e.target.result);
                if(flagUpload !== 1){
                    $(".setimage").tooltip({
                       title:'You can drag , rotate and expand picture.Click here to set picture after alterations or it will be lost!',
                       trigger:'manual'
                    }).tooltip('show');   
                }
                flagUpload = 1;
            };       
            FR.readAsDataURL( this.files[0] );
        }
    };
    $(".fileToBaseEmployee").change(addImage);
    if($(".photostr").val() === "" || $(".photostr").val() === null){
        addimagetocanvas('resources/images/avatar.jpg');
    }else{
        addimagetocanvas($(".photostr").val());
    }
    
    $(".uploadDummy").click(function (){
        $(".fileToBaseEmployee").click();
    });
    $(".setimage").click(function (){
        canvas.deactivateAll().renderAll();
        $(".setimage").tooltip('hide');
    });
    $(".clearinput").click(function (){
        $(".fileToBaseEmployee").val("");
        canvas.clear().renderAll();
        addimagetocanvas('resources/images/avatar.jpg');
    });
    /**************************Holiday******************************/
    $(".delete-verifier").click(function (){
    	var thisbutton = $(this).attr("data-action");
    	$("#deleterecord").find(".actionname").text(thisbutton);
       $("#deleterecord").modal("show");
       $(".delete-confirm").attr("href",$(this).attr("data-url"));
    });
    $(".delete-confirm").click(function (){
        window.location.href = $(this).attr("data-remove");
    });
    $(".datepicker1").datepicker({
        startDate:'500m'
    });
    $(".datepicker3").datepicker({
        
    });
    $(".datepicker2").datepicker({
        startDate:'500m'
    });
    var checkifless = function (number){
        if(number < 10 && number > 0){
            number = "0"+number;
        }
        return number;
    };
    
    var dateFrom = $(".append-start-date .date").clone();
    var dateTo = $(".append-end-date .date").clone();
    
    $("#apply-leave-type-id").change(function (){
        
        $(".append-start-date").html(editLeaveCloneFD);
        $(".append-end-date").html(editLeaveCloneTD);
        
        var chosenDate = $(".apply-leave-from-date").val();
        var chosenArray = $(".apply-leave-from-date").val().split("-");
        
        var newDate = new Date();
        newDate.setFullYear(chosenArray[0]);
        newDate.setMonth(chosenArray[1]-1);
        newDate.setDate(chosenArray[2]);
        
        var startDate = new Date();
        var endDate = $("#endDateHidden").val();
        
        var calendarDate = new Date();calendarDate.setDate(calendarDate.getDate());
        var value = $(this).val();
        var allowAfter = parseInt($(this).find("option[value='"+value+"']").attr("data-allowafter"));
        var allowedCount = parseInt($(this).find("option[value='"+value+"']").attr("data-allowed-count"));
        var allowedcountMock = allowedCount;
        if(allowAfter === 1){
            var mockstart = $("#startDateHidden").val().split("-");
            startDate = new Date(mockstart[0],mockstart[1],mockstart[2],0,0,0,1);
            var calendarDateModifier = mockstart;
            calendarDate.setDate(calendarDateModifier[2]);calendarDate.setMonth(calendarDateModifier[1-1]);calendarDate.setFullYear(calendarDateModifier[0]);
        }
        
        $(".append-start-date .date").remove();
        $(".append-start-date").append(dateFrom);
        $(".datepicker1").datepicker({
            startDate:startDate,
            endDate:endDate,
            daysOfWeekDisabled:[0,6],
            datesDisabled:holidaysArray
            
        });
        if(newDate > calendarDate){
            $(".apply-leave-from-date").val(chosenDate);
            isClicked = 1;
        }else if(newDate <= calendarDate){
            $(".apply-leave-from-date").val(calendarDate.getFullYear()+"-"+checkifless(calendarDate.getMonth()+1)+"-"+checkifless(calendarDate.getDate()));
            isClicked = 1;
        }
        
        $(".datepicker1").datepicker().on("change.dp",function (){
            chosenDate = $(".apply-leave-from-date").val();
            var toDateSetter = $(".apply-leave-from-date").val().split("-");
            var checkToDate = new Date(toDateSetter[0],toDateSetter[1]-1,toDateSetter[2],0,0,0,1);
            var dateMockForEach =  new Date(toDateSetter[0],(toDateSetter[1]-1),toDateSetter[2],0,0,0,1);
            for(var i = 0; i< allowedcountMock;i++){
                var dateMockForEachDateStr = dateMockForEach.getFullYear()+"-"+(dateMockForEach.getMonth()+1)+"-"+dateMockForEach.getDate();
                var inArrayCheck = $.inArray(dateMockForEachDateStr,leaveDaysArrayGlobal);
                if(inArrayCheck !== -1 || dateMockForEachDateStr === $("#endDateHidden").val()){
                    endDate = dateMockForEachDateStr;
                    break;
                }
                var inArrayCheckWeekend = $.inArray(dateMockForEach.getDay(),[0,6]);
                var inArrayCheckHolidays = $.inArray(dateMockForEachDateStr,holidaysArray);
                
                if(inArrayCheckWeekend !== -1 || inArrayCheckHolidays !== -1){
                    allowedcountMock = allowedcountMock + 1;
                }
                
                if(i === (allowedcountMock-1)){
                    endDate = dateMockForEachDateStr;
                }
                dateMockForEach.setDate(dateMockForEach.getDate()+1);
            }
            if(chosenDate === ""){
                checkToDate = "+0d";
                endDate = "+0d";
            }
            $(".append-end-date .date").remove();
            $(".append-end-date").append(dateTo);

            $(".datepicker2").datepicker({
                startDate:checkToDate,
                endDate:endDate,
                daysOfWeekDisabled:[0,6],
                datesDisabled:holidaysArray
            });
        });
        var setints = setInterval(function (){
            if(isClicked === 1){
                $(".datepicker1").datepicker().trigger("change.dp");
                $(".leavestatus").val(parseInt($("#apply-leave-type-id").find("option:selected").attr("data-isdeduct")));        
                clearInterval(setints);
            }
        },100);
        
    });
    
    $(".addExpatriateSubmits").click(function (e){
        canvas.deactivateAll().renderAll();
        var dataUrl = canvas.toDataURL();
        $(".photostr").val(dataUrl);
    });
    $(".submits").click(function (e){
        $(".issubmit").val("1");
    });
    $(".category").change(function (){
        var typeCheck = $(".type-hidden-admin-report").val();
        var selectMock = "<select name='leaveType' class='selects removeable-types'><option value='-1'>All Types</option>";
        $.get("leavetypescategory?category="+$(this).find("option:selected").val(), function(data, status){
            if(status === "success"){
                var len = data.length;
                $(".removeable-types").remove();
                if(len===0){
                    selectMock += "</select>";
                    $(".removeable-types-wrapper").append(selectMock);
                    $(".removeable-types").select2();
                    $(".removeable-types").val("-1");
                }
                var selectedState = "";
                for(var i=0;i< len;i++){
                    if(parseInt(typeCheck) === parseInt(data[i].id)){
                        selectedState = "selected = 'selected'";
                    }else{
                        selectedState = "";
                    }
                    selectMock += "<option value='"+data[i].id+"' "+selectedState+">"+data[i].leavetype+"</option>";
                    if(i === (len-1)){
                        selectMock += "</select>";
                        $(".removeable-types-wrapper").append(selectMock);
                        $(".removeable-types").select2();
                        $(".removeable-types").val("-1");
                    }
                }
            }else{
                selectMock += "</select>";
                $(".removeable-types-wrapper").append(selectMock);
                $(".removeable-types").select2();
                $(".removeable-types").val("-1");
                alert("Some Error Occured");
            }
        });
    });
    $(".category").change();
    $(".maincategory").change(function (){
        var selectedval = "";
        var typeCheck = $(this).val();
        var selectMock = "<select name='category' class='selects subcategory'><option value='' selected='selected'>Choose</option>";
        $.get("listAllSubCategory?category="+typeCheck, function(data, status){
            if(status === "success"){
                var len = data.length;
                $(".subcategory").remove();
                if(len===0){
                    selectMock += "</select>";
                    $(".category-wrapper").html(selectMock);
                    $(".subcategory").select2();
                    $(".subcategory").val("");
                }
                
                for(var i=0;i< len;i++){
                    if(parseInt($(".catoneditexpat").val()) === parseInt(data[i].id)){
                        selectedval = "selected='selected'";
                    }else{
                        selectedval = "";
                    }
                    selectMock += "<option value='"+data[i].id+"' "+selectedval+">"+data[i].category+"</option>";
                    if(i === (len-1)){
                        selectMock += "</select>";
                    $(".category-wrapper").html(selectMock);
                    $(".subcategory").select2();
                    
                    }
                }
            }else{
                selectMock += "</select>";
                $(".removeable-types-wrapper").append(selectMock);
                $(".removeable-types").select2();
                $(".removeable-types").val("-1");
                alert("Some Error Occured");
            }
        });
        
    });
    $(".maincategory").change();
    if($(".catoneditexpat").val() !== ""){
        $(".maincategory").trigger("change");
    }
    if($(".hidden-check-is-post").val() === "post"){
        $(".category").trigger("change");
    }
    $(".datepicker").datepicker({
        
    });
    
    /**********Calculate leave count on submiting the apply leave form**************/
    var calculateLeaveCount = function (dateFromParam,dateToParam){
        var leaveFrom = new Date(dateFromParam[0],dateFromParam[1]-1,dateFromParam[2],0,0,0,1);
        var leaveTo = new Date(dateToParam[0],dateToParam[1]-1,dateToParam[2],23,59,59,999);
        var leaveCount =  Math.ceil((leaveTo - leaveFrom)/(86400*1000));
        var leaveCountActual = 0;
        for(var i = 0 ; i < leaveCount;i++){
            var leaveFromAlt = leaveFrom.getDate();
            var getMonth = leaveFrom.getMonth();
            var validate = $.inArray(leaveFromAlt,holidaysArrayNew[getMonth]);
            if (validate !== -1 || leaveFrom.getDay() === 0 || leaveFrom.getDay() === 6){
                
            }else{
                leaveCountActual = leaveCountActual+1;
            }
            leaveFrom.setDate(leaveFrom.getDate()+1);
        }
        return leaveCountActual;
    };
    $(".apply-leave-submit").click(function (e){
        var df = $(".apply-leave-from-date").val().split("-");
        var dt = $(".apply-leave-to-date").val().split("-");
        var counts = calculateLeaveCount(df,dt);
        $(".calculateCount").val(counts) ;
        var availableBalance = parseInt($(".balance-leave").text());
        if(availableBalance < counts){
            $(".error-message-al").html("<i class='fa fa-exclamation-triangle'></i> You have only "+availableBalance+" days leave balance but you have tried for "+counts);
            e.preventDefault();
        }
    });
    $(".upload-mock").click(function (){
       $(".upload-excel-file").trigger("click");
    });
    $(".upload-excel-file").change(function (){
        $(".error-message-al").html("");
        var filename = $(this).val().split("\\");
        $(".file-name-mock").val(filename[filename.length-1]);
        var validateFile = filename[filename.length-1].split(".");
        if(validateFile[1] === "xlsx" || validateFile[1] === "xls" || validateFile[1] === "csv" || validateFile[1] === "XLSX" || validateFile[1] === "XLS" || validateFile[1] === "CSV" ){
            
        }else{
            $(".clear-mock").trigger("click");
            $(".error-message-al").html("Incorrect File Type!");
        }
    });
    $(".clear-mock").click(function (){
        $(".file-name-mock").val("No Files Chosen");
        $(".error-message-al").html("");
        $(".upload-excel-file").val("");
    });
    /**************************************************Vertical Tabs****************************************************/
    $("div.bhoechie-tab-menu>div.list-group>a").click(function(e) {
        e.preventDefault();
        $(this).siblings('a.active').removeClass("active");
        $(this).addClass("active");
        var index = $(this).index();
        $("div.bhoechie-tab>div.bhoechie-tab-content").removeClass("active");
        $("div.bhoechie-tab>div.bhoechie-tab-content").eq(index).addClass("active");
    });
    /**************************************************Input fields***************************************************************/
    $("input[type='text'],input[type='number']").attr("autocomplete","off");
    /******************************************************************/
    $(".logout").click(function (){
       $.get("logoutsuccess",function (){
            
       });
    });
    /*****************************************Validate IsExist OJF**********************************************************/
    $(".addojfsubmit").click(function (e){
    	var value = $(".ojfadd").val();
        $.get("isexistojf?value="+value,function(data, status){
        	if(data[0] === "0"){
        		$(".ojfexist").html("<i class='fa fa-exclamation-triangle fa-fw'></i> "+data[1]);
        	}else{
        		$(".ojfexist").html("");
        		$("form#OJFForm").submit();
        	}
        });
        
     });
    /*****************************************Validate IsExist Expatriate**********************************************************/
    $(".existexpatadd").click(function (e){
    	var value = $(".username").val();
    	var id = $(".idvalidation").val();
        $.get("isexistexpatriate?value="+value+"&id="+id,function(data, status){
        	if(data[0] === "0"){
        		$(".expatexist").html("<i class='fa fa-exclamation-triangle fa-fw'></i> "+data[1]);
        	}else{
        		$(".expatexist").html("");
        		$("form#AddExpatriatesFrorm").submit();
        	}
        });
        
     });
    /*****************************************Validate IsExist Leave Type**********************************************************/
    $(document).on("change",".subcategory",function(){
    	$(".subcategory").val($(this).val());
    });
    
    $(".addleavetypeisexist").click(function (e){
    	var value = $(".leavetype").val();
    	var category =  $(".subcategory").val();
    	var id = $(".idvalidation").val();
        $.get("isexistleavetypes?value="+value+"&category="+category+"&id="+id,function(data, status){
        	if(data[0] === "0"){
        		$(".leavetypeexist").html("<i class='fa fa-exclamation-triangle fa-fw'></i> "+data[1]);
        	}else{
        		$(".leavetypeexist").html("");
        		$("form#AddLeaveTypesForm").submit();
        	}
        });
     });
    
    /*****************************************Validate IsExist Holiday**********************************************************/
    $(".existholiday").click(function (e){
    	var value = $(".holidaydate").val();
    	var id = $(".idvalidation").val();
        $.get("isexistholidays?value="+value+"&id="+id,function(data, status){
        	if(data[0] === "0"){
        		$(".holidayexist").html("<i class='fa fa-exclamation-triangle fa-fw'></i> "+data[1]);
        	}else{
        		$(".holidayexist").html("");
        		$("form#AddHolidayForm").submit();
        	}
        });
        
     });
    /*****************************************Validate IsExist Add Admin**********************************************************/
    $(".isexistadminsubmit").click(function (e){
    	var value = $(".isexistadmin").val();
    	var id = $(".idadmin").val();
        $.get("isexistadmin?value="+value+"&id="+id,function(data, status){
        	if(data[0] === "0"){
        		$(".adminexisterr").html("<i class='fa fa-exclamation-triangle fa-fw'></i> "+data[1]);
        	}else{
        		$(".adminexisterr").html("");
        		$("form#addAdminForm").submit();
        	}
        });
        
     });
    /*****************************************Validate IsExist Add Main category**********************************************************/
    $(".existmcbutton").click(function (e){
    	var value = $(".existmc").val();
    	var id = $(".idmc").val();
        $.get("isexistmc?value="+value+"&id="+id,function(data, status){
        	if(data[0] === "0"){
        		$(".mcexisterr").html("<i class='fa fa-exclamation-triangle fa-fw'></i> "+data[1]);
        	}else{
        		$(".mcexisterr").html("");
        		$("form#addMainCategoryForm").submit();
        	}
        });
        
     });
    /*****************************************Validate IsExist Add Sub category**********************************************************/
    $(".existscbutton").click(function (e){
    	var value = $(".existsc").val();
    	var id = $(".idsc").val();
    	var mc = $(".mcidhidden").val();
        $.get("isexistsc?value="+value+"&id="+id+"&mc="+mc,function(data, status){
        	if(data[0] === "0"){
        		$(".existscerr").html("<i class='fa fa-exclamation-triangle fa-fw'></i> "+data[1]);
        	}else{
        		$(".existscerr").html("");
        		$("form#addSubCategory").submit();
        	}
        });
        
     });
    $(".genPdfexpat").click(function() {
    	$("form#postreportexpat").attr("action","downloadexpatriatesreportspdf");
		$("form#postreportexpat").submit();
		$("form#postreportexpat").attr("action","viewexpatriatesreports");
	});
    $(".genexcelsexpat").click(function() {
    	$("form#postreportexpat").attr("action","downloadexpatriatesreportsexcel");
		$("form#postreportexpat").submit();
		$("form#postreportexpat").attr("action","viewexpatriatesreports");
	});
    $(".leavetypespdfdownload").click(function() {
    	$("form#leavetypesreport").attr("action","downloadleavetypesreportspdf");
    	$("form#leavetypesreport").submit();
    	$("form#leavetypesreport").attr("action","viewleavetypesreports");
	});
});
