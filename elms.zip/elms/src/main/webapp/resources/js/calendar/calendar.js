$(document).ready(function (){
    if($(".isexpatDashboard").text() === "1"){
        var MonthsArray = ["January","February","March","April","May","June","July","August","September","October","November","December"];
        var holidayArrayFull = [[],[],[],[],[],[],[],[],[],[],[],[]];
        var holidayArray = [[],[],[],[],[],[],[],[],[],[],[],[]];
        var leaveArray =  [[],[],[],[],[],[],[],[],[],[],[],[]];
        var leaveArrayFull =  [[],[],[],[],[],[],[],[],[],[],[],[]];
        var weekendArray = [0,6];
        var dynamicDate = new Date();
        /*******************************Get Start date***************************/
        var dateFromExpat = $("#startDateHidden").val().split("-");
        dateFromExpat = new Date(dateFromExpat[0],dateFromExpat[1],dateFromExpat[2]);
        var dateToExpat = $("#endDateHidden").val().split("-");
        dateToExpat = new Date(dateToExpat[0],dateToExpat[1],dateToExpat[2]);
        /*******************************Get Start date***************************/
        var createCalendar = function (paramMonth,paramYear){
            dynamicDate.setFullYear(paramYear);dynamicDate.setMonth(paramMonth);dynamicDate.setDate(1);
            var currentDateVerifier = new Date(paramYear,paramMonth-1,1,0,1);
            var getDatesOfCurrentMonth = new Date(paramYear,paramMonth,1,0,-1).getDate();
            var getFirstDayOfCurrentMonth = new Date(paramYear,paramMonth-1,1,0,1).getDay();
            var cellCount = Math.ceil((getDatesOfCurrentMonth + getFirstDayOfCurrentMonth)/7)*7;
            var calendarFormatter = "<table class='calendar-wrapper'><tr class='border-bottom'><th class='cal-prev'  style='text-align:left;'><i class='fa fa-angle-left fa-2x fa-fw'></i></th><th colspan='5'>"+MonthsArray[currentDateVerifier.getMonth()]+ " - " +currentDateVerifier.getFullYear()+"</th><th class='cal-next' style='text-align:right;'><i class='fa fa-angle-right fa-2x fa-fw'></i></th></tr><tr class='days-head'><th>SUN</th><th>MON</th><th>TUE</th><th>WED</th><th>THU</th><th>FRI</th><th>SAT</th></tr>";
            var dateCounter = 1;
            var lastMonthBalance = new Date(paramYear,paramMonth-1,1,0,-1).getDate();
            var nextMonthInits = 1;

            var checkWeekend = function (variableDate){
                var checkResult = (variableDate % 7);
                var classString = "";
                var checkIfAssignedPeriod = new Date(paramYear,paramMonth,variableDate);
                if($.inArray(checkResult,weekendArray) !== -1 || checkIfAssignedPeriod < dateFromExpat || checkIfAssignedPeriod > dateToExpat){
                    classString = "datedblclick-empty";
                }
                return classString;
            };
            var checkHoliday = function (holidayMonth,holidayDate){
                var getHoliday = $.inArray(holidayDate,holidayArray[holidayMonth-1]);
                var classString = {classname:"",leavetag:""};
                var checkIfAssignedPeriod = new Date(paramYear,(paramMonth-1),holidayDate);
                var checkleaveDayDate = new Date(paramYear,(paramMonth-1),holidayDate);

                var checkResult = ((holidayDate + (getFirstDayOfCurrentMonth - 1)) % 7);
                var checkWeekend = $.inArray(checkResult,weekendArray);

                var dateTemp = checkleaveDayDate.getFullYear()+"-"+(checkleaveDayDate.getMonth()+1)+"-"+checkleaveDayDate.getDate();
                var checkLeaveday = $.inArray(dateTemp,leaveArray[paramMonth-1]);

                if(getHoliday !== -1 && checkIfAssignedPeriod >= dateFromExpat && checkIfAssignedPeriod <= dateToExpat){
                    var eventName = holidayArrayFull[holidayMonth-1][getHoliday][0];
                    classString.classname = " datedblclick-empty holidays";
                    classString.leavetag = "<p class='leavetag' data-holiday-desc='"+holidayArrayFull[holidayMonth-1][getHoliday][0]+"' data-holiday-date='"+holidayArrayFull[holidayMonth-1][getHoliday][4]+"' data-holiday-details='"+holidayArrayFull[holidayMonth-1][getHoliday][3]+"'>"+eventName+"</p>";
                }else if(getHoliday === -1 && checkWeekend === -1 && checkLeaveday !== -1){
                    classString.classname = " datedblclick-empty";
                    classString.leavetag = "<p class='leaveIndicator'><i class='"+leaveArrayFull[paramMonth-1][checkLeaveday][0]+"' style='color:"+leaveArrayFull[paramMonth-1][checkLeaveday][1]+" !important'></i></p>";
                }else if((getHoliday !== -1 && checkIfAssignedPeriod < dateFromExpat) || (getHoliday !== -1 && checkIfAssignedPeriod > dateToExpat)){
                    classString.classname = " datedblclick-empty";
                    classString.leavetag = "";
                }
                return classString;
            };
            for(var i = 0; i < cellCount; i++){
                if(i >= getFirstDayOfCurrentMonth && i < (getDatesOfCurrentMonth+getFirstDayOfCurrentMonth)){
                    var checkHolidayVariable = checkHoliday(paramMonth,dateCounter);
                    if(i === 0 || i === 7 || i === 14 ||  i === 21 ||  i === 28 ||  i === 35 || i === 42 || i === 48){
                        calendarFormatter += "<tr><td class='datedblclick "+checkWeekend(i)+" "+checkHolidayVariable.classname+"'><span>"+dateCounter+"</span>"+checkHolidayVariable.leavetag+"</td>";
                    }else if(i === 6 || i === 13 || i === 20 ||  i === 27 ||  i === 34 ||  i === 41 ||  i === 47 || i === 53){
                        calendarFormatter += "<td class='datedblclick "+checkWeekend(i)+" "+checkHolidayVariable.classname+"'><span>"+dateCounter+"</span>"+checkHolidayVariable.leavetag+"</td></tr>";
                    }else{
                        calendarFormatter += "<td class='datedblclick "+checkWeekend(i)+" "+checkHolidayVariable.classname+"'><span>"+dateCounter+"</span>"+checkHolidayVariable.leavetag+"</td>";
                    }
                    dateCounter++;
                }else{
                    if(i < getFirstDayOfCurrentMonth){
                        calendarFormatter += "<td class='datedblclick-nextorprev'>"+(lastMonthBalance - (getFirstDayOfCurrentMonth-1-i))+"</td>";
                    }else{
                        calendarFormatter += "<td class='datedblclick-nextorprev'>"+(nextMonthInits++)+"</td>";
                    }
                }

            }
            calendarFormatter += "</table>";
            $(".calendar-wrapper").html(calendarFormatter);
            $(".cal-next").click(function (){
                createCalendar((dynamicDate.getMonth()+1),dynamicDate.getFullYear());
            });
            $(".cal-prev").click(function (){
                createCalendar((dynamicDate.getMonth()-1),dynamicDate.getFullYear());
            });
            $(".datedblclick:not(.datedblclick-empty)").click(function (){
                $(".reducttext-area").val("");
                $("#applyleave .apply-leave-type").find("option").removeAttr("selected");
                var indVerifier = 0;
                var isBLeave = 0;
                $("#applyleave .apply-leave-type").find("option").each(function (ind){
                    if($(this).attr("disabled")){}
                    else{
                        if(parseInt($(this).attr("data-isdeduct")) === 4){
                            isBLeave = 1;
                        }
                        indVerifier = indVerifier+1;
                        if(indVerifier === 1){
                            $("#applyleave .apply-leave-type").find("option").eq(ind).attr("selected","selected");
                            $(".select2-container.selects.apply-leave-type").find(".select2-choice .select2-chosen").text($("#applyleave .apply-leave-type").find("option").eq(ind).text());
                        }
                    }
                });
                var availableBalance = parseInt($(".balance-leave").text());
                if(indVerifier === 0 && isBLeave !== 1){
                    $(".reason-reject").text("You have no leave types available to apply leave");
                    $("#noleaveFound").modal("show");
                }else if(availableBalance === 0 && isBLeave !== 1){
                    $(".reason-reject").text("You have no leave balance available to apply.");
                    $("#noleaveFound").modal("show");
                }else{
                    $("#apply-leave-type-id").trigger("change");
                    $(".apply-leave-from-date").val(dynamicDate.getFullYear()+"-"+checkifless(dynamicDate.getMonth())+"-"+checkifless($(this).find("span").text()));
                    $("#applyleave").modal("show");
                    isClicked = 1;
                }
            });
            $(".holidays").click(function (){
                var description = $(this).find("p").attr("data-holiday-desc");
                var dateHoliday = $(this).find("p").attr("data-holiday-date");
                var details = $(this).find("p").attr("data-holiday-details");
                $("#HolidayDesc").find(".holiday-title").html(description);
                $("#HolidayDesc").find(".holiday-date").html(dateHoliday);
                $("#HolidayDesc").find(".holiday-description").html(details);
                $("#HolidayDesc").modal("show");
            });
        };
        var getLeavedays = function (){
            $.get("getLeaveDays", function(data, status){
            	console.log(data);
                for(var i = 0;i < data.length; i++){
                    var leaveFromDate = data[i][0].split("-");
                    leaveFromDate = new Date(leaveFromDate[0],leaveFromDate[1]-1,leaveFromDate[2]);
                    var leaveToDate = data[i][1].split("-");
                    leaveToDate = new Date(leaveToDate[0],leaveToDate[1]-1,leaveToDate[2]);
                    var leaveCountsExpats = (leaveToDate-leaveFromDate)/(86400*1000);
                    for(var j = 0; j<= leaveCountsExpats;j++){
                        var dateCurrentIter = leaveFromDate.getFullYear()+"-"+(leaveFromDate.getMonth()+1)+"-"+leaveFromDate.getDate();
                        var iconandcolor = [data[i][3],data[i][4]];
                        leaveArrayFull[leaveFromDate.getMonth()].push(iconandcolor);
                        leaveArray[leaveFromDate.getMonth()].push(dateCurrentIter);
                        holidaysArray.push(dateCurrentIter);
                        leaveDaysArrayGlobal.push(dateCurrentIter);
                        leaveFromDate.setDate(leaveFromDate.getDate()+1);
                    }
                }
                createCalendar((dynamicDate.getMonth()+1),dynamicDate.getFullYear());
            });
        };
        $.get("getholidaycalendar", function(data, status){
            for(var i=0;i< data.length;i++){
                holidayArrayFull[parseInt(data[i][1])-1].push(data[i]);
                holidayArray[parseInt(data[i][1])-1].push(parseInt(data[i][2]));
                holidaysArray.push(data[i][4]);
            }
            holidaysArrayNew = holidayArray;
            getLeavedays();
        });

        var checkifless = function (number){
            if(number < 10 && number > 0){
                number = "0"+number;
            }
            return number;
        };
    }
   
});