package dao;

import java.security.Principal;
import java.util.List;
import java.util.Map;

import model.ApplyLeave;
import model.Categories;
import model.Expatriate;
import model.Holidays;
import model.LeaveTypes;
import model.OJFGeneral;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.web.multipart.MultipartFile;

import com.itextpdf.text.pdf.PdfPTable;

public interface UserDAO {
	 /***********************Dashboard Admin*************************/
    public String dashGetExpatriatesCount();
    public String dashGetLeaveTypesCount(String isAdmin, String username);
    public String dashGetAdminCount();
    public String dashGetLeaveCount(String username);
    public String dashGetLeaveConditionCount(String leaveStatus);
    public int dashboardAdmingetMinimumMonth();
    public List<Object> dashGetChartExpatrates(String year,int month,String username,String usertype);
    public int upcomingLeaves(String username,String adminOrSuperadmin);
    public int peopleInLeave(String username,String adminOrSuperadmin);
    public int upcomingTrips(String username,String adminOrSuperadmin);
    public int peopleinTrips(String username,String adminOrSuperadmin);
    public List<Object> dashGetChartExpatratesLeaves(String username,String maincategory,String from,String till,String isadmin);
    public Map<String,String[][]> dashGetChartLeaveTypes();
    public List<String[]> getHolidaysCalendar();
    public List<Categories> listAllCategoryWithMainCategory(String username,String isAdminOrSuperadmin);
    /*********************Dashboard users***************************/
    public int statusCheck(String username, int status);
    public String dashGetLeaveConditionCount(int leaveStatus,String username);
    public int appliedLeave(String username);
    public List<String[]> dashGetCategorywiseLEaveCount(String username);
    public String dashGetTotalAvailableLeave(String username);
    public List<LeaveTypes> dashGetLeaveTypesWithValidation(String username);
    public String[] dashGetUserStartEndDates(String username);
    public List<String[]> getLeaveDays(String username);
    public List<String[]> getExpatriatesChart(String username);
    public List<Holidays> listAllHolidaysUsers(String username);
    /*************************OJF*****************************/
    public String[] saveOJF(Expatriate expatriate);
    public String[] isExistOJF(String username);
    public List<Expatriate> listAllOJF(String username,String isAdmin);
    public String[] removeOJF(int id);
    public String[] disableOJF(int id);
    public String[] enableOJF(int id);
    public String[] resendOJFMail(String username);
    public Expatriate addAsExpatriateOJF(String id);
    /****************Get Admin User Main Category*******************/
    public String[] getAdminMainCategory(String username);
    /*************************Main Category************************/
    public String[] savemainCategory(Categories categories,String username);
    public String[] isExistMC(String mcid,String id);
    public List<Categories> listAllCategories();
    public String[] disableMainCategory(int id);
    public String[] enableMainCategory(int id);
    /*************************Sub Category************************/
    public String[] saveSubCategory(Categories categories,String username);
    public String[] isExistSC(String scid,String id,String mc);
    public List<Categories> listAllSubCategories(String username,String isAdmin);
    public String[] disableSubCategory(int id);
    public String[] enableSubCategory(int id);
    /*************************Profile*****************************/
    public Expatriate profile(String username);
    /*************************Admin Users**************************/
    public String[] saveAdmin(Expatriate expatriate,String username);
    public String[] isExistAdmin(String adminid,String id);
    public List<Expatriate> listAllAdmins(String isAdmin,String username);
    public Expatriate editAdminProfile(String username);
    public String[] disableAdmin(int id,String enabled);
    /*************************Expatriates**************************/
    public List<Categories> listAllSubCategory(String mainCategory);
    public String[] saveExpatriates(Expatriate expatriate,String username);
    public String[] isExistExpatriate(String username,String id);
    public List<Expatriate> listAllExpatriate(Boolean role);
    public Expatriate editExpatriate(int id);
    public String[] updateExpatriateStatus(String username);
    public String[] resendMailExpatriates(String username);
    public List<Expatriate> listExpatriateTypeReport(String username,String reportFor,String status,String duration,String dateFrom,String dateTill);
    public PdfPTable ExpatPdfDownload(String username,String reportFor,String status,String duration,String dateFrom,String dateTill);
    public HSSFWorkbook ExpatExcelDownload(String username,String reportFor,String status,String duration,String dateFrom,String dateTill);
    /*************************Leave Types**************************/
    public List<Categories> listAdminSpecificSubcategories(String username);
    public String[] saveLeaveTypes(LeaveTypes leaveTypes,String username);
    public String[] isExistLeaveTypes(String category,String leaveType,String id);
    public List<LeaveTypes> listAllLeaveTypes(String adminstatus,String username);
    public LeaveTypes editLeaveTypes(int id);
    public String[] deleteLeaveTypes(int id,String status);
    public List<LeaveTypes> listAllLeaveTypeReport(String isAdmin,String username,String admin,String dateFrom,String dateTo,String category);
    public PdfPTable LeaveTypePdfDownload(String isAdmin,String username,String admin,String dateFrom,String dateTo,String category);
    /*public HSSFWorkbook LeaveTypeExcelDownload(String username,String admin,String dateFrom,String dateTo,String category);*/
    /*************************Holidays*****************************/
    public String[] saveHoliday(Holidays holidays,String username);
    public String[] isExistHoliday(String holidaydate,String id);
    public List<Holidays> listAllHolidays(String adminstatus,String username);
    public Holidays editHoliday(int id);
    public String[] deleteHoliday(int id);
    /*************************User Leave**************************/
    public List<LeaveTypes> listAllLeaveTypes(String username);
    public String[] saveLeave(ApplyLeave applyLeave,String username);
    public List<ApplyLeave> listAllLeaves(String username);
    public ApplyLeave editLeave(int id);
    public String[] cancelLeave(int id);
    public String[] rejectleave(int id);
    public String[] approveleave(int id);
    public List<ApplyLeave> listLeavesReport(String username,int leaveType,String status,String leaveFrom,String leaveTo);
    /**************************Monitor leave***************************/
    public List<ApplyLeave> listAllLeavesAdmin(String username,String isAdmin);
    public List<LeaveTypes> listAllLeaveTypesBasedOnCategory(String category);
    public List<ApplyLeave> listAllLeavesAdminReport(String category,int leaveType,String status,String leaveFrom,String leaveTo);
    /*************************Login & Password**************************/
    public String[] forgotPassword(String username);
    public String[] changePassword(String username,String password,String newpassword);
    public void lastLogin(String username);
    /*************************Helper Methods**************************/
    public String getPrincipals(Principal user);
    public String[] getUserIcon(Principal user);
    public String[] sendMail(String mailto,String empid,String password,String Username);
    public String[] sendMailAdminAddOJF(String mailto,String password);
    public String[] sendMailApplyLeave(Expatriate expatriate,ApplyLeave applyLeave);
    public String[] sendMailForgotpassword(String mailto,String empid,String password,String username);
    public String[] readExcel(MultipartFile file,String username);
    
    /**********************************OJF********************************/
    public String[] saveOJFByExpat(OJFGeneral ojfGeneral,String username,int issubmit);
    public OJFGeneral expatSpecificDetails(String username);
    
}
