package controller;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.Principal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.ApplyLeave;
import model.Categories;
import model.Expatriate;
import model.Holidays;
import model.LeaveTypes;
import model.OJFGeneral;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.itextpdf.text.Document;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

import dao.UserDAO;
@Controller
@RequestMapping(value = "/")
public class LoginController {
        @Autowired private UserDAO userDao;
        
        /*
        *@Module Init
        */
        @RequestMapping(value = "/",method = RequestMethod.GET)
        public ModelAndView empty(HttpServletRequest request,ModelAndView model){
            model.setViewName("redirect:/home");
            return model;
        }
        @RequestMapping(value = "/logoutsuccess",method = RequestMethod.GET)
        public void j_spring_security_logout(HttpServletRequest request,ModelAndView model,Principal user){
            userDao.lastLogin(user.getName());
        }
        @RequestMapping(value = "/home",method = RequestMethod.GET)
        public ModelAndView homePage(HttpServletRequest request,ModelAndView model,Principal user) throws FileNotFoundException{
        	String[] str = {"","","","",""};
        	if(request.isUserInRole("ROLE_USER")){
        		str = userDao.getUserIcon(user);
        	}else if(request.isUserInRole("ROLE_ADMIN") || request.isUserInRole("ROLE_SADMIN")){
        		str = userDao.getUserIcon(user);
                str[0] = "glyphicon glyphicon-user fa-fw";
            }else if(request.isUserInRole("ROLE_OJF")){
	            str[1] = user.getName();
	            str[0] = "glyphicon glyphicon-user fa-fw";
            }else{
            	str[1] = "GET IN";
            	str[0] = "glyphicon glyphicon-user fa-fw";
            }
        	
            model.addObject("username",str);
            //model.addObject("dashGetLeaveTypesWithValidation",userDao.dashGetLeaveTypesWithValidation(userDao.getPrincipals(user)));
            model.setViewName("User");
            return model;
        }
        @RequestMapping(value = "/login",method = RequestMethod.GET)
        public ModelAndView login(@RequestParam(value="error",required = false) String error,HttpServletRequest request,ModelAndView model){
            if(error != null){
                if(error.equals("1")){
                    model.addObject("error","1");
                }
            }
            model.setViewName("Login");
            return model;
        }
        @RequestMapping(value = "/changepassword",method = RequestMethod.GET)
        public ModelAndView changepassword(HttpServletRequest request,ModelAndView model,Principal user){
            String[] str = userDao.getUserIcon(user);
            if(!request.isUserInRole("ROLE_USER")){
                str[0] = "glyphicon glyphicon-user fa-fw";
            }
            System.out.println("CHANGE PASSWORD SCREEN AS "+user.getName());
            model.addObject("username",str);
            model.setViewName("ChangePassword");
            return model;
        }
        @RequestMapping(value = "/changepassword",method = RequestMethod.POST)
        public ModelAndView changepasswordPOST(@RequestParam("password") String currePassword,
                @RequestParam("newpassword") String newPassword,HttpServletRequest request,ModelAndView model,Principal user,RedirectAttributes redirectAttributes){
        	System.out.println("PASSWORD CHANGE TRIGGERED BY "+user.getName());
        	redirectAttributes.addFlashAttribute("saveStatus",userDao.changePassword(user.getName(), currePassword, newPassword));
            model.setViewName("redirect:/changepassword");
            return model;
        }
        @RequestMapping(value = "/forgotpassword",method = RequestMethod.POST)
        public ModelAndView forgotpassword(HttpServletRequest request,ModelAndView model,RedirectAttributes redirectAttributes){
        	System.out.println("FORGOT PASSWORD TRIGGERED FOR "+request.getParameter("username"));
        	redirectAttributes.addFlashAttribute("saveStatus",userDao.forgotPassword(request.getParameter("username")));
            model.setViewName("redirect:/login");
            return model;
        }
        @RequestMapping(value = "/accessdenied",method = RequestMethod.GET)
        public ModelAndView accessdenied(HttpServletRequest request,ModelAndView model,Principal user){
        	System.out.println("ACCESS DENIED TRIGGERED FOR  "+user.getName());
            String[] str = userDao.getUserIcon(user);
            if(request.isUserInRole("ROLE_USER")){
                str[0] = "glyphicon glyphicon-user fa-fw";
            }
            model.addObject("username",str);
            model.setViewName("AccessDenied");
            return model;
        }
        @RequestMapping(value = "/viewprofile",method = RequestMethod.GET)
        public ModelAndView viewprofile(HttpServletRequest request,ModelAndView model,Principal user){
        	System.out.println("PROFILE REQUEST TRIGGERED "+user.getName());
            model.addObject("username",userDao.getUserIcon(user));
            model.addObject("userDetails",userDao.profile(user.getName()));
            model.setViewName("ViewProfile");
            return model;
        }
        
        /*************************Dashboard**************************/
        @RequestMapping(value = "/dashboard",method = RequestMethod.GET)
        public ModelAndView dashboard(HttpServletRequest request,ModelAndView model,Principal user){
        	System.out.println("DASHBOARD REQUEST TRIGGERED "+user.getName());
            if(request.isUserInRole("ROLE_ADMIN") || request.isUserInRole("ROLE_SADMIN")){
            	System.out.println("###########admin");
            	/*side bar*/
                String isAdminOrSuperAdmin = "1";
                if(request.isUserInRole("ROLE_ADMIN")){
                    isAdminOrSuperAdmin = "0";
                }
            	model.addObject("username",userDao.getUserIcon(user));
                model.addObject("listAllCategories",userDao.listAllCategories());
                model.addObject("ExpatriatesCount",userDao.dashGetExpatriatesCount());
                model.addObject("LeaveTypesCount",userDao.dashGetLeaveTypesCount(isAdminOrSuperAdmin,user.getName()));
                model.addObject("AdminCount",userDao.dashGetAdminCount());
                model.addObject("LeaveCounts",userDao.dashGetLeaveCount(user.getName()));
                //model.addObject("ApprovedLeaveCounts",userDao.dashGetLeaveConditionCount("1"));
                //model.addObject("RejectedLeaveCounts",userDao.dashGetLeaveConditionCount("2"));
                //model.addObject("WaitingLeaveCounts",userDao.dashGetLeaveConditionCount("0"));
                model.addObject("ChartLeaveType",userDao.dashGetChartLeaveTypes());
                model.addObject("UpcominLeaves",userDao.upcomingLeaves(user.getName(),isAdminOrSuperAdmin));
                model.addObject("PeopleInLeave",userDao.peopleInLeave(user.getName(),isAdminOrSuperAdmin));
                model.addObject("UpcomingTrips",userDao.upcomingTrips(user.getName(),isAdminOrSuperAdmin));
                model.addObject("PeopleInTrips",userDao.peopleinTrips(user.getName(),isAdminOrSuperAdmin));
                model.addObject("isadmin",isAdminOrSuperAdmin);
                model.setViewName("DashboardAdmin");
            }else if(request.isUserInRole("ROLE_USER")){
            	System.out.println("###########user");
            	model.addObject("username",userDao.getUserIcon(user));
                model.addObject("AllLeaveTypes",userDao.listAllLeaveTypes(user.getName()));
                model.addObject("LeavesTaken",userDao.dashGetLeaveConditionCount(0,user.getName()));
                model.addObject("LeavesFuture",userDao.dashGetLeaveConditionCount(1,user.getName()));
                model.addObject("usericon",userDao.getUserIcon(user));
                model.addObject("appliedLeave",userDao.appliedLeave(user.getName()));
                model.addObject("approvedLeave",userDao.statusCheck(user.getName(),1));
                model.addObject("waitingApproval",userDao.statusCheck(user.getName(),0));
                model.addObject("rejectedLeave",userDao.statusCheck(user.getName(),2));
                model.addObject("LeaveCalculationsBasedOnType",userDao.dashGetCategorywiseLEaveCount(user.getName()));
                model.addObject("totalAvailableLeave",userDao.dashGetTotalAvailableLeave(user.getName()));
                model.addObject("dashGetLeaveTypesWithValidation",userDao.dashGetLeaveTypesWithValidation(user.getName()));
                model.addObject("dashGetUserYear",userDao.dashGetUserStartEndDates(user.getName()));
                model.addObject("dashGetHolidays",userDao.listAllHolidaysUsers(user.getName()));
                model.addObject("ListAllLeaves",userDao.listAllLeaves(user.getName()));
                model.setViewName("Dashboard");
            }else{
            	System.out.println("###########ojf");
            	model.setViewName("redirect:/addojfgeneral");
            }
            return model;
        }
        @RequestMapping(value = "/getholidaycalendar",method = RequestMethod.GET)
        public @ResponseBody List<String[]> getholidaycalendar(){
            List<String[]>  holidaysArray = userDao.getHolidaysCalendar();
            return holidaysArray;
        }
        @RequestMapping(value = "/getMinimumYear",method = RequestMethod.GET)
        public @ResponseBody int getMinimumYear(Principal user){
            int minYear = userDao.dashboardAdmingetMinimumMonth();
            return minYear;
        }
        @RequestMapping(value = "/getExpatriatesChartDashboard",method = RequestMethod.GET)
        public @ResponseBody List<String[]> getExpatriatesChartDashboard(Principal user){
            List<String[]>  getExpatriatesChartDashboard = userDao.getExpatriatesChart(user.getName());
            return getExpatriatesChartDashboard;
        }
        @RequestMapping(value = "/getExpatriatesChartAdminDashboard",method = RequestMethod.GET)
        public @ResponseBody List<Object> getExpatriatesChartAdminDashboard(HttpServletRequest request,Principal user,@RequestParam("year") String year,@RequestParam("months") int months){
        	String usertype = "A";
        	if(!request.isUserInRole("ROLE_ADMIN")){
        		usertype = "SA";
        	}
            List<Object> getExpatriatesChartAdminDashboard = userDao.dashGetChartExpatrates(year,months,user.getName(),usertype);
            return getExpatriatesChartAdminDashboard;
        }
        @RequestMapping(value = "/getExpatriatesLeavesChartAdminDashboard",method = RequestMethod.GET)
        public @ResponseBody List<Object> getExpatriatesLeavesChartAdminDashboard(HttpServletRequest request,Principal user,@RequestParam("from") String from,@RequestParam("till") String till,@RequestParam("mc") String mc){
        	String isadmin = "SA";
        	if(request.isUserInRole("ROLE_ADMIN")){
        		isadmin = "A";
        	}
            List<Object> getExpatriatesLeavesChartAdminDashboard = userDao.dashGetChartExpatratesLeaves(user.getName(),mc,from,till,isadmin);
            return getExpatriatesLeavesChartAdminDashboard;
        }
        @RequestMapping(value = "/getLeaveDays",method = RequestMethod.GET)
        public @ResponseBody List<String[]> getLeaveDays(Principal user){
            List<String[]>  getLeaveDays = userDao.getLeaveDays(user.getName());
            return getLeaveDays;
        }
        @RequestMapping(value = "/savefile",method = RequestMethod.POST)
        public @ResponseBody ModelAndView savefile(@RequestParam("file") MultipartFile file,HttpServletRequest request,ModelAndView model,Principal user,RedirectAttributes redirectAttributes){
            redirectAttributes.addFlashAttribute("saveStatus",userDao.readExcel(file,user.getName()));
            model.setViewName("redirect:/addexpatriate");
            return model;
        }
        /************************OJF*************************/
        @RequestMapping(value = "/saveojf",method = RequestMethod.POST)
        public ModelAndView saveojf(HttpServletRequest request,ModelAndView model,Expatriate expatriate,Principal user,RedirectAttributes redirectAttributes){
            redirectAttributes.addFlashAttribute("saveStatus",userDao.saveOJF(expatriate));
            model.setViewName("redirect:/viewlistallojf");   
            return model;
        }
        @RequestMapping(value = "/resendemailojf",method = RequestMethod.GET)
        public ModelAndView resendemailojf(HttpServletRequest request,ModelAndView model,RedirectAttributes redirectAttributes,Principal user,@RequestParam("username") String usersname){
        	redirectAttributes.addFlashAttribute("saveStatus",userDao.resendOJFMail(usersname));
            model.setViewName("redirect:/viewlistallojf");
            return model;
        }
        
        @RequestMapping(value = "/viewlistallojf",method = RequestMethod.GET)
        public ModelAndView viewlistallojf(HttpServletRequest request,ModelAndView model,RedirectAttributes redirectAttributes,Principal user){
        	String isAdmin = "SA";
            if(request.isUserInRole("ROLE_ADMIN")){
                isAdmin = "A";
            }
            model.addObject("viewlistallojf",userDao.listAllOJF(user.getName(),isAdmin));
            model.addObject("username",userDao.getUserIcon(user));
            model.setViewName("ViewOJF");
            return model;
        }
        @RequestMapping(value = "/viewojfadmin",method = RequestMethod.GET)
        public ModelAndView viewojfadmin(HttpServletRequest request,ModelAndView model,RedirectAttributes redirectAttributes,Principal user,@RequestParam("id") String usersname){
        	redirectAttributes.addFlashAttribute("ojfGeneralDataSession",userDao.expatSpecificDetails(usersname));
            model.setViewName("redirect:/viewojfadmins");
            return model;
        }
        @RequestMapping(value = "/viewojfadmins",method = RequestMethod.GET)
        public ModelAndView viewojfadmins(HttpServletRequest request,ModelAndView model,Principal user){
        	model.addObject("username",userDao.getUserIcon(user));
            model.setViewName("OJFAddExpatriate");
            return model;
        }
        @RequestMapping(value = "/deleteojf",method = RequestMethod.GET)
        public ModelAndView deleteojf(@RequestParam("id") int id,HttpServletRequest request,ModelAndView model,RedirectAttributes redirectAttributes,Principal user){
            redirectAttributes.addFlashAttribute("deleteStatus",userDao.removeOJF(id));
            model.setViewName("redirect:/viewlistallojf");
            return model;
        }
        @RequestMapping(value = "/disableOJF",method = RequestMethod.GET)
        public ModelAndView disableOJF(@RequestParam("id") int id,HttpServletRequest request,ModelAndView model,RedirectAttributes redirectAttributes,Principal user){
            redirectAttributes.addFlashAttribute("deleteStatus",userDao.disableOJF(id));
            model.setViewName("redirect:/viewlistallojf");
            return model;
        }
        @RequestMapping(value = "/enableOJF",method = RequestMethod.GET)
        public ModelAndView enableOJF(@RequestParam("id") int id,HttpServletRequest request,ModelAndView model,RedirectAttributes redirectAttributes,Principal user){
            redirectAttributes.addFlashAttribute("deleteStatus",userDao.enableOJF(id));
            model.setViewName("redirect:/viewlistallojf");
            return model;
        }
        @RequestMapping(value = "/addasexpatriateojf",method = RequestMethod.GET)
        public ModelAndView addasexpatojf(@RequestParam("id") String id,HttpServletRequest request,ModelAndView model,RedirectAttributes redirectAttributes,Principal user){
            redirectAttributes.addFlashAttribute("editexpatriates",userDao.addAsExpatriateOJF(id));
            model.setViewName("redirect:/addexpatriate");
            return model;
        }
        
        /************************Main category*************************/
        @RequestMapping(value = "/savemaincategory",method = RequestMethod.POST)
        public ModelAndView savemaincategory(HttpServletRequest request,ModelAndView model,Categories categories,Principal user,RedirectAttributes redirectAttributes){
            redirectAttributes.addFlashAttribute("saveStatusMC",userDao.savemainCategory(categories,user.getName()));
            redirectAttributes.addFlashAttribute("tab",3);
            model.setViewName("redirect:/adminsettings"); 
            return model;
        }
        @RequestMapping(value = "/isexistmc",method = RequestMethod.GET)
        public @ResponseBody String[] isexistmc(@RequestParam("value") String mc,@RequestParam("id") String id){
            String[]  admins = userDao.isExistMC(mc,id);
            return admins;
        }
        @RequestMapping(value = "/disablemc",method = RequestMethod.GET)
        public ModelAndView disablemc(@RequestParam("id") int id,HttpServletRequest request,ModelAndView model,RedirectAttributes redirectAttributes,Principal user){
            redirectAttributes.addFlashAttribute("disablemc",userDao.disableMainCategory(id));
            redirectAttributes.addFlashAttribute("tab",4);
            model.setViewName("redirect:/adminsettings");
            return model;
        }
        @RequestMapping(value = "/enablemc",method = RequestMethod.GET)
        public ModelAndView enablemc(@RequestParam("id") int id,HttpServletRequest request,ModelAndView model,RedirectAttributes redirectAttributes,Principal user){
            redirectAttributes.addFlashAttribute("disablemc",userDao.enableMainCategory(id));
            redirectAttributes.addFlashAttribute("tab",4);
            model.setViewName("redirect:/adminsettings");
            return model;
        }
        /************************Sub category*************************/
        @RequestMapping(value = "/savesubcategory",method = RequestMethod.POST)
        public ModelAndView savesubcategory(HttpServletRequest request,ModelAndView model,Categories categories,Principal user,RedirectAttributes redirectAttributes){
            redirectAttributes.addFlashAttribute("saveStatusSC",userDao.saveSubCategory(categories,user.getName()));
            redirectAttributes.addFlashAttribute("tab",5);
            model.setViewName("redirect:/adminsettings"); 
            return model;
        }
        @RequestMapping(value = "/isexistsc",method = RequestMethod.GET)
        public @ResponseBody String[] isexistsc(@RequestParam("value") String sc,@RequestParam("id") String id,@RequestParam("mc") String mc){
            String[]  admins = userDao.isExistSC(sc,id,mc);
            return admins;
        }
        @RequestMapping(value = "/disablesc",method = RequestMethod.GET)
        public ModelAndView disablesc(@RequestParam("id") int id,HttpServletRequest request,ModelAndView model,RedirectAttributes redirectAttributes,Principal user){
            redirectAttributes.addFlashAttribute("disablesc",userDao.disableSubCategory(id));
            redirectAttributes.addFlashAttribute("tab",6);
            model.setViewName("redirect:/adminsettings");
            return model;
        }
        @RequestMapping(value = "/enablesc",method = RequestMethod.GET)
        public ModelAndView enablesc(@RequestParam("id") int id,HttpServletRequest request,ModelAndView model,RedirectAttributes redirectAttributes,Principal user){
            redirectAttributes.addFlashAttribute("disablesc",userDao.enableSubCategory(id));
            redirectAttributes.addFlashAttribute("tab",6);
            model.setViewName("redirect:/adminsettings");
            return model;
        }
        /************************Admin Settings*************************/
        @RequestMapping(value = "/adminsettings",method = RequestMethod.GET)
        public ModelAndView adminsettings(HttpServletRequest request,ModelAndView model,Principal user){
            model.addObject("username",userDao.getUserIcon(user));
            String isAdmin = "1";
            if(request.isUserInRole("ROLE_ADMIN")){
            	isAdmin = "0";
            	model.addObject("mCategoryName",userDao.getAdminMainCategory(user.getName()));
            }
            model.addObject("allAdmins",userDao.listAllAdmins(isAdmin,user.getName()));
            model.addObject("listAllCategories",userDao.listAllCategories());
            model.addObject("listAllSubCategories",userDao.listAllSubCategories(user.getName(),isAdmin));
            model.addObject("isadmin",isAdmin);
            model.setViewName("AdminSettings");
            return model;
        }
        /*******************************************Admin users******************************************/
        @RequestMapping(value = "/saveadmin",method = RequestMethod.POST)
        public ModelAndView saveadmin(HttpServletRequest request,ModelAndView model,Expatriate expatriate,Principal user,RedirectAttributes redirectAttributes){
            redirectAttributes.addFlashAttribute("saveStatusAdmin",userDao.saveAdmin(expatriate,user.getName()));
            redirectAttributes.addFlashAttribute("tab",1);
            model.setViewName("redirect:/adminsettings");
            return model;
        }
        @RequestMapping(value = "/isexistadmin",method = RequestMethod.GET)
        public @ResponseBody String[] isexistadmin(@RequestParam("value") String username,@RequestParam("id") String id){
            String[]  admins = userDao.isExistAdmin(username,id);
            return admins;
        }
        @RequestMapping(value = "/editadminprofile",method = RequestMethod.GET)
        public ModelAndView editadminprofile(HttpServletRequest request,ModelAndView model,RedirectAttributes redirectAttributes,Principal user){
            redirectAttributes.addFlashAttribute("editadminprofile",userDao.editAdminProfile(user.getName()));
            redirectAttributes.addFlashAttribute("tab",1);
            model.setViewName("redirect:/adminsettings");
            return model;
        }
        @RequestMapping(value = "disableadmin",method = RequestMethod.GET)
        public ModelAndView disableadmin(@RequestParam("id") int id,@RequestParam("enabled") String en,ModelAndView model,RedirectAttributes redirectAttributes){
            redirectAttributes.addFlashAttribute("deleteStatusadmin",userDao.disableAdmin(id,en));
            redirectAttributes.addFlashAttribute("tab",2);
            model.setViewName("redirect:/adminsettings");
            return model;
        }
        /*******************************************Expatriates*******************************************/
        @RequestMapping(value = "/listAllSubCategory",method = RequestMethod.GET)
        public @ResponseBody List<Categories> listAllSubCategory(@RequestParam("category") String category){
            List<Categories> listAllSubCats = userDao.listAllSubCategory(category);
            return listAllSubCats;
        }
        @RequestMapping(value = "/addexpatriate",method = RequestMethod.GET)
        public ModelAndView addexpatriate(HttpServletRequest request,ModelAndView model,Principal user){
            model.addObject("username",userDao.getUserIcon(user));
            model.addObject("mainCategory",userDao.listAllCategories());
            model.addObject("addorupdate","Save");
            model.setViewName("AddExpatriate");
            return model;
        }
        @RequestMapping(value = "/saveexpatriate",method = RequestMethod.POST)
        public ModelAndView saveexpatriate(HttpServletRequest request,ModelAndView model,Expatriate expatriate,Principal user,RedirectAttributes redirectAttributes){
        	redirectAttributes.addFlashAttribute("saveStatus",userDao.saveExpatriates(expatriate,user.getName()));
            model.setViewName("redirect:/addexpatriate");
            return model;
        }
        @RequestMapping(value = "/isexistexpatriate",method = RequestMethod.GET)
        public @ResponseBody String[] isexistexpatriate(@RequestParam("value") String username,@RequestParam("id") String id){
            String[]  expats = userDao.isExistExpatriate(username,id);
            return expats;
        }
        @RequestMapping(value = "/viewexpatriates",method = RequestMethod.GET)
        public ModelAndView viewexpatriates(HttpServletRequest request,ModelAndView model,Principal user){
            model.addObject("username",userDao.getUserIcon(user));
            model.addObject("ListAllExpatriates",userDao.listAllExpatriate(request.isUserInRole("ROLE_ADMIN")));
            model.setViewName("ViewExpatriates");
            return model;
        }
        @RequestMapping(value = "/editexpatriates",method = RequestMethod.GET)
        public ModelAndView editexpatriates(HttpServletRequest request,ModelAndView model,RedirectAttributes redirectAttributes,@RequestParam("id") int id,Principal user){
            redirectAttributes.addFlashAttribute("editexpatriates",userDao.editExpatriate(id));
            redirectAttributes.addFlashAttribute("addorupdate","Update");
            model.setViewName("redirect:/addexpatriate");
            return model;
        }
        @RequestMapping(value = "deleteexpatriates",method = RequestMethod.GET)
        public ModelAndView deleteexpatriates(@RequestParam("id") String id,ModelAndView model,RedirectAttributes redirectAttributes){
            redirectAttributes.addFlashAttribute("deleteStatus",userDao.updateExpatriateStatus(id));
            model.setViewName("redirect:/viewexpatriates");
            return model;
        }
        @RequestMapping(value = "/viewexpatriatesreport",method = RequestMethod.GET)
        public ModelAndView viewexpatriatesreport(HttpServletRequest request,ModelAndView model,RedirectAttributes redirectAttributes,Principal username){           
            model.addObject("username",userDao.getUserIcon(username));
            model.setViewName("ViewExpatriatesReport");
            return model;
        }
        @RequestMapping(value = "/viewexpatriatesreports",method = RequestMethod.POST)
        public ModelAndView viewexpatriatesreportpost(HttpServletRequest request,HttpServletResponse response,ModelAndView model,RedirectAttributes redirectAttributes,Principal username){
            redirectAttributes.addFlashAttribute("viewexpatriatesreport",userDao.listExpatriateTypeReport(username.getName(),request.getParameter("reportfor"),request.getParameter("status"),request.getParameter("duration"),request.getParameter("datefrom"),request.getParameter("datetill")));
            model.setViewName("redirect:/viewexpatriatesreport");
            return model;
        }
        @RequestMapping(value = "/downloadexpatriatesreportspdf",method = RequestMethod.POST)
        public ModelAndView downloadexpatriatesreportspdf(HttpServletRequest request,HttpServletResponse response,ModelAndView model,RedirectAttributes redirectAttributes,Principal username) throws FileNotFoundException{
            Document document = new Document();
            String timeStamp = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss").format(new Date());
            try{
            	response.setContentType("application/force-download");
                response.setHeader("Content-Disposition", "filename=ExpatriatesReports"+timeStamp+".pdf"); 
                PdfWriter.getInstance(document, response.getOutputStream());
                document.open();
                document.add(new Paragraph("Expatriate Reports "+timeStamp));
                document.add(userDao.ExpatPdfDownload(username.getName(),request.getParameter("reportfor"),request.getParameter("status"),request.getParameter("duration"),request.getParameter("datefrom"),request.getParameter("datetill")));
                
                //document.add(new Paragraph(new Date().toString()));
                //Add more content here
                document.close();
                response.getOutputStream().flush();
            }catch(Exception e){
                e.printStackTrace();
            }
            
            model.setViewName("redirect:/viewexpatriatesreport");
            return model;
        }
        @RequestMapping(value = "/downloadexpatriatesreportsexcel",method = RequestMethod.POST)
        public ModelAndView downloadexpatriatesreportsexcel(HttpServletRequest request,HttpServletResponse response,ModelAndView model,RedirectAttributes redirectAttributes,Principal username) throws FileNotFoundException{ 
            String timeStamp = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss").format(new Date());
            response.setContentType("application/force-download");
            response.setHeader("Content-Disposition", "filename=ExpatriatesReports"+timeStamp+".xls");
            HSSFWorkbook workbook = userDao.ExpatExcelDownload(username.getName(),request.getParameter("reportfor"),request.getParameter("status"),request.getParameter("duration"),request.getParameter("datefrom"),request.getParameter("datetill"));
            try {
				workbook.write(response.getOutputStream());
				response.getOutputStream().flush();
			} catch (IOException e) {
				e.printStackTrace();
			}
            
            model.setViewName("redirect:/viewexpatriatesreport");
            return model;
        }
        
        @RequestMapping(value = "/expatriateresendmail",method = RequestMethod.GET)
        public ModelAndView expatriateresendmail(HttpServletRequest request,ModelAndView model,RedirectAttributes redirectAttributes,@RequestParam("zid") String username){           
        	redirectAttributes.addFlashAttribute("saveStatus",userDao.resendMailExpatriates(username));
            model.setViewName("redirect:/viewexpatriates");
            return model;
        }
        
        /*************************Leave Types**************************/
        @RequestMapping(value = "/addleavetypes",method = RequestMethod.GET)
        public ModelAndView addleavetypes(HttpServletRequest request,ModelAndView model,Principal user){
            model.addObject("username",userDao.getUserIcon(user));
            model.addObject("listAllCategories",userDao.listAllCategories());
            model.addObject("listAdminSpecificSubcategories",userDao.listAdminSpecificSubcategories(user.getName()));
            if(request.isUserInRole("ROLE_SADMIN")){
                model.addObject("admintype","SADMIN");
            }else{
                model.addObject("admintype","ADMIN");
            }
            model.addObject("addorupdate","Save");
            model.setViewName("AddLeaveTypes");
            return model;
        }
        @RequestMapping(value = "/saveleavetypes",method = RequestMethod.POST)
        public ModelAndView saveleavetypes(HttpServletRequest request,ModelAndView model,LeaveTypes leaveTypes,Principal user,RedirectAttributes redirectAttributes){
            redirectAttributes.addFlashAttribute("saveStatus",userDao.saveLeaveTypes(leaveTypes,user.getName()));
            model.setViewName("redirect:/addleavetypes");
            return model;
        }
        @RequestMapping(value = "/isexistleavetypes",method = RequestMethod.GET)
        public @ResponseBody String[] isexistleavetypes(HttpServletRequest request,Principal user,@RequestParam("value") String value,@RequestParam("category") String category,@RequestParam("id") String id){
        	String[]  lt = userDao.isExistLeaveTypes(category,value,id);
            return lt;
        }
        @RequestMapping(value = "/viewleavetypes",method = RequestMethod.GET)
        public ModelAndView viewleavetypes(HttpServletRequest request,ModelAndView model,Principal user){
            model.addObject("username",userDao.getUserIcon(user));
            String adminstatus = "SA";
            if(request.isUserInRole("ROLE_ADMIN")){
                adminstatus = "A";
            }
            model.addObject("ListAllLeaveTypes",userDao.listAllLeaveTypes(adminstatus,user.getName()));
            model.addObject("adminstatus",adminstatus);
            model.setViewName("ViewLeaveTypes");
            return model;
        }
        @RequestMapping(value = "/editleavetypes",method = RequestMethod.GET)
        public ModelAndView editleavetypes(HttpServletRequest request,ModelAndView model,RedirectAttributes redirectAttributes,@RequestParam("id") int id,Principal user){
            redirectAttributes.addFlashAttribute("editleavetypes",userDao.editLeaveTypes(id));
            redirectAttributes.addFlashAttribute("addorupdate","Update");
            model.setViewName("redirect:/addleavetypes");
            return model;
        }
        @RequestMapping(value = "disableleavetypes",method = RequestMethod.GET)
        public ModelAndView deleteleavetypes(@RequestParam("id") int id,@RequestParam("st") String status,ModelAndView model,RedirectAttributes redirectAttributes){
            redirectAttributes.addFlashAttribute("deleteStatus",userDao.deleteLeaveTypes(id,status));
            model.setViewName("redirect:/viewleavetypes");
            return model;
        }
        @RequestMapping(value = "/viewleavetypesreport",method = RequestMethod.GET)
        public ModelAndView viewleavetypesreport(HttpServletRequest request,ModelAndView model,Principal user){
            model.addObject("username",userDao.getUserIcon(user));
            String isAdmin = "SA";
            if(request.isUserInRole("ROLE_ADMIN")){
                isAdmin = "A";
            }
            System.out.println(userDao.listAllCategoryWithMainCategory(user.getName(),isAdmin).size());
            model.addObject("AllLeaveTypes",userDao.listAllCategoryWithMainCategory(user.getName(),isAdmin));
            model.addObject("admins",isAdmin);
            model.setViewName("ViewLeaveTypesReport");
            return model;
        }
        
        @RequestMapping(value = "/viewleavetypesreports",method = RequestMethod.POST)
        public ModelAndView viewleavetypesreportPost(HttpServletRequest request,ModelAndView model,Principal user,RedirectAttributes redirectAttributes){
        	String isAdmin = "SA";
            if(request.isUserInRole("ROLE_ADMIN")){
                isAdmin = "A";
            }
            redirectAttributes.addFlashAttribute("listAllLeaveTypeReport",userDao.listAllLeaveTypeReport(isAdmin,user.getName(),request.getParameter("reportuser"),request.getParameter("reportDateFrom"),request.getParameter("reportDateTo"),request.getParameter("category")));
            String[] str = {request.getParameter("reportuser"),request.getParameter("reportDateFrom"),request.getParameter("reportDateTo"),request.getParameter("category")};
            redirectAttributes.addFlashAttribute("datefields",str);
            model.setViewName("redirect:/viewleavetypesreport");
            return model;
        }
        @RequestMapping(value = "/downloadleavetypesreportspdf",method = RequestMethod.POST)
        public ModelAndView downloadleavetypesreportspdf(HttpServletRequest request,HttpServletResponse response,ModelAndView model,RedirectAttributes redirectAttributes,Principal user) throws FileNotFoundException{
        	String isAdmin = "SA";
            if(request.isUserInRole("ROLE_ADMIN")){
                isAdmin = "A";
            }
            String[] str = {request.getParameter("reportuser"),request.getParameter("reportDateFrom"),request.getParameter("reportDateTo"),request.getParameter("category")};
            redirectAttributes.addFlashAttribute("datefields",str);
            Document document = new Document();
            String timeStamp = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss").format(new Date());
            try{
            	response.setContentType("application/force-download");
                response.setHeader("Content-Disposition", "filename=ExpatriatesReports"+timeStamp+".pdf"); 
                PdfWriter.getInstance(document, response.getOutputStream());
                document.open();
                document.add(new Paragraph("Leave Types Reports"+timeStamp));
                document.add(new Paragraph("\n"));
                document.add(userDao.LeaveTypePdfDownload(isAdmin,user.getName(),request.getParameter("reportuser"),request.getParameter("reportDateFrom"),request.getParameter("reportDateTo"),request.getParameter("category")));
                document.close();
                response.getOutputStream().flush();
            }catch(Exception e){
                e.printStackTrace();
            }
            
            model.setViewName("redirect:/viewleavetypesreport");
            return model;
        }
        /*************************Holidays**************************/
        @RequestMapping(value = "/addholiday",method = RequestMethod.GET)
        public ModelAndView addholiday(HttpServletRequest request,ModelAndView model,Principal user){
            model.addObject("username",userDao.getUserIcon(user));
            model.addObject("addorupdate","Save");
            model.setViewName("AddHolidays");
            return model;
        }
        @RequestMapping(value = "/saveholiday",method = RequestMethod.POST)
        public ModelAndView saveholiday(HttpServletRequest request,ModelAndView model,Holidays holidays,Principal user,RedirectAttributes redirectAttributes){
            redirectAttributes.addFlashAttribute("saveStatus",userDao.saveHoliday(holidays,user.getName()));
            model.setViewName("redirect:/addholiday");
            return model;
        }
        @RequestMapping(value = "/isexistholidays",method = RequestMethod.GET)
        public @ResponseBody String[] isexistholidays(HttpServletRequest request,Principal user,@RequestParam("value") String value,@RequestParam("id") String id){
        	String[]  holidays = userDao.isExistHoliday(value,id);
            return holidays;
        }
        @RequestMapping(value = "/viewholidays",method = RequestMethod.GET)
        public ModelAndView viewholidays(HttpServletRequest request,ModelAndView model,Principal user){
            model.addObject("username",userDao.getUserIcon(user));
            String isAdmin = "1";
            if(request.isUserInRole("ROLE_ADMIN")){
            	isAdmin = "0";
            }
            model.addObject("ListAllHolidays",userDao.listAllHolidays(isAdmin,user.getName()));
            model.setViewName("ViewHolidays");
            return model;
        }
        @RequestMapping(value = "/editholiday",method = RequestMethod.GET)
        public ModelAndView editholiday(HttpServletRequest request,ModelAndView model,RedirectAttributes redirectAttributes,@RequestParam("id") int id,Principal user){
            redirectAttributes.addFlashAttribute("editholiday",userDao.editHoliday(id));
            redirectAttributes.addFlashAttribute("addorupdate","Update");
            model.setViewName("redirect:/addholiday");
            return model;
        }
        @RequestMapping(value = "deleteholiday",method = RequestMethod.GET)
        public ModelAndView deleteholiday(@RequestParam("id") int id,ModelAndView model,RedirectAttributes redirectAttributes){
            redirectAttributes.addFlashAttribute("deleteStatus",userDao.deleteHoliday(id));
            model.setViewName("redirect:/viewholidays");
            return model;
        }
        /*************************Apply Leave**************************/
        @RequestMapping(value = "/saveleave",method = RequestMethod.POST)
        public ModelAndView saveleave(HttpServletRequest request,ModelAndView model,ApplyLeave applyLeave,Principal user,RedirectAttributes redirectAttributes){
            redirectAttributes.addFlashAttribute("saveStatus",userDao.saveLeave(applyLeave,user.getName()));
            model.setViewName("redirect:/dashboard");
            return model;
        }
        @RequestMapping(value = "/viewleaves",method = RequestMethod.GET)
        public ModelAndView viewleaves(HttpServletRequest request,ModelAndView model,Principal user){
            model.addObject("username",userDao.getUserIcon(user));
            model.addObject("ListAllLeaves",userDao.listAllLeaves(user.getName()));
            model.setViewName("ViewLeaves");
            return model;
        }
        @RequestMapping(value = "/editLeave",method = RequestMethod.GET)
        public @ResponseBody ApplyLeave editLeave(@RequestParam("id") int id){
            ApplyLeave listLeave = userDao.editLeave(id);
            return listLeave;
        }
        @RequestMapping(value = "/cancelLeave",method = RequestMethod.GET)
        public ModelAndView cancelLeave(@RequestParam("id") int id,ModelAndView model,RedirectAttributes redirectAttributes){
            redirectAttributes.addFlashAttribute("deleteStatus",userDao.cancelLeave(id));
            model.setViewName("redirect:/dashboard");
            return model;
        }
        @RequestMapping(value = "/rejectleave",method = RequestMethod.GET)
        public ModelAndView rejectleave(@RequestParam("id") int id,ModelAndView model,RedirectAttributes redirectAttributes){
            redirectAttributes.addFlashAttribute("deleteStatus",userDao.rejectleave(id));
            System.out.println(userDao.rejectleave(id)[0]);
            System.out.println(userDao.rejectleave(id)[1]);
            model.setViewName("redirect:/home");
            return model;
        }
        @RequestMapping(value = "/approveleave",method = RequestMethod.GET)
        public ModelAndView approveleave(@RequestParam("id") int id,ModelAndView model,RedirectAttributes redirectAttributes){
            redirectAttributes.addFlashAttribute("deleteStatus",userDao.approveleave(id));
            System.out.println(userDao.rejectleave(id)[0]);
            System.out.println(userDao.rejectleave(id)[1]);
            model.setViewName("redirect:/home");
            return model;
        }
        @RequestMapping(value = "/viewleavesreport",method = RequestMethod.GET)
        public ModelAndView viewleavesreport(HttpServletRequest request,ModelAndView model,RedirectAttributes redirectAttributes,Principal user){           
            model.addObject("username",userDao.getUserIcon(user));
            model.addObject("AllLeaveTypes",userDao.listAllLeaveTypes(user.getName()));
            model.addObject("dashGetLeaveTypesWithValidation",userDao.dashGetLeaveTypesWithValidation(user.getName()));
            model.setViewName("ViewLeavesReport");
            return model;
        }
        @RequestMapping(value = "/viewleavesreports",method = RequestMethod.POST)
        public ModelAndView viewleavesreportpost(HttpServletRequest request,ModelAndView model,RedirectAttributes redirectAttributes,Principal username){ 
            redirectAttributes.addFlashAttribute("viewleavesreport",userDao.listLeavesReport(username.getName(),Integer.parseInt(request.getParameter("leaveType")),request.getParameter("status"),request.getParameter("leaveFrom"),request.getParameter("leaveTo")));
            String[] str = {request.getParameter("leaveType"),request.getParameter("status"),request.getParameter("leaveFrom"),request.getParameter("leaveTo")};
            redirectAttributes.addFlashAttribute("datefields",str);
            model.setViewName("redirect:/viewleavesreport");
            return model;
        }
        @RequestMapping(value = "/viewallleavesadmin",method = RequestMethod.GET)
        public ModelAndView viewallleavesadmin(HttpServletRequest request,ModelAndView model,RedirectAttributes redirectAttributes,Principal user){           
            model.addObject("username",userDao.getUserIcon(user));
            String isAdmin = "SA";
            if(request.isUserInRole("ROLE_ADMIN")){
                isAdmin = "A";
            }
            model.addObject("AllLeaveAdmin",userDao.listAllLeavesAdmin(user.getName(),isAdmin));
            model.setViewName("ViewLeavesAdmin");
            return model;
        }
        @RequestMapping(value = "/leavetypescategory",method = RequestMethod.GET)
        public @ResponseBody List<LeaveTypes> LeaveTypesCategory(@RequestParam("category") String category){
            List<LeaveTypes> listAllLeaveTypesCategory= userDao.listAllLeaveTypesBasedOnCategory(category);
            return listAllLeaveTypesCategory;
        }
        
        @RequestMapping(value = "/viewleavesreportadmin",method = RequestMethod.GET)
        public ModelAndView viewleavesreportadmin(HttpServletRequest request,ModelAndView model,RedirectAttributes redirectAttributes,Principal user){           
            model.addObject("username",userDao.getUserIcon(user));
            String isAdmin = "SA";
            if(request.isUserInRole("ROLE_ADMIN")){
                isAdmin = "A";
            }
            model.addObject("AllLeaveTypes",userDao.listAllCategoryWithMainCategory(user.getName(),isAdmin));
            model.addObject("admins",isAdmin);
            model.setViewName("ViewLeavesReportAdmin");
            return model;
        }
        @RequestMapping(value = "/viewleavesreportsadmin",method = RequestMethod.POST)
        public ModelAndView viewleavesreportsadmin(HttpServletRequest request,ModelAndView model,RedirectAttributes redirectAttributes,Principal username){ 
            redirectAttributes.addFlashAttribute("viewleavesreport",userDao.listAllLeavesAdminReport(request.getParameter("category"),Integer.parseInt(request.getParameter("leaveType")),request.getParameter("status"),request.getParameter("leaveFrom"),request.getParameter("leaveTo")));
            String[] str = {request.getParameter("leaveType"),request.getParameter("status"),request.getParameter("leaveFrom"),request.getParameter("leaveTo"),request.getParameter("category")};
            redirectAttributes.addFlashAttribute("datefields",str);
            redirectAttributes.addFlashAttribute("isPost","post");
            model.setViewName("redirect:/viewleavesreportadmin");
            return model;
        }
        
        /*************************OJF********************************/
        @RequestMapping(value = "/addojfgeneral",method = RequestMethod.GET)
        public ModelAndView addojfgeneral(HttpServletRequest request,ModelAndView model,Principal user){
            model.addObject("ojfGeneralDataSession",userDao.expatSpecificDetails(user.getName()));
            model.setViewName("OJFAddExpatriate");
            return model;
        }
        @RequestMapping(value = "/isexistojf",method = RequestMethod.GET)
        public @ResponseBody String[] isexistojf(@RequestParam("value") String username){
            String[]  ojf = userDao.isExistOJF(username);
            return ojf;
        }
        @RequestMapping(value = "/saveojfgeneral",method = RequestMethod.POST)
        public ModelAndView saveojfgeneral(HttpServletRequest request,ModelAndView model,Principal user,RedirectAttributes redirectAttributes,Principal username,OJFGeneral oJFGeneral,@RequestParam("submission") int issubmit){ 
            redirectAttributes.addFlashAttribute("saveStatus",userDao.saveOJFByExpat(oJFGeneral,user.getName(),issubmit));
            if(request.isUserInRole("ROLE_ADMIN") || request.isUserInRole("ROLE_SADMIN") || request.isUserInRole("ROLE_USER")){
            	model.setViewName("redirect:/viewlistallojf");
            }else{
            	model.setViewName("redirect:/addojfgeneral");
            }
            return model;
        }
        @RequestMapping(value = "/confidential",method = RequestMethod.GET)
        public ModelAndView confidential(HttpServletRequest request,ModelAndView model,Principal user){
            model.addObject("ojfGeneralDataSession",userDao.expatSpecificDetails(user.getName()));
            model.setViewName("OJFConfidential");
            return model;
        }
        @RequestMapping(value = "/ojfidcard",method = RequestMethod.GET)
        public ModelAndView ojfidcard(HttpServletRequest request,ModelAndView model,Principal user){
            model.addObject("ojfGeneralDataSession",userDao.expatSpecificDetails(user.getName()));
            model.setViewName("OJFIDCard");
            return model;
        }
}