package controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import dao.SecondDAO;
@Controller
@RequestMapping(value = "/")
public class newController {
        @Autowired private SecondDAO secondDAO;
        /*
        *@Module Init
        */
        @RequestMapping(value = "/newpage",method = RequestMethod.GET)
        public ModelAndView empty(HttpServletRequest request,ModelAndView model){
            model.setViewName("redirect:/home");
            secondDAO.simpleSOUT();
            return model;
        }
        
}