/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package daoImpl;
import javax.sql.DataSource;

import dao.SecondDAO;

/**
 *
 * @author z015675
 */
public class SecondDAOImpl implements SecondDAO{
    private final DataSource dataSource;
    public SecondDAOImpl(DataSource dataSource) {
        this.dataSource = dataSource;
    }
    @Override
    public void simpleSOUT(){
        System.out.println("#################3");
    }
}
