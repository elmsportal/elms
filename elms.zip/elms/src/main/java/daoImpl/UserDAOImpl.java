package daoImpl;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.Principal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.sql.DataSource;

import model.ApplyLeave;
import model.Categories;
import model.Expatriate;
import model.Holidays;
import model.LeaveTypes;
import model.OJFGeneral;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.record.PageBreakRecord.Break;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.web.multipart.MultipartFile;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;

import dao.UserDAO;

/**
 *
 * @author z015675
 */
public class UserDAOImpl implements UserDAO {
	private final DataSource dataSource;
	final static Logger logger = Logger.getLogger(UserDAOImpl.class);

    public UserDAOImpl(DataSource dataSource) {
        this.dataSource = dataSource;
    }
    //Dashboard Admin
     
    @Override
    public String dashGetExpatriatesCount(){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "SELECT COUNT(*) FROM users WHERE authority = 'ROLE_USER' AND enabled = 1";
        logger.info(sql);
        int leaveTypesCounts = jdbcTemplate.queryForInt(sql);
        String leaveTypesCount = leaveTypesCounts+"";
        if(leaveTypesCounts < 10 && leaveTypesCounts > 0){
           leaveTypesCount  = "0"+leaveTypesCount;
        }
        return leaveTypesCount;
    }
    @Override
    public String dashGetLeaveTypesCount(String isAdmin, String username){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String subQuery = "";
        if(!isAdmin.equals("1")){
        	subQuery = "WHERE t2.id=(SELECT main_category FROM user_details WHERE zid='"+username+"')";
        }
        String sql = "SELECT SUM(cat) AS leave_types FROM category AS t1 LEFT JOIN (SELECT id FROM main_categories ) AS t2 ON t1.main_category = t2.id LEFT JOIN (SELECT COUNT(leave_type) AS cat,category AS ca  FROM leave_types GROUP BY category) AS t3 ON t3.ca = t1.id "+subQuery;
        logger.info(sql);
        int leaveTypesCounts = jdbcTemplate.queryForInt(sql);
        String leaveTypesCount = leaveTypesCounts+"";
        if(leaveTypesCounts < 10 && leaveTypesCounts > 0){
           leaveTypesCount  = "0"+leaveTypesCount;
        }
        return leaveTypesCount;
    }
    @Override
    public String dashGetAdminCount(){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "SELECT COUNT(*) FROM users WHERE authority = 'ROLE_ADMIN' OR authority = 'ROLE_SADMIN'";
        logger.info(sql);
        int leaveTypesCounts = jdbcTemplate.queryForInt(sql);
        String leaveTypesCount = leaveTypesCounts+"";
        if(leaveTypesCounts < 10 && leaveTypesCounts > 0){
           leaveTypesCount  = "0"+leaveTypesCount;
        }
        return leaveTypesCount;
    }
    @Override
    public String dashGetLeaveCount(String username){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        Date date = new Date();
        Calendar calendar = new GregorianCalendar();
        calendar.setTime(date);
        //int year = calendar.get(Calendar.YEAR);
        //int month = calendar.get(Calendar.MONTH) + 1;//int day = calendar.get(Calendar.DAY_OF_MONTH);
        String sql = "SELECT COUNT(leave_count) FROM leave_maintenance WHERE applied_on >= (SELECT last_login FROM user_details WHERE zid='"+username+"')";
        logger.info(sql);
        int leaveCounts = jdbcTemplate.queryForInt(sql);
        String leaveCount = leaveCounts+"";
        if(leaveCounts < 10 && leaveCounts > 0){
           leaveCount  = "0"+leaveCount;
        }
        return leaveCount;
    }
    @Override
    public String dashGetLeaveConditionCount(String leaveStatus){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        Date date = new Date();
        Calendar calendar = new GregorianCalendar();
        calendar.setTime(date);
        int year = calendar.get(Calendar.YEAR);
        String sql = "SELECT SUM(leave_count) FROM leave_maintenance WHERE leave_approval_status = '"+leaveStatus+"' AND applied_on > STR_TO_DATE('"+year+"-1-1','%Y-%m-%d')";
        logger.info(sql);
        int leaveCounts = jdbcTemplate.queryForInt(sql);
        String leaveCount = leaveCounts+"";
        if(leaveCounts < 10 && leaveCounts > 0){
           leaveCount  = "0"+leaveCount;
        }
        return leaveCount;
        
    }
    @Override
    public String dashGetLeaveConditionCount(int leaveStatus,String username){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String validate = "<";
        if(leaveStatus == 1){
            validate = ">";
        }
        String sql = "SELECT SUM(leave_count) as counts FROM leave_maintenance WHERE str_to_date(leave_from,'%Y-%m-%d') "+validate+" str_to_date(NOW(),'%Y-%m-%d') AND emp_zid='"+username+"' AND (leave_approval_status = 0 OR leave_approval_status = 1)";
        logger.info(sql);
        int leaveCounts = jdbcTemplate.queryForInt(sql);
        String leaveCount = leaveCounts+"";
        if(leaveCounts < 10 && leaveCounts > 0){
           leaveCount  = "0"+leaveCount;
        }
        return leaveCount;
        
    }
    @Override
    public int dashboardAdmingetMinimumMonth(){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String minimumYear = "SELECT IFNULL(MIN(YEAR(assignment_from)),YEAR(NOW())) AS years FROM user_details";
        logger.info(minimumYear);
        int minYear = jdbcTemplate.queryForInt(minimumYear);
        return minYear;
    }
    @Override
    public List<Object> dashGetChartExpatrates(String year,int month,String username,String usertype){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String mainCategories = "SELECT main_category FROM main_categories WHERE status = 1 ";
        logger.info(mainCategories);
        List<String> getMainCategories = jdbcTemplate.query(mainCategories, new RowMapper<String>() {
            @Override
            public String mapRow(ResultSet rs, int i) throws SQLException {
                String str = rs.getString("main_category");
                return str;
            }
        });
        String subCategories = "SELECT category FROM category WHERE status = 1 GROUP BY category";
        logger.info(subCategories);
        List<String> getSubCategories = jdbcTemplate.query(subCategories, new RowMapper<String>() {
            @Override
            public String mapRow(ResultSet rs, int i) throws SQLException {
                String str = rs.getString("category");
                return str;
            }
        });
        List<Object> wholearr  = new ArrayList<Object>();
        String[] colorsArrayMC = {"#4389bc","#50c550","#ffb366","#b862ca"};
        List<String> colorsArraySC = new ArrayList<String>();
        colorsArraySC.add("#00bdd2");
        colorsArraySC.add("#f78aff");
        if(usertype.equals("SA")){
	        for(int i=0;i< getMainCategories.size();i++){
	            int[] arrayOfData = {0,0,0,0,0,0,0,0,0,0,0,0};
	            String name = getMainCategories.get(i);
	            String stack = "MC";
	            String color = colorsArrayMC[i];
	            /*********************get data***********************/
	            for(int j=1;j<(month+1);j++){
	                String sql = "SELECT COUNT(mc) AS counts,mc FROM user_details AS t1 LEFT JOIN (SELECT enabled,username FROM users) AS t2 ON t1.zid = t2.username LEFT JOIN (SELECT main_category AS mc,id FROM main_categories) AS t3 ON t1.main_category = t3.id WHERE STR_TO_DATE(assignment_from,'%Y-%m-%d') <= STR_TO_DATE('"+year+"-"+j+"-31','%Y-%m-%d') AND STR_TO_DATE(t1.assignment_to,'%Y-%m-%d') > STR_TO_DATE('"+year+"-"+j+"-31','%Y-%m-%d') GROUP BY mc ORDER BY mc;";
	                logger.info(sql);
	                List<String[]> listChartExpatriate = jdbcTemplate.query(sql,new RowMapper<String[]>(){
	                    @Override
	                    public String[] mapRow(ResultSet rs,int ind) throws SQLException{
	                        String[] str = {rs.getString("counts"),rs.getString("mc")};
	                        return str;
	                    }
	                });
	                if(!listChartExpatriate.isEmpty()){
	                    for(int k = 0;k< listChartExpatriate.size();k++){
	                        if(listChartExpatriate.get(k)[1].equals(getMainCategories.get(i))){
	                            arrayOfData[j-1] = Integer.parseInt(listChartExpatriate.get(k)[0]);
	                        }
	                    }
	                }
	            }
	            Map<String,Object> arr  = new HashMap<String, Object>();
	            arr.put("color",color);
	            arr.put("data", arrayOfData);
	            arr.put("name", name);
	            arr.put("stack", stack);
	            wholearr.add(arr);
	        }
        }
        /**************************************Based on sub category*****************************************/
        for(int i=0;i< getSubCategories.size();i++){
            int[] arrayOfData = {0,0,0,0,0,0,0,0,0,0,0,0};
            String name = getSubCategories.get(i);
            String stack = "SC";
            String color;
            if(name.toLowerCase().equals("Nissan".toLowerCase())){
                color = "#d44660";
            }else if(name.toLowerCase().equals("Renault".toLowerCase())){
                color = "#e8d80d";
            }else{
                color = colorsArraySC.get(0);
                colorsArraySC.remove(0);
            }
       
            /*********************get data***********************/
            for(int j=1;j<(month+1);j++){
            	String subQuery  = "";
            	if(!usertype.equals("SA")){
            		subQuery = " WHERE main_category = (SELECT main_category FROM user_details WHERE zid='"+username+"')";
            	}
                String sql = "SELECT COUNT(mc) AS counts,mc FROM user_details AS t1 LEFT JOIN (SELECT enabled,username FROM users) AS t2 ON t1.zid = t2.username LEFT JOIN (SELECT category AS mc,id FROM category"+subQuery+") AS t3 ON t1.category = t3.id  WHERE STR_TO_DATE(assignment_from,'%Y-%m-%d') <= STR_TO_DATE('"+year+"-"+j+"-31','%Y-%m-%d') AND STR_TO_DATE(t1.assignment_to,'%Y-%m-%d') > STR_TO_DATE('"+year+"-"+j+"-31','%Y-%m-%d') AND t2.enabled = 1 AND mc != '' GROUP BY mc ORDER BY mc;;";
                logger.info(sql);
                List<String[]> listChartExpatriate = jdbcTemplate.query(sql,new RowMapper<String[]>(){
                    @Override
                    public String[] mapRow(ResultSet rs,int ind) throws SQLException{
                        String[] str = {rs.getString("counts"),rs.getString("mc")};
                        return str;
                    }
                });
                if(!listChartExpatriate.isEmpty()){
                    for(int k = 0;k< listChartExpatriate.size();k++){
                        if(listChartExpatriate.get(k)[1].equals(getSubCategories.get(i))){
                            arrayOfData[j-1] = Integer.parseInt(listChartExpatriate.get(k)[0]);
                        }
                    }
                }
            }
            Map<String,Object> arr  = new HashMap<String, Object>();
            arr.put("color",color);
            arr.put("data", arrayOfData);
            arr.put("name", name);
            arr.put("stack", stack);
            wholearr.add(arr);
        }
        
        return wholearr;
    }
    @Override
    public int upcomingLeaves(String username,String adminOrSuperadmin){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String subQuery = "";
        // if adminOrSuperadmin is zero the role is admin or super admin
        if(adminOrSuperadmin.equals("0")){
            subQuery = "main_category=(SELECT main_category FROM user_details WHERE zid='"+username+"') AND ";
        }
        String sql = "SELECT COUNT(emp_zid) AS counts FROM (SELECT *,zid AS zids FROM leave_maintenance AS t1 LEFT JOIN (SELECT zid FROM user_details WHERE "+subQuery+" category != '') AS t2 ON t1.emp_zid = t2.zid) AS  leave_maintenance1 WHERE STR_TO_DATE(leave_from,'%Y-%m-%d') > STR_TO_DATE(NOW(),'%Y-%m-%d')  AND (leave_approval_status = 0  OR leave_approval_status = 1) AND zids !='';";
        logger.info(sql);
        int msg = jdbcTemplate.queryForInt(sql);
        return msg;
    }
    @Override
    public int peopleInLeave(String username,String adminOrSuperadmin){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String subQuery = "";
        // if adminOrSuperadmin is zero the role is admin or super admin
        if(adminOrSuperadmin.equals("0")){
            subQuery = "main_category=(SELECT main_category FROM user_details WHERE zid='"+username+"') AND ";
        }
        String sql = "SELECT COUNT(DISTINCT emp_zid) AS counts FROM (SELECT *,zid AS zids FROM leave_maintenance AS t1 LEFT JOIN (SELECT zid FROM user_details  WHERE "+subQuery+" category != '') AS t2 ON t1.emp_zid = t2.zid) AS  leave_maintenance1 WHERE STR_TO_DATE(leave_from,'%Y-%m-%d') <= STR_TO_DATE(NOW(),'%Y-%m-%d')  AND STR_TO_DATE(leave_to,'%Y-%m-%d') >= STR_TO_DATE(NOW(),'%Y-%m-%d') AND (leave_approval_status = 1 OR leave_approval_status = 0 ) AND zids !=''";
        logger.info(sql);
        int msg = jdbcTemplate.queryForInt(sql);
        return msg;
    }
    @Override
    public int upcomingTrips(String username,String adminOrSuperadmin){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String subQuery = "";
        // if adminOrSuperadmin is zero the role is admin or super admin
        if(adminOrSuperadmin.equals("0")){
            subQuery = "main_category=(SELECT main_category FROM user_details WHERE zid='"+username+"') AND ";
        }
        String sql = "SELECT COUNT(emp_zid) AS counts FROM (SELECT *,zid AS zids FROM leave_maintenance AS t1 LEFT JOIN (SELECT zid FROM user_details  WHERE "+subQuery+" category != '') AS t2 ON t1.emp_zid = t2.zid) AS  leave_maintenance1 WHERE STR_TO_DATE(leave_from,'%Y-%m-%d') > STR_TO_DATE(NOW(),'%Y-%m-%d')  AND leave_approval_status = 4 AND zids !='';";
        logger.info(sql);
        int msg = jdbcTemplate.queryForInt(sql);
        return msg;
    }
    @Override
    public int peopleinTrips(String username,String adminOrSuperadmin){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String subQuery = "";
        // if adminOrSuperadmin is zero the role is admin or super admin
        if(adminOrSuperadmin.equals("0")){
            subQuery = "main_category=(SELECT main_category FROM user_details WHERE zid='"+username+"') AND ";
        }
        String sql = "SELECT COUNT(DISTINCT emp_zid) AS counts FROM (SELECT *,zid AS zids FROM leave_maintenance AS t1 LEFT JOIN (SELECT zid FROM user_details  WHERE "+subQuery+" category != '') AS t2 ON t1.emp_zid = t2.zid) AS  leave_maintenance1 WHERE STR_TO_DATE(leave_from,'%Y-%m-%d') <= STR_TO_DATE(NOW(),'%Y-%m-%d')  AND STR_TO_DATE(leave_to,'%Y-%m-%d') >= STR_TO_DATE(NOW(),'%Y-%m-%d') AND leave_approval_status = 4 AND zids !='';";
        logger.info(sql);
        int msg = jdbcTemplate.queryForInt(sql);
        return msg;
    }
    
    @Override
    public List<Object> dashGetChartExpatratesLeaves(String username,String maincategory,String from,String till,String isadmin){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String subQuery = "";
        if(isadmin.equals("SA")){
        	subQuery = "AND main_category='"+maincategory+"'";
        }else{
        	subQuery = "AND main_category=(SELECT main_category FROM user_details WHERE zid='"+username+"')";
        }
        String subCategories = "SELECT category FROM category WHERE status = 1 "+subQuery;
        logger.info(subCategories);
        List<String> getCategories = jdbcTemplate.query(subCategories, new RowMapper<String>() {
            @Override
            public String mapRow(ResultSet rs, int i) throws SQLException {
                String str = rs.getString("category");
                return str;
            }
        });
        if(isadmin.equals("A")){
            maincategory = "t5.main_category = (SELECT main_category FROM user_details WHERE zid='"+username+"') AND ";
        }else{
        	maincategory = "t5.main_category = '"+maincategory+"' AND ";
        }
        String getallLeaves = "SELECT category,IFNULL(sums,0) AS sums,IFNULL(lf,-1) as leave_froms FROM category AS t5 LEFT JOIN (SELECT count(distinct emp_zid) AS sums,cat,main_category,MONTH(leave_from) as lf,leave_from FROM leave_maintenance AS t2 LEFT JOIN (SELECT zid,category,main_category FROM user_details) AS t1 ON t1.zid = t2.emp_zid LEFT JOIN (SELECT category AS cat,id FROM category) AS t3 ON t1.category = t3.id GROUP BY lf) AS t6 ON t5.category = t6.cat WHERE "+maincategory+" lf != -1 AND STR_TO_DATE(t6.leave_from,'%Y-%m-%d') > STR_TO_DATE('"+from+"','%Y-%m-%d') AND STR_TO_DATE(t6.leave_from,'%Y-%m-%d') < STR_TO_DATE('"+till+"','%Y-%m-%d')";
        logger.info(getallLeaves);
        List<String[]> getValues = jdbcTemplate.query(getallLeaves, new RowMapper<String[]>() {
            @Override
            public String[] mapRow(ResultSet rs, int i) throws SQLException {
                String[] str = {rs.getString("category"),rs.getString("sums"),rs.getString("leave_froms")};
                return str;
            }
        });
        List<String> colorsArraySC = new ArrayList<String>();
        colorsArraySC.add("#00bdd2");
        colorsArraySC.add("#f78aff");
        List<Object> wholearr  = new ArrayList<Object>();
        for(int i =0;i<getCategories.size();i++){
            String name = getCategories.get(i);
            int[] arrayOfValues = {0,0,0,0,0,0,0,0,0,0,0,0};
            String color;
            if(name.toLowerCase().equals("Nissan".toLowerCase())){
                color = "#d44660";
            }else if(name.toLowerCase().equals("Renault".toLowerCase())){
                color = "#e8d80d";
            }else{
                color = colorsArraySC.get(0);
                colorsArraySC.remove(0);
            }
            for(int j=0;j<getValues.size();j++){
                if(getValues.get(j)[0].equals(name)){
                    int months = Integer.parseInt(getValues.get(j)[2]);
                    arrayOfValues[months] = Integer.parseInt(getValues.get(j)[1]);
                }
            }
            Map<String,Object> arr  = new HashMap<String, Object>();
            arr.put("color", color);
            arr.put("data", arrayOfValues);
            arr.put("name", name);
            wholearr.add(arr);
        }
        return wholearr;
    }
    
    @Override
    public Map<String,String[][]> dashGetChartLeaveTypes(){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String Catogories = "SELECT DISTINCT category FROM user_details GROUP BY category";
        logger.info(Catogories);
        List<String> getAllAvailableCategories = jdbcTemplate.query(Catogories, new RowMapper<String>() {
            @Override
            public String mapRow(ResultSet rs, int i) throws SQLException {
                String str = rs.getString("category");
                return str;
            }
        });
        String sql = "SELECT MONTH(added_on) AS months,COUNT(DISTINCT id) AS count,category FROM leave_types WHERE YEAR(added_on)= YEAR(now()) GROUP BY months,category";
        logger.info(sql);
        List<String[]> listChartLeaveTypes = jdbcTemplate.query(sql,new RowMapper<String[]>(){
            @Override
            public String[] mapRow(ResultSet rs,int ind) throws SQLException{
                String[] str = {rs.getString("months"),rs.getString("count"),rs.getString("category")};
                return str;
            }
        });
        String[] MonthsArray = {"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
        int typesCount = 1;
        if(!getAllAvailableCategories.isEmpty()){
            typesCount = getAllAvailableCategories.size();
        }
        String[][] Types = new String[1][typesCount];
        String[][] Months = new String[12][typesCount+1];
        for(int i = 0; i < 12;i++){
            Months[i][0] = MonthsArray[i];
            for(int j=0; j<typesCount;j++){
                Months[i][j+1] = "0";
                if(!getAllAvailableCategories.isEmpty()){
                    Types[0][j] = getAllAvailableCategories.get(j);
                }
            }
        }
        if(!getAllAvailableCategories.isEmpty()){
            int i = 0;
            for(String category : getAllAvailableCategories){
                for (String[] leaveTypeList : listChartLeaveTypes) {
                    if(leaveTypeList[2].equals(category)){
                        Months[Integer.parseInt(leaveTypeList[0])-1][i+1] = leaveTypeList[1];
                    }
                }
                i = i+1;
            }
        }
        Map<String,String[][]> ExpatriatesChart = new HashMap<String, String[][]>();
        ExpatriatesChart.put("Data", Months);
        ExpatriatesChart.put("Types", Types);
        return ExpatriatesChart;
    }
    @Override
    public List<String[]> getHolidaysCalendar(){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "SELECT holiday_date,holiday_name,MONTH(holiday_date) as months,substring(holiday_date,9) as dates,holiday_description FROM holidays";
        logger.info(sql);
        List<String[]> listHolidays = jdbcTemplate.query(sql,new RowMapper<String[]>(){
            @Override
            public String[] mapRow(ResultSet rs,int ind) throws SQLException{
                String[] str = {rs.getString("holiday_name"),rs.getString("months"),rs.getString("dates"),rs.getString("holiday_description"),rs.getString("holiday_date")};
                return str;
            }
        });
        return listHolidays;
    }
    @Override
    public List<Categories> listAllCategoryWithMainCategory(String username,String isAdminOrSuperadmin){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String subQuery = "";
        if(isAdminOrSuperadmin.equals("A")){
            subQuery = " AND t1.main_category = (SELECT main_category FROM user_details WHERE zid='"+username+"')";
        }
        String sql = "SELECT t1.id,t1.category,t2.mc FROM category AS t1 LEFT JOIN (SELECT main_category AS mc,id AS ids FROM main_categories) AS t2 ON t1.main_category = t2.ids WHERE t1.id != -1"+subQuery;
        logger.info(sql);
        List<Categories> listMainCategories = jdbcTemplate.query(sql,new RowMapper<Categories>(){
            @Override
            public Categories mapRow(ResultSet rs,int ind) throws SQLException{
                Categories categories = new Categories();
                categories.setId(rs.getInt("id"));
                categories.setMainCategory(rs.getString("mc"));
                categories.setCategory(rs.getString("category"));
                return categories;
            }
        });
        return listMainCategories;
    }
    /*********************Dashboard users***************************/
    @Override
    public int statusCheck(String username, int status) {
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "SELECT IFNULL(SUM(leave_count),0) FROM leave_maintenance where emp_zid=? and leave_approval_status=?";
        logger.info(sql);
        int msg = jdbcTemplate.queryForInt(sql,username,status);
        return msg;
    }
    @Override
    public int appliedLeave(String username) {
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "SELECT IFNULL(SUM(leave_count),0) FROM leave_maintenance WHERE (leave_approval_status = 0 OR leave_approval_status = 1) AND emp_zid=?";
        logger.info(sql);
        int msg = jdbcTemplate.queryForInt(sql,username);
        return msg;
    }
    @Override
    public List<String[]> dashGetCategorywiseLEaveCount(String username){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "SELECT t1.id,t1.leave_type,t1.color,t1.icon,t1.max_count, IFNULL(t2.counts,0) AS counts,IFNULL(t2.leavetotal,0) AS totals,IFNULL(befores,0) AS befores,IFNULL(afters,0) AS afters,deduct FROM leave_types AS t1 LEFT JOIN (SELECT COUNT(*) AS counts,SUM(leave_count) as leavetotal,leave_type,emp_zid FROM leave_maintenance WHERE emp_zid='"+username+"' AND (leave_approval_status =0 OR leave_approval_status = 1) GROUP BY leave_type) AS t2 ON t1.id = t2.leave_type LEFT JOIN (SELECT SUM(leave_count) AS befores,leave_type AS lt FROM leave_maintenance WHERE str_to_date(leave_from,'%Y-%m-%d') < str_to_date(NOW(),'%Y-%m-%d') AND emp_zid='"+username+"' AND (leave_approval_status =0 OR leave_approval_status = 1) GROUP BY leave_type) AS t3 ON t3.lt=t1.id LEFT JOIN (SELECT sum(leave_count) AS afters,leave_type AS lt FROM leave_maintenance WHERE str_to_date(leave_from,'%Y-%m-%d') > str_to_date(NOW(),'%Y-%m-%d') AND emp_zid='"+username+"' AND (leave_approval_status =0 OR leave_approval_status = 1) GROUP BY leave_type) AS t4 ON t4.lt=t1.id WHERE t1.category=(SELECT category FROM user_details WHERE zid='"+username+"') ORDER BY t1.leave_type";
        logger.info(sql);
        List<String[]> listcategoryBasedresult = jdbcTemplate.query(sql,new RowMapper<String[]>(){
            @Override
            public String[] mapRow(ResultSet rs,int ind) throws SQLException{
                String[] result={rs.getString("id"),rs.getString("leave_type"),rs.getString("counts"),rs.getString("totals"),rs.getString("color"),rs.getString("icon"),rs.getString("max_count"),rs.getString("befores"),rs.getString("afters"),rs.getString("deduct")};
                return  result;
            }
        });
        return listcategoryBasedresult;
    }
    @Override
    public String dashGetTotalAvailableLeave(String username){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "SELECT IFNULL((count - (SELECT IFNULL(SUM(leave_count),0) FROM leave_maintenance WHERE emp_zid='"+username+"' AND (leave_approval_status = 0 OR leave_approval_status = 1))),0) AS balance FROM leave_balance WHERE zid='"+username+"' LIMIT 1;";
        logger.info(sql);
        int counts = jdbcTemplate.queryForInt(sql);
        String leaveCount = counts+"";
        if(counts < 10 && counts > 0){
           leaveCount  = "0"+leaveCount;
        }
        return leaveCount;
    }
    @Override
    public List<LeaveTypes> dashGetLeaveTypesWithValidation(String username){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "SELECT t1.*,IFNULL(lt,0) as lt FROM leave_types AS t1 LEFT JOIN (SELECT COUNT(leave_type) AS lt,leave_type,emp_zid FROM leave_maintenance WHERE emp_zid='"+username+"'  AND (leave_approval_status = 0 OR leave_approval_status = 1) GROUP BY leave_type) AS t2 ON t1.id = t2.leave_type  WHERE t1.category=(SELECT category FROM user_details WHERE zid='"+username+"');";
        logger.info(sql);
        List<LeaveTypes> listLeaveTypes = jdbcTemplate.query(sql,new RowMapper<LeaveTypes>(){
            @Override
            public LeaveTypes mapRow(ResultSet rs,int ind) throws SQLException{
                LeaveTypes leaveTypes = new LeaveTypes();
                leaveTypes.setId(rs.getInt("id"));
                leaveTypes.setLeavetype(rs.getString("leave_type"));
                leaveTypes.setLeaveDetails(rs.getString("details"));
                leaveTypes.setColor(rs.getString("color"));
                leaveTypes.setIcon(rs.getString("icon"));
                leaveTypes.setMaxCount(rs.getString("max_count"));
                leaveTypes.setAllowedCount(rs.getString("allowed_count"));
                leaveTypes.setCategory(rs.getString("category"));
                leaveTypes.setAllowAfter(rs.getString("allow_after"));
                leaveTypes.setDeduct(rs.getString("deduct"));
                if(rs.getString("max_count").equals(rs.getString("lt"))){
                    leaveTypes.setDisabledCSS("disabled");
                }else{
                    leaveTypes.setDisabledCSS("");
                }
                
                return leaveTypes;
            }
        });
        return listLeaveTypes;
    }
    @Override
    public String[] dashGetUserStartEndDates(String username){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "SELECT assignment_from,assignment_to FROM user_details WHERE zid='"+username+"'";
        logger.info(sql);
        List<String[]> getUserYear = jdbcTemplate.query(sql,new RowMapper<String[]>(){
            @Override
            public String[] mapRow(ResultSet rs,int ind) throws SQLException{
                String[] str = {rs.getString("assignment_from"),rs.getString("assignment_to")};
                return str;
            }
        });
        return getUserYear.get(0);
    }
    @Override
    public List<String[]> getLeaveDays(String username){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "SELECT t1.leave_from,t1.leave_to,t2.leave_type,t2.icon,t2.color FROM leave_maintenance AS t1 LEFT JOIN (SELECT leave_type,id,icon,color FROM leave_types) AS t2 ON t1.leave_type = t2.id WHERE t1.emp_zid='"+username+"' AND (leave_approval_status = 0 OR leave_approval_status = 1)";
        logger.info(sql);
        List<String[]> getLeaveDays = jdbcTemplate.query(sql,new RowMapper<String[]>(){
            @Override
            public String[] mapRow(ResultSet rs,int ind) throws SQLException{
                String[] str = {rs.getString("leave_from"),rs.getString("leave_to"),rs.getString("leave_type"),rs.getString("icon"),rs.getString("color")};
                return str;
            }
        });
        return getLeaveDays;
    }
    @Override
    public List<String[]> getExpatriatesChart(String username){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "SELECT t1.leave_from,t1.leave_to,t2.leave_type,t2.color,t2.id FROM leave_maintenance AS t1 LEFT JOIN (SELECT leave_type,id,color FROM leave_types) AS t2 ON t1.leave_type = t2.id WHERE (t1.leave_approval_status = 0 OR t1.leave_approval_status = 1 OR t1.leave_approval_status = 4  OR t1.leave_approval_status = 5) AND YEAR(t1.leave_to) = YEAR(NOW()) AND emp_zid='"+username+"' ORDER BY t1.leave_from;";
        logger.info(sql);
        List<String[]> listChartExpatriate = jdbcTemplate.query(sql,new RowMapper<String[]>(){
            @Override
            public String[] mapRow(ResultSet rs,int ind) throws SQLException{
                String[] str = {rs.getString("leave_from"),rs.getString("leave_to"),rs.getString("leave_type"),rs.getString("color"),rs.getString("id")};
                return str;
            }
        });
        
        return listChartExpatriate;
    }
    /*************************Profile**************************/
    @Override
    public Expatriate profile(String username){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "SELECT t1.* ,DATE_FORMAT(t1.last_updated_date,'%d-%m-%Y') AS luo,DATE_FORMAT(t1.added_date,'%d-%m-%Y') AS addeddt,t2.*,t3.* FROM user_details AS t1 LEFT JOIN (SELECT username,authority,enabled FROM users) AS t2 on t1.zid = t2.username left join (select * from leave_balance where leave_type='Init') as t3 on t2.username = t3.zid WHERE t1.zid='"+username+"';";
        logger.info(sql);
        List<Expatriate> listExpatriate = jdbcTemplate.query(sql,new RowMapper<Expatriate>(){
            @Override
            public Expatriate mapRow(ResultSet rs,int ind) throws SQLException{
                Expatriate expatriate = new Expatriate();
                expatriate.setId(rs.getInt("id"));
                expatriate.setUsername(rs.getString("zid"));
                expatriate.setEmail(rs.getString("email"));
                expatriate.setFirstName(rs.getString("first_name"));
                expatriate.setLastName(rs.getString("last_name"));
                expatriate.setCategory(rs.getString("category"));
                expatriate.setDesignation(rs.getString("designation"));
                expatriate.setPicture(rs.getString("picture"));
                expatriate.setDepartment(rs.getString("department"));
                expatriate.setAssignmentFrom(rs.getString("assignment_from"));
                expatriate.setAssignmentTo(rs.getString("assignment_to"));
                expatriate.setAssignementDuration(rs.getString("assignment_duration"));
                expatriate.setApprovalManager(rs.getString("approval_manager"));
                expatriate.setApprovalManagerEmail(rs.getString("approval_manager_email"));
                expatriate.setRnNumber(rs.getString("rn_number"));
                expatriate.setHomeCountry(rs.getString("home_country"));
                expatriate.setLastUpdatedBy(rs.getString("last_updated_by"));
                expatriate.setLastUpdatedDate(rs.getString("luo"));
                expatriate.setAddedBy(rs.getString("added_by"));
                expatriate.setAddedDate(rs.getString("addeddt"));
                expatriate.setLeaveCount(rs.getString("count"));
                expatriate.setEnabled(rs.getString("enabled"));
                return expatriate;
            }
        });
        return listExpatriate.get(0);
    }
    
    /*************************OJF**************************/
    @Override
    public String[] saveOJF(Expatriate expatriate){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql1 ,sql2,AddORUpdate;
        String passcode = UUID.randomUUID().toString().substring(0, 8);
        sql1 = "INSERT INTO users(username,password,enabled,authority) VALUES(?,'"+passcode+"',1,'ROLE_OJF')";
        sql2 = "INSERT INTO ojf_general_details(email,userid,expatid,submission,status) VALUES(?,?,'0','0','1')";
        logger.info(sql1);
        logger.info(sql2);
        AddORUpdate = "Sav";
        String msg[] = {"",""};
        try {
            jdbcTemplate.update(sql1,expatriate.getUsername());
            jdbcTemplate.update(sql2,expatriate.getUsername(),expatriate.getUsername());
            msg[0] = "OJF Member Successfully "+AddORUpdate+"ed";
            msg[1] = "1";
            try{
            	msg = this.sendMailAdminAddOJF(expatriate.getUsername(),passcode);
            }catch(Exception exception){
            	msg[0] = "OJF Member Successfully "+AddORUpdate+"ed but some error occured while sending email.";
                msg[1] = "0";
            }
            
        } catch (Exception e) {
            msg[0] = "Some error occured in "+AddORUpdate+"ing OJF details , please try again!";
            msg[1] = "0";
            logger.info(e);
        }
        return msg;
    }
    @Override
    public String[] isExistOJF(String username){
    	JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "SELECT COUNT(username) FROM users WHERE LCASE(username)=LCASE('"+username+"')";
        logger.info(sql);
        
        String[] msg = {"",""};
        int counts = jdbcTemplate.queryForInt(sql);
    	if(counts > 0){
    		msg[0] = "0";
    		msg[1] = "Already exist!";
    	}else{
    		msg[0] = "1";
    		msg[1] = "";
    	}
        return msg;
    	
    }
    @Override
    public String[] resendOJFMail(String username){
    	JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "SELECT password,username FROM users WHERE username='"+username+"'";
        logger.info(sql);
        List<Expatriate> resendmail = jdbcTemplate.query(sql, new RowMapper<Expatriate>() {
            @Override
            public Expatriate mapRow(ResultSet rs, int i) throws SQLException {
            	Expatriate expatriate = new Expatriate();
            	expatriate.setFirstName(rs.getString("username"));
            	expatriate.setLastName(rs.getString("password"));
                return expatriate;
            }
        });
        Expatriate expatriate =  resendmail.get(0);
        String[] msg = {"",""};
        try{
        	msg = this.sendMailAdminAddOJF(expatriate.getUsername(),expatriate.getPassword());
        	
        }catch(Exception exception){
        	msg[0] = "Some error occured while sending email.";
            msg[1] = "0";
        }
        return msg;
    	
    }
    @Override
    public Expatriate addAsExpatriateOJF(String id){
    	JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
    	String sql = "SELECT id,first_name,last_name,userid,designation,department,superior_host_company_name,assignment_from,expatid,photo,assignment_to FROM ojf_general_details WHERE userid='"+id+"' ORDER BY userid DESC LIMIT 1";
    	logger.info(sql);
    	List<Expatriate> getOJFData = jdbcTemplate.query(sql,new RowMapper<Expatriate>(){
            @Override
            public Expatriate mapRow(ResultSet rs,int ind) throws SQLException{
                Expatriate expatriate = new Expatriate();
                expatriate.setFirstName(rs.getString("first_name"));
                expatriate.setLastName(rs.getString("last_name"));
                expatriate.setEmail(rs.getString("userid"));
                expatriate.setDesignation(rs.getString("designation"));
                expatriate.setDepartment(rs.getString("department"));
                expatriate.setApprovalManager(rs.getString("superior_host_company_name"));
                expatriate.setAssignmentFrom(rs.getString("assignment_from"));
                expatriate.setAssignmentTo(rs.getString("assignment_to"));
                expatriate.setExpatOJFid(rs.getString("expatid"));
                expatriate.setExpatBasicId(rs.getInt("id"));
                expatriate.setPicture(rs.getString("photo"));
                
                return expatriate;
            }
        });
    	return getOJFData.get(0);
    }
    @Override
    public List<Expatriate> listAllOJF(String username,String isAdmin){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String subQuery = "";
        if(isAdmin.equals("A")){
        	subQuery = " WHERE id = (SELECT main_category FROM user_details WHERE zid='"+username+"')";
        }
        String sql = "SELECT *,submission FROM users AS t1 LEFT JOIN (SELECT submission,userid,main_category as cat,expatid FROM ojf_general_details) AS t2 ON t1.username= t2.userid LEFT JOIN (SELECT main_category,id as ids from main_categories "+subQuery+") AS t3 ON t2.cat = t3.ids WHERE authority='ROLE_OJF' GROUP BY id ORDER BY id DESC";
        logger.info(sql);
        List<Expatriate> listAdmins = jdbcTemplate.query(sql,new RowMapper<Expatriate>(){
            @Override
            public Expatriate mapRow(ResultSet rs,int ind) throws SQLException{
                Expatriate expatriate = new Expatriate();
                expatriate.setId(rs.getInt("id"));
                expatriate.setEmail(rs.getString("username"));
                expatriate.setEnabled(rs.getString("enabled"));
                expatriate.setAssignementDuration(rs.getString("submission"));
                expatriate.setExpatOJFid(rs.getString("expatid"));
                return expatriate;
            }
        });
        return listAdmins;
    }
    
    @Override
    public String[] disableOJF(int id){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "UPDATE users SET enabled = '0' WHERE id="+id;
        logger.info(sql);
        String[] msg = {"",""};
        try{
           jdbcTemplate.execute(sql);
           msg[0] = "OJF Disabled Successfully!";
           msg[1] = "1";
        }catch(Exception e){
           msg[0] = "Some error occured, please try again !"; 
           msg[1] = "0";
        }
        return msg;
    }
    @Override
    public String[] enableOJF(int id){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "UPDATE users SET enabled = '1' WHERE id="+id;
        logger.info(sql);
        String[] msg = {"",""};
        try{
           jdbcTemplate.execute(sql);
           msg[0] = "OJF Enabled Successfully!";
           msg[1] = "1";
        }catch(Exception e){
           msg[0] = "Some error occured, please try again !"; 
           msg[1] = "0";
        }
        return msg;
    }
    @Override
    public String[] removeOJF(int id){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "DELETE users WHERE id="+id;
        String[] msg = {"",""};
        try{
           jdbcTemplate.execute(sql);
           msg[0] = "OJF Deleted Successfully!";
           msg[1] = "1";
        }catch(Exception e){
           msg[0] = "Some error occured, please try again !"; 
           msg[1] = "0";
        }
        return msg;
    }
    /****************Get Admin User Main Category*******************/
    @Override
    public String[] getAdminMainCategory(String username){
	    JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
	    String selectQuery = "SELECT t2.main_category AS mcname,t1.main_category AS mcid FROM user_details AS t1 LEFT JOIN (SELECT main_category,id FROM main_categories ) AS t2 ON t1.main_category = t2.id WHERE t1.zid = '"+username+"' LIMIT 1";
	    logger.info(selectQuery);
	    List<String[]> getMainCategory = jdbcTemplate.query(selectQuery, new RowMapper<String[]>() {
	        @Override
	        public String[] mapRow(ResultSet rs, int i) throws SQLException {
	            String[] getMainCategoryArray = {rs.getString("mcid"),rs.getString("mcname")};
	            return getMainCategoryArray;
	        }
	    });
	    return getMainCategory.get(0);
    }
    /*************************Main categories**************************/
    @Override
    public String[] savemainCategory(Categories categories,String username){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql;String AddORUpdate;
        if(categories.getId()== -1){
            sql = "INSERT INTO main_categories(main_category,description,location,added_by,added_on,status) VALUES(?,?,?,'"+username+"',NOW(),?);";
            AddORUpdate = "Sav";
            
        }else{
            sql = "UPDATE main_categories SET main_category=?,description=?,location=?,lastupdated_by='"+username+"',lastupdated_on=NOW(),status=? WHERE id="+categories.getId();
            AddORUpdate = "Updat";
        }
        logger.info(sql);
        String msg[] = {"",""};
        try {
            jdbcTemplate.update(sql,categories.getMainCategory(),categories.getMainCategoryDetails(),categories.getMainCategoryLocation(),categories.getStatus());
            msg[0] = "Main category Successfully "+AddORUpdate+"ed";
            msg[1] = "1";
        } catch (Exception e) {
            msg[0] = "Some error occured in "+AddORUpdate+"ing main category , please try again!";
            msg[1] = "0";
            logger.info(e);
        }
        return msg;
    }
    @Override
    public String[] isExistMC(String mcid,String id){
    	JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "SELECT COUNT(id) FROM main_categories WHERE LCASE(main_category) = LCASE('"+mcid+"') AND id !="+Integer.parseInt(id);
        logger.info(sql);
        String[] msg = {"",""};
        int counts = jdbcTemplate.queryForInt(sql);
        if(counts > 0){
    		msg[0] = "0";
    		msg[1] = "Already exist!";
    	}else{
    		msg[0] = "1";
    		msg[1] = "";
    	}
        return msg;
    	
    }
    @Override
    public List<Categories> listAllCategories(){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "SELECT * FROM main_categories ORDER BY id DESC;";
        logger.info(sql);
        List<Categories> listMainCategories = jdbcTemplate.query(sql,new RowMapper<Categories>(){
            @Override
            public Categories mapRow(ResultSet rs,int ind) throws SQLException{
                Categories categories = new Categories();
                categories.setId(rs.getInt("id"));
                categories.setMainCategory(rs.getString("main_category"));
                categories.setMainCategoryLocation(rs.getString("location"));
                categories.setMainCategoryDetails(rs.getString("description"));
                categories.setAddedBy(rs.getString("added_by"));
                categories.setAddedOn(rs.getString("added_on"));
                categories.setLastupdatedBy(rs.getString("lastupdated_by"));
                categories.setLastupdatedOn(rs.getString("lastupdated_on"));
                categories.setStatus(rs.getString("status"));
                return categories;
            }
        });
        return listMainCategories;
    }
    @Override
    public String[] disableMainCategory(int id){
    	JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "UPDATE main_categories SET status='0' WHERE id="+id;
        logger.info(sql);
        String[] msg = {"",""};
        try{
           jdbcTemplate.execute(sql);
           msg[0] = "Status changed successfully!";
           msg[1] = "1";
        }catch(Exception e){
           msg[0] = "Some error occured, please try again !"; 
           msg[1] = "0";
        }
        return msg;
    }
    @Override
    public String[] enableMainCategory(int id){
    	JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "UPDATE main_categories SET status='1' WHERE id="+id;
        logger.info(sql);
        String[] msg = {"",""};
        try{
           jdbcTemplate.execute(sql);
           msg[0] = "Status changed successfully!";
           msg[1] = "1";
        }catch(Exception e){
           msg[0] = "Some error occured, please try again !"; 
           msg[1] = "0";
        }
        return msg;
    }
    /*************************Main categories**************************/
    @Override
    public String[] saveSubCategory(Categories categories,String username){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql;String AddORUpdate;
        if(categories.getId()== -1){
            sql = "INSERT INTO category(main_category,category,added_by,added_on,status) VALUES(?,?,'"+username+"',NOW(),?);";
            AddORUpdate = "Sav";
            
        }else{
            sql = "UPDATE category SET main_category=?,category=?,lastupdated_by='"+username+"',lastupdated_on=NOW(),status=? WHERE id="+categories.getId();
            AddORUpdate = "Updat";
        }
        logger.info(sql);
        String msg[] = {"",""};
        try {
            jdbcTemplate.update(sql,categories.getMainCategory(),categories.getCategory(),categories.getStatus());
            msg[0] = "Category Successfully "+AddORUpdate+"ed";
            msg[1] = "1";
        } catch (Exception e) {
            msg[0] = "Some error occured in "+AddORUpdate+"ing Category , please try again!";
            msg[1] = "0";
            logger.info(e);
        }
        return msg;
    }
    @Override
    public String[] isExistSC(String scid,String id,String mc){
    	JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "SELECT COUNT(id) FROM category WHERE main_category = '"+mc+"' AND LCASE(category) = LCASE('"+scid+"') AND id !="+Integer.parseInt(id);
        logger.info(sql);
        String[] msg = {"",""};
        int counts = jdbcTemplate.queryForInt(sql);
        if(counts > 0){
    		msg[0] = "0";
    		msg[1] = "Already exist!";
    	}else{
    		msg[0] = "1";
    		msg[1] = "";
    	}
        return msg;
    	
    }
    @Override
    public List<Categories> listAllSubCategories(String username,String isAdmin){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String subQuery = "";
        if(isAdmin.equals("0")){
        	subQuery  = "WHERE t1.main_category=(SELECT main_category FROM user_details WHERE zid='admin')"; 
        }
        String sql = "SELECT *,t2.main_category as main_category_word  FROM category AS t1 LEFT JOIN (SELECT main_category,id FROM main_categories) AS t2 ON t1.main_category = t2.id "+subQuery+" ORDER BY t1.id DESC;";
        logger.info(sql);
        List<Categories> listMainCategories = jdbcTemplate.query(sql,new RowMapper<Categories>(){
            @Override
            public Categories mapRow(ResultSet rs,int ind) throws SQLException{
                Categories categories = new Categories();
                categories.setId(rs.getInt("id"));
                categories.setMainCategory(rs.getString("main_category_word"));
                categories.setCategory(rs.getString("category"));
                categories.setAddedBy(rs.getString("added_by"));
                categories.setAddedOn(rs.getString("added_on"));
                categories.setLastupdatedBy(rs.getString("lastupdated_by"));
                categories.setLastupdatedOn(rs.getString("lastupdated_on"));
                categories.setStatus(rs.getString("status"));
                return categories;
            }
        });
        return listMainCategories;
    }
    @Override
    public String[] disableSubCategory(int id){
    	JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "UPDATE category SET status='0' WHERE id="+id;
        logger.info(sql);
        String[] msg = {"",""};
        try{
           jdbcTemplate.execute(sql);
           msg[0] = "Status changed successfully!";
           msg[1] = "1";
        }catch(Exception e){
           msg[0] = "Some error occured, please try again !"; 
           msg[1] = "0";
        }
        return msg;
    }
    @Override
    public String[] enableSubCategory(int id){
    	JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "UPDATE category SET status='1' WHERE id="+id;
        logger.info(sql);
        String[] msg = {"",""};
        try{
           jdbcTemplate.execute(sql);
           msg[0] = "Status changed successfully!";
           msg[1] = "1";
        }catch(Exception e){
           msg[0] = "Some error occured, please try again !"; 
           msg[1] = "0";
        }
        return msg;
    }
    /*************************Admin Users**************************/
    @Override
    public String[] saveAdmin(Expatriate expatriate,String username){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql,sql1;String AddORUpdate;
        String passcode = UUID.randomUUID().toString().substring(0, 8);
        if(expatriate.getId() == -1){
            sql = "INSERT INTO users(username,password,enabled,authority) VALUES(?,'"+passcode+"',?,'"+expatriate.getAuthority()+"');";
            sql1 = "INSERT INTO user_details(zid,rn_number,first_name,last_name,email,main_category,added_date,added_by) VALUES(?,?,?,?,?,?,NOW(),'"+username+"');";
            AddORUpdate = "Sav";
            
        }else{
            sql = "UPDATE users SET username=?,enabled=? WHERE username='"+username+"'";
            sql1 = "UPDATE user_details SET zid=?,rn_number=?,first_name=?,last_name=?,email=?,main_category=? WHERE zid='"+username+"'";
            AddORUpdate = "Updat";
        }
        logger.info(sql);
        logger.info(sql1);
        String msg[] = {"",""};
        try {
            jdbcTemplate.update(sql,expatriate.getUsername(),expatriate.getEnabled());
            jdbcTemplate.update(sql1,expatriate.getUsername(),expatriate.getRnNumber(),expatriate.getFirstName(),expatriate.getLastName(),expatriate.getEmail(),expatriate.getCategory());
            msg[0] = "Admin Details Successfully "+AddORUpdate+"ed";
            msg[1] = "1";
            try {
            	msg = this.sendMail(expatriate.getEmail(),expatriate.getUsername(),passcode,expatriate.getFirstName());
            } catch (Exception e) {
                msg[0] = "Admin Saved Successfully,Some error occured in sending email notification!";
                msg[1] = "0";
                logger.info(e);
            }
        } catch (Exception e) {
            msg[0] = "Some error occured in "+AddORUpdate+"ing admin details , please try again!";
            msg[1] = "0";
            logger.info(e);
        }
        return msg;
    }
    @Override
    public String[] isExistAdmin(String adminid,String id){
    	JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "SELECT COUNT(username) FROM users WHERE LCASE(username)=LCASE('"+adminid+"') AND id !="+Integer.parseInt(id);
        logger.info(sql);
        String[] msg = {"",""};
        int counts = jdbcTemplate.queryForInt(sql);
        if(counts > 0){
    		msg[0] = "0";
    		msg[1] = "Already exist!";
    	}else{
    		msg[0] = "1";
    		msg[1] = "";
    	}
        return msg;
    	
    }
    @Override
    public List<Expatriate> listAllAdmins(String isAdmin,String username){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String subQuery = "";
        if(isAdmin.equals("0")){
        	subQuery = "AND t2.main_category = (SELECT main_category FROM user_details WHERE zid='"+username+"')";
        }
        String sql = "SELECT t1.*,t2.* FROM users AS t1 LEFT JOIN (SELECT t3.*,substring(t3.added_date,10) as addeddt,t4.main_category AS mc FROM user_details AS t3 LEFT JOIN (SELECT main_category,id FROM main_categories) AS t4 ON t3.main_category=t4.id) AS t2 ON t1.username = t2.zid WHERE (t1.authority = 'ROLE_ADMIN' OR t1.authority = 'ROLE_SADMIN') "+subQuery+";";
        logger.info(sql);
        List<Expatriate> listAdmins = jdbcTemplate.query(sql,new RowMapper<Expatriate>(){
            @Override
            public Expatriate mapRow(ResultSet rs,int ind) throws SQLException{
                Expatriate expatriate = new Expatriate();
                expatriate.setId(rs.getInt("id"));
                expatriate.setUsername(rs.getString("zid"));
                expatriate.setEmail(rs.getString("email"));
                expatriate.setFirstName(rs.getString("first_name"));
                expatriate.setLastName(rs.getString("last_name"));
                expatriate.setRnNumber(rs.getString("rn_number"));
                expatriate.setLastUpdatedBy(rs.getString("last_login"));
                expatriate.setAddedBy(rs.getString("added_by"));
                expatriate.setAddedDate(rs.getString("addeddt"));
                expatriate.setEnabled(rs.getString("enabled"));
                expatriate.setCategory(rs.getString("mc"));
                expatriate.setAuthority(rs.getString("authority"));
                return expatriate;
            }
        });
        return listAdmins;
    }
    @Override
    public Expatriate editAdminProfile(String username){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "SELECT * FROM user_details AS t1 LEFT JOIN (SELECT * FROM users) AS t2 ON t1.zid=t2.username WHERE t1.zid = '"+username+"' LIMIT 1;";
        logger.info(sql);
        List<Expatriate> listAdmins = jdbcTemplate.query(sql,new RowMapper<Expatriate>(){
            @Override
            public Expatriate mapRow(ResultSet rs,int ind) throws SQLException{
                Expatriate expatriate = new Expatriate();
                expatriate.setId(rs.getInt("id"));
                expatriate.setUsername(rs.getString("zid"));
                expatriate.setEmail(rs.getString("email"));
                expatriate.setFirstName(rs.getString("first_name"));
                expatriate.setLastName(rs.getString("last_name"));
                expatriate.setRnNumber(rs.getString("rn_number"));
                expatriate.setLastUpdatedBy(rs.getString("last_login"));
                expatriate.setAddedBy(rs.getString("added_by"));
                expatriate.setAddedDate(rs.getString("added_date"));
                expatriate.setAuthority(rs.getString("authority"));
                expatriate.setEnabled(rs.getString("enabled"));
                return expatriate;
            }
        });
        return listAdmins.get(0);
    }
    @Override
    public String[] disableAdmin(int id,String enabled){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "UPDATE users SET enabled='"+enabled+"' WHERE id="+id;
        logger.info(sql);
        String[] msg = {"",""};
        try{
           jdbcTemplate.execute(sql);
           msg[0] = "Status changed successfully!";
           msg[1] = "1";
        }catch(Exception e){
           msg[0] = "Some error occured, please try again !"; 
           msg[1] = "0";
        }
        return msg;
    }
    /*************************Expatriates**************************/
    @Override
    public List<Categories> listAllSubCategory(String mainCategory){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "SELECT category,id FROM category WHERE main_category = '"+mainCategory+"'";
        logger.info(sql);
        List<Categories> listAllSubCategories = jdbcTemplate.query(sql, new RowMapper<Categories>() {
            @Override
            public Categories mapRow(ResultSet rs, int i) throws SQLException {
                Categories categories = new Categories();
                categories.setId(rs.getInt("id"));
                categories.setCategory(rs.getString("category"));
                return categories;
            }
        });
        return listAllSubCategories;
    }
    @Override
    public String[] saveExpatriates(Expatriate expatriate,String username){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql,sql1,sql2,sql3;String AddORUpdate;
        String passcode = UUID.randomUUID().toString().substring(0, 8);
        if(expatriate.getExpatOJFid().equals("-1")){
    		sql3 = "INSERT INTO ojf_general_details(email,userid,expatid,submission,status,first_name,last_name,id_number,designation,department,superior_host_company_name,assignment_from,assignment_to,photo) VALUES('"+expatriate.getEmail()+"','"+expatriate.getEmail()+"','"+expatriate.getUsername()+"','0','1','"+expatriate.getFirstName()+"','"+expatriate.getLastName()+"','"+expatriate.getUsername()+"','"+expatriate.getDesignation()+"','"+expatriate.getDepartment()+"','"+expatriate.getApprovalManager()+"','"+expatriate.getAssignmentFrom()+"','"+expatriate.getAssignmentTo()+"','"+expatriate.getPicture()+"')";
    	}else{
    		sql3 = "UPDATE ojf_general_details SET email = '"+expatriate.getEmail()+"',userid='"+expatriate.getEmail()+"',expatid = '"+expatriate.getUsername()+"',first_name='"+expatriate.getFirstName()+"',last_name='"+expatriate.getLastName()+"',id_number='"+expatriate.getUsername()+"',designation = '"+expatriate.getDesignation()+"',department = '"+expatriate.getDepartment()+"',superior_host_company_name='"+expatriate.getApprovalManager()+"',assignment_from = '"+expatriate.getAssignmentFrom()+"',assignment_to = '"+expatriate.getAssignmentTo()+"',photo = '"+expatriate.getPicture()+"' WHERE expatid = '"+expatriate.getUsername()+"';";
    	}
        if(expatriate.getId()== -1){
        	sql1 = "INSERT INTO users(username,password,enabled,authority) VALUES(?,'"+passcode+"',?,'ROLE_USER')";
            sql2 = "INSERT INTO leave_balance(zid,leave_type,count) VALUES(?,?,?)";
            sql = "INSERT INTO user_details(zid,email,first_name,last_name,main_category,category,designation,picture,department,approval_manager,approval_manager_email,assignment_from,assignment_to,assignment_duration,rn_number,home_country,added_by,added_date,last_updated_by,last_updated_date)"
                    + " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,datediff(?, ?),?,?,'"+username+"',NOW(),'"+username+"',NOW());";
            AddORUpdate = "Sav";
            
        }else{
            sql = "UPDATE user_details SET zid=?,email=?,first_name=?,last_name=?,main_category=?,category=?,designation=?,picture=?,department=?,approval_manager=?,approval_manager_email=?,assignment_from=?,assignment_to=?,assignment_duration=datediff(?, ?),rn_number=?,home_country=?,last_updated_by='"+username+"',last_updated_date=NOW() WHERE id="+expatriate.getId();
            sql1 = "UPDATE users SET username=?,enabled=? WHERE username='"+expatriate.getUsername()+"'";
            sql2 = "UPDATE leave_balance SET zid=?,leave_type=?,count=?  WHERE zid='"+expatriate.getUsername()+"'";;
            AddORUpdate = "Updat";
        }
        logger.info(sql);
        logger.info(sql1);
        logger.info(sql2);
        logger.info(sql3);
        String msg[] = {"",""};
        try {
            jdbcTemplate.update(sql,expatriate.getUsername(),expatriate.getEmail(),expatriate.getFirstName(),expatriate.getLastName(),expatriate.getMainCategory(),expatriate.getCategory(),expatriate.getDesignation(),expatriate.getPicture(),expatriate.getDepartment(),expatriate.getApprovalManager(),expatriate.getApprovalManagerEmail(),expatriate.getAssignmentFrom(),expatriate.getAssignmentTo(),expatriate.getAssignmentTo(),expatriate.getAssignmentFrom(),expatriate.getRnNumber(),expatriate.getHomeCountry());
            jdbcTemplate.update(sql1,expatriate.getUsername(),expatriate.getEnabled());
            jdbcTemplate.update(sql2,expatriate.getUsername(),"Init",expatriate.getLeaveCount());
            jdbcTemplate.update(sql3);
            msg[0] = "Expatriate Details Successfully "+AddORUpdate+"ed";
            msg[1] = "1";
            try {
            	msg = this.sendMail(expatriate.getEmail(),expatriate.getUsername(),passcode,expatriate.getFirstName());
            } catch (Exception e) {
                msg[0] = "Expatriate Saved Successfully,Some error occured in sending email notification!";
                msg[1] = "0";
                logger.info(e);
            }
        } catch (Exception e) {
            msg[0] = "Some error occured in "+AddORUpdate+"ing expatriate details , please try again!";
            msg[1] = "0";
            logger.info(e);
        }
        return msg;
    }
    @Override
    public String[] isExistExpatriate(String username,String id){
    	JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "SELECT COUNT(username) FROM users AS t1 LEFT JOIN (SELECT id ,zid FROM user_details) AS t2 ON t1.username = t2.zid WHERE LCASE(t1.username)=LCASE('"+username+"') AND t2.id !="+Integer.parseInt(id);
        logger.info(sql);
        String[] msg = {"",""};
        int counts = jdbcTemplate.queryForInt(sql);
    	if(counts > 0){
    		msg[0] = "0";
    		msg[1] = "Already exist!";
    	}else{
    		msg[0] = "1";
    		msg[1] = "";
    	}
        return msg;
    	
    }
    @Override
    public List<Expatriate> listAllExpatriate(Boolean role) {
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String subQuery = "";
        if(role){
            subQuery = "t1.main_category = (SELECT main_category FROM user_details WHERE zid='admin')";
        }else{
            subQuery = "t1.main_category != ''";
        }
        String sql = "SELECT t1.* ,DATE_FORMAT(t1.last_updated_date,'%d-%m-%Y') AS luo,DATE_FORMAT(t1.added_date,'%d-%m-%Y') AS addeddt,t2.*,(SELECT main_category FROM main_categories WHERE id=t1.main_category) AS main_category_word,(SELECT category FROM category WHERE id=t1.category) AS sub_category_word,(SELECT category FROM category WHERE id=t1.category) AS sub_category_word,((SELECT count FROM leave_balance WHERE zid=t1.zid)-IFNULL((SELECT SUM(leave_count) FROM leave_maintenance WHERE emp_zid=t1.zid),0)) AS countsbalance  FROM user_details AS t1 LEFT JOIN (SELECT username,authority,enabled FROM users) AS t2 on t1.zid = t2.username WHERE t2.authority = 'ROLE_USER' AND "+subQuery+";";
        logger.info(sql);
        List<Expatriate> listExpatriate = jdbcTemplate.query(sql,new RowMapper<Expatriate>(){
            @Override
            public Expatriate mapRow(ResultSet rs,int ind) throws SQLException{
                Expatriate expatriate = new Expatriate();
                expatriate.setId(rs.getInt("id"));
                expatriate.setUsername(rs.getString("zid"));
                expatriate.setEmail(rs.getString("email"));
                expatriate.setFirstName(rs.getString("first_name"));
                expatriate.setLastName(rs.getString("last_name"));
                expatriate.setCategory(rs.getString("sub_category_word"));
                expatriate.setMainCategory(rs.getString("main_category_word"));
                expatriate.setDesignation(rs.getString("designation"));
                expatriate.setDepartment(rs.getString("department"));
                expatriate.setPicture(rs.getString("picture"));
                expatriate.setAssignmentFrom(rs.getString("assignment_from"));
                expatriate.setAssignmentTo(rs.getString("assignment_to"));
                expatriate.setAssignementDuration(rs.getString("countsbalance"));
                expatriate.setApprovalManager(rs.getString("approval_manager"));
                expatriate.setApprovalManagerEmail(rs.getString("approval_manager_email"));
                expatriate.setRnNumber(rs.getString("rn_number"));
                expatriate.setHomeCountry(rs.getString("home_country"));
                expatriate.setLastUpdatedBy(rs.getString("last_updated_by"));
                expatriate.setLastUpdatedDate(rs.getString("luo"));
                expatriate.setAddedBy(rs.getString("added_by"));
                expatriate.setAddedDate(rs.getString("addeddt"));
                expatriate.setEnabled(rs.getString("enabled"));
                return expatriate;
            }
        });
        return listExpatriate;
    }
    @Override
    public Expatriate editExpatriate(int id){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "SELECT t1.* ,DATE_FORMAT(t1.last_updated_date,'%d-%m-%Y') AS luo,DATE_FORMAT(t1.added_date,'%d-%m-%Y') AS addeddt,t2.*,t3.* FROM user_details AS t1 LEFT JOIN (SELECT username,authority,enabled FROM users) AS t2 on t1.zid = t2.username left join (select * from leave_balance where leave_type='Init') as t3 on t2.username = t3.zid WHERE t1.id="+id;
        logger.info(sql);
        List<Expatriate> listExpatriate = jdbcTemplate.query(sql,new RowMapper<Expatriate>(){
            @Override
            public Expatriate mapRow(ResultSet rs,int ind) throws SQLException{
                Expatriate expatriate = new Expatriate();
                expatriate.setId(rs.getInt("id"));
                expatriate.setUsername(rs.getString("zid"));
                expatriate.setEmail(rs.getString("email"));
                expatriate.setFirstName(rs.getString("first_name"));
                expatriate.setLastName(rs.getString("last_name"));
                expatriate.setCategory(rs.getString("category"));
                expatriate.setMainCategory(rs.getString("main_category"));
                expatriate.setDesignation(rs.getString("designation"));
                expatriate.setPicture(rs.getString("picture"));
                expatriate.setDepartment(rs.getString("department"));
                expatriate.setAssignmentFrom(rs.getString("assignment_from"));
                expatriate.setAssignmentTo(rs.getString("assignment_to"));
                expatriate.setAssignementDuration(rs.getString("assignment_duration"));
                expatriate.setApprovalManager(rs.getString("approval_manager"));
                expatriate.setApprovalManagerEmail(rs.getString("approval_manager_email"));
                expatriate.setRnNumber(rs.getString("rn_number"));
                expatriate.setHomeCountry(rs.getString("home_country"));
                expatriate.setLastUpdatedBy(rs.getString("last_updated_by"));
                expatriate.setLastUpdatedDate(rs.getString("luo"));
                expatriate.setAddedBy(rs.getString("added_by"));
                expatriate.setAddedDate(rs.getString("addeddt"));
                expatriate.setLeaveCount(rs.getString("count"));
                expatriate.setEnabled(rs.getString("enabled"));
                expatriate.setExpatOJFid(rs.getString("zid"));
                return expatriate;
            }
        });
        return listExpatriate.get(0);
    }
    @Override
    public String[] updateExpatriateStatus(String username) {
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "UPDATE users SET enabled=0 WHERE username="+username;
        logger.info(sql);
        String[] msg = {"",""};
        try{
           jdbcTemplate.execute(sql);
           msg[0] = "Record Deleted Successfully!";
           msg[1] = "1";
        }catch(Exception e){
           msg[0] = "some error occured, please try again !"; 
           msg[1] = "0";
        }
        return msg;
    }
    @Override
     public List<Expatriate> listExpatriateTypeReport(String username,String reportFor,String status,String duration,String dateFrom,String dateTill){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String subQuery = "";
        if(reportFor.equals("1")){
            subQuery += " AND added_by ='"+username+"'";
        }
        if(!status.equals("-1")){
            subQuery += " AND enabled = "+status;
        }
        if(duration.equals("1")){
            subQuery += " AND YEAR(added_date) = YEAR(NOW())";
        }else if(duration.equals("2")){
            subQuery += " AND (STR_TO_DATE(added_date,'%Y-%m-%d') >= STR_TO_DATE('"+dateFrom+"','%Y-%m-%d') AND STR_TO_DATE(added_date,'%Y-%m-%d') >= STR_TO_DATE('"+dateTill+"','%Y-%m-%d') )";
        }
        
        String sql = "SELECT * FROM (SELECT * FROM ojf_general_details AS t1 LEFT JOIN (SELECT zid,picture,category,approval_manager,approval_manager_email,assignment_duration,rn_number,home_country,added_by,added_date,last_updated_by,last_updated_date,last_login FROM user_details) AS t3  ON t3.zid = t1.expatid LEFT JOIN (SELECT enabled,username,authority FROM users) AS t2 ON t3.zid=t2.username  WHERE t2.authority = 'ROLE_USER' GROUP BY t2.username) viewtable WHERE id != -1 "+subQuery+";";
        logger.info(sql);
        List<Expatriate> listExpatriate = jdbcTemplate.query(sql,new RowMapper<Expatriate>(){
            @Override
            public Expatriate mapRow(ResultSet rs,int ind) throws SQLException{
                Expatriate expatriate = new Expatriate();
                expatriate.setFirstName(rs.getString("first_name"));
                expatriate.setLastName(rs.getString("last_name"));
                expatriate.setCategory(rs.getString("category"));
                expatriate.setDepartment(rs.getString("department"));
                //expatriate.setPicture(rs.getString("picture"));
                expatriate.setAssignmentFrom(rs.getString("assignment_from"));
                expatriate.setAssignmentTo(rs.getString("assignment_to"));
                expatriate.setAddedDate(rs.getString("added_date"));                
                return expatriate;
            }
        });
        return listExpatriate;
    }
    @Override
    public PdfPTable ExpatPdfDownload(String username,String reportFor,String status,String duration,String dateFrom,String dateTill){
       JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
       String subQuery = "";
       if(reportFor.equals("1")){
           subQuery += " AND added_by ='"+username+"'";
       }
       if(!status.equals("-1")){
           subQuery += " AND enabled = "+status;
       }
       if(duration.equals("1")){
           subQuery += " AND YEAR(added_date) = YEAR(NOW())";
       }else if(duration.equals("2")){
           subQuery += " AND (STR_TO_DATE(added_date,'%Y-%m-%d') >= STR_TO_DATE('"+dateFrom+"','%Y-%m-%d') AND STR_TO_DATE(added_date,'%Y-%m-%d') >= STR_TO_DATE('"+dateTill+"','%Y-%m-%d') )";
       }
       
       String sql = "SELECT * FROM (SELECT * FROM ojf_general_details AS t1 LEFT JOIN (SELECT zid,category,approval_manager,approval_manager_email,assignment_duration,rn_number,home_country,added_by,added_date,last_updated_by,last_updated_date,last_login FROM user_details) AS t3  ON t3.zid = t1.expatid LEFT JOIN (SELECT enabled,username,authority FROM users) AS t2 ON t3.zid=t2.username  WHERE t2.authority = 'ROLE_USER' GROUP BY t2.username) viewtable WHERE id != -1 "+subQuery+";";
       logger.info(sql);
       List<Expatriate> listExpatriate = jdbcTemplate.query(sql,new RowMapper<Expatriate>(){
           @Override
           public Expatriate mapRow(ResultSet rs,int ind) throws SQLException{
               Expatriate expatriate = new Expatriate();
               expatriate.setFirstName(rs.getString("first_name"));
               expatriate.setLastName(rs.getString("last_name"));
               expatriate.setCategory(rs.getString("category"));
               expatriate.setDepartment(rs.getString("department"));
               //expatriate.setPicture(rs.getString("picture"));
               expatriate.setAssignmentFrom(rs.getString("assignment_from"));
               expatriate.setAssignmentTo(rs.getString("assignment_to"));
               expatriate.setAddedDate(rs.getString("added_date"));                
               return expatriate;
           }
       });
       PdfPTable table = new PdfPTable(3); // 3 columns.
       table.setWidthPercentage(100); //Width 100%
       table.setSpacingBefore(10f); //Space before table
       table.setSpacingAfter(10f); //Space after table

       //Set Column widths
       float[] columnWidths = {1f, 1f, 1f};
       try {
			table.setWidths(columnWidths);
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
       System.out.println("%%%%%%%%%%%%%%%%%"+listExpatriate.size());
       if(listExpatriate.size() > 0){
    	   for(int i =0; i< listExpatriate.size();i++){
	    	   PdfPCell cell1 = new PdfPCell(new Paragraph(listExpatriate.get(0).getFirstName()));
	           cell1.setBorderColor(BaseColor.BLUE);
	           cell1.setPaddingLeft(10);
	           cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
	           cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
	    
	           PdfPCell cell2 = new PdfPCell(new Paragraph(listExpatriate.get(0).getFirstName()));
	           cell2.setBorderColor(BaseColor.GREEN);
	           cell2.setPaddingLeft(10);
	           cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
	           cell2.setVerticalAlignment(Element.ALIGN_MIDDLE);
	    
	           PdfPCell cell3 = new PdfPCell(new Paragraph(listExpatriate.get(0).getFirstName()));
	           cell3.setBorderColor(BaseColor.RED);
	           cell3.setPaddingLeft(10);
	           cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
	           cell3.setVerticalAlignment(Element.ALIGN_MIDDLE);
	    
	           //To avoid having the cell border and the content overlap, if you are having thick cell borders
	           cell1.setUseBorderPadding(true);
	           cell2.setUseBorderPadding(true);
	           cell3.setUseBorderPadding(true);
	    
	           table.addCell(cell1);
	           table.addCell(cell2);
	           table.addCell(cell3);
    	   }
       }
       return table;
   }
    @Override
    public HSSFWorkbook ExpatExcelDownload(String username,String reportFor,String status,String duration,String dateFrom,String dateTill){
       JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
       String subQuery = "";
       if(reportFor.equals("1")){
           subQuery += " AND added_by ='"+username+"'";
       }
       if(!status.equals("-1")){
           subQuery += " AND enabled = "+status;
       }
       if(duration.equals("1")){
           subQuery += " AND YEAR(added_date) = YEAR(NOW())";
       }else if(duration.equals("2")){
           subQuery += " AND (STR_TO_DATE(added_date,'%Y-%m-%d') >= STR_TO_DATE('"+dateFrom+"','%Y-%m-%d') AND STR_TO_DATE(added_date,'%Y-%m-%d') >= STR_TO_DATE('"+dateTill+"','%Y-%m-%d') )";
       }
       
       String sql = "SELECT * FROM (SELECT * FROM ojf_general_details AS t1 LEFT JOIN (SELECT zid,category,approval_manager,approval_manager_email,assignment_duration,rn_number,home_country,added_by,added_date,last_updated_by,last_updated_date,last_login FROM user_details) AS t3  ON t3.zid = t1.expatid LEFT JOIN (SELECT enabled,username,authority FROM users) AS t2 ON t3.zid=t2.username  WHERE t2.authority = 'ROLE_USER' GROUP BY t2.username) viewtable WHERE id != -1 "+subQuery+";";
       logger.info(sql);
       List<OJFGeneral> listExpatriate = jdbcTemplate.query(sql,new RowMapper<OJFGeneral>(){
           @Override
           public OJFGeneral mapRow(ResultSet rs,int ind) throws SQLException{
        	   OJFGeneral ojfGeneral = new OJFGeneral();
        	   ojfGeneral.setFirstName(rs.getString("first_name"));
        	   ojfGeneral.setLastName(rs.getString("last_name"));
        	   //ojfGeneral.setCategory(rs.getString("category"));
        	   ojfGeneral.setDepartment(rs.getString("department"));
        	   //ojfGeneral.setpho(rs.getString("picture"));
        	   ojfGeneral.setAssignmentFrom(rs.getString("assignment_from"));
        	   ojfGeneral.setAssignmentTo(rs.getString("assignment_to"));
        	   ojfGeneral.setEmail(rs.getString("email"));
        	   ojfGeneral.setDob(rs.getString("added_date"));    
        	   ojfGeneral.setBlood(rs.getString("added_by"));
               return ojfGeneral;
           }
       });
       HSSFWorkbook workbook = new HSSFWorkbook();
       if(listExpatriate.size() > 0){
    	   try {
           	   
               
               HSSFSheet sheet = workbook.createSheet("Expatriate");  
               HSSFRow rowhead = sheet.createRow((short)0);
               rowhead.createCell(0).setCellValue("No.");
               rowhead.createCell(1).setCellValue("First Name");
               rowhead.createCell(2).setCellValue("Last Name");
               rowhead.createCell(3).setCellValue("Email");
               rowhead.createCell(4).setCellValue("Department");
               rowhead.createCell(5).setCellValue("Assignment From");
               rowhead.createCell(6).setCellValue("Assignment Till");
               rowhead.createCell(7).setCellValue("Added Date");
               rowhead.createCell(8).setCellValue("Added by");
               for(int i = 0; i < listExpatriate.size();i++){
	               HSSFRow row = sheet.createRow((short)(i+1));
	               row.createCell(0).setCellValue(i+1);
	               row.createCell(1).setCellValue(listExpatriate.get(0).getFirstName());
	               row.createCell(2).setCellValue(listExpatriate.get(0).getLastName());
	               row.createCell(3).setCellValue(listExpatriate.get(0).getEmail());
	               row.createCell(4).setCellValue(listExpatriate.get(0).getDepartment());
	               row.createCell(5).setCellValue(listExpatriate.get(0).getAssignmentFrom());
	               row.createCell(6).setCellValue(listExpatriate.get(0).getAssignmentTo());
	               row.createCell(7).setCellValue(listExpatriate.get(0).getDob());
	               row.createCell(8).setCellValue(listExpatriate.get(0).getBlood());
               }
           } catch ( Exception ex ) {
               System.out.println(ex);
           }
       }
       return workbook;
   }
    @Override
    public String[] resendMailExpatriates(String username){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "SELECT password,t2.* FROM users AS t1 LEFT JOIN (SELECT first_name,last_name,email,zid FROM user_details) AS t2 ON t1.username = t2.zid WHERE username='"+username+"'";
        logger.info(sql);
        List<Expatriate> resendmail = jdbcTemplate.query(sql, new RowMapper<Expatriate>() {
            @Override
            public Expatriate mapRow(ResultSet rs, int i) throws SQLException {
            	Expatriate expatriate = new Expatriate();
            	expatriate.setFirstName(rs.getString("first_name"));
            	expatriate.setLastName(rs.getString("last_name"));
            	expatriate.setEmail(rs.getString("email"));
            	expatriate.setPassword(rs.getString("password"));
            	expatriate.setUsername(rs.getString("zid"));
                return expatriate;
            }
        });
        Expatriate expatriate =  resendmail.get(0);
        String[] msg = {"",""};
        try{
        	msg = this.sendMail(expatriate.getEmail(),expatriate.getUsername(),expatriate.getPassword(),expatriate.getFirstName());
        }catch(Exception e){
           msg[0] = "Some error occured, please try again !"; 
           msg[1] = "0";
        }
        return msg;
    }
    /*************************Leave Types**************************/
     @Override
     public List<Categories> listAdminSpecificSubcategories(String username){
         JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "SELECT category,id FROM category WHERE main_category=(SELECT main_category FROM user_details WHERE zid='"+username+"')";
        logger.info(sql);
        List<Categories> listMainCategories = jdbcTemplate.query(sql,new RowMapper<Categories>(){
            @Override
            public Categories mapRow(ResultSet rs,int ind) throws SQLException{
                Categories categories = new Categories();
                categories.setId(rs.getInt("id"));
                categories.setCategory(rs.getString("category"));
                return categories;
            }
        });
        return listMainCategories;
     }
    @Override
    public String[] saveLeaveTypes(LeaveTypes leaveTypes,String username) {
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql;String AddORUpdate;
        if(leaveTypes.getId()== -1){
            sql = "INSERT INTO leave_types(leave_type,category,max_count,allowed_count,allow_after,status,details,color,icon,added_by,added_on,lastupdated_by,lastupdated_on,deduct) VALUES (?,?,?,?,?,?,?,?,?,'"+username+"',NOW(),'"+username+"',NOW(),?);";
            AddORUpdate = "Sav";
        }else{
            sql = "UPDATE leave_types SET leave_type=?,category=?,max_count=?,allowed_count=?,allow_after=?,status=?,details=?,color=?,icon=?,lastupdated_by='"+username+"',lastupdated_on=NOW(),deduct=? WHERE id="+leaveTypes.getId();
            AddORUpdate = "Updat";
        }
        logger.info(sql);
        String msg[] = {"",""};
        try {
            jdbcTemplate.update(sql,leaveTypes.getLeavetype(),leaveTypes.getCategory(),leaveTypes.getMaxCount(),leaveTypes.getAllowedCount(),leaveTypes.getAllowAfter(),leaveTypes.getStatus(),leaveTypes.getLeaveDetails(),leaveTypes.getColor(),leaveTypes.getIcon(),leaveTypes.getDeduct());
            msg[0] = "Leave Type Successfully  "+AddORUpdate+"ed";
            msg[1] = "1";
        } catch (Exception e) {
            msg[0] = "Some error occured while "+AddORUpdate+"ing Leave Type , please try again!";
            msg[1] = "0";
            logger.info(e);
        }
        return msg;
    }
    @Override
    public String[] isExistLeaveTypes(String category,String leaveType,String id){
    	JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "SELECT COUNT(id) FROM leave_types WHERE category='"+category+"' AND LCASE(leave_type)=LCASE('"+leaveType+"')  AND id !="+Integer.parseInt(id);
        logger.info(sql);
        String[] msg = {"",""};
        int counts = jdbcTemplate.queryForInt(sql);
        if(counts > 0){
    		msg[0] = "0";
    		msg[1] = "Already exist!";
    	}else{
    		msg[0] = "1";
    		msg[1] = "";
    	}
        return msg;
    	
    }
    @Override
    public List<LeaveTypes> listAllLeaveTypes(String adminstatus,String username) {
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String subQuery = "";
        if(!adminstatus.equals("SA")){
            subQuery = " WHERE main_category = (SELECT main_category FROM user_details WHERE zid='"+username+"' LIMIT 1)";
        }
        String sql = "SELECT id,leave_type,IFNULL(emps,0) as emps,cat,mc,max_count,deduct,allowed_count,allow_after,details,icon,color,status,added_by,added_on,lastupdated_by,lastupdated_on FROM leave_types AS t1 LEFT JOIN (SELECT IFNULL(COUNT(emp_zid),0) AS emps,leave_type AS lt FROM leave_maintenance) AS t4 ON t1.id=t4.lt LEFT JOIN (SELECT category AS cat , id AS ids,main_category FROM category "+subQuery+") AS t2 ON t1.category = t2.ids LEFT JOIN (SELECT main_category AS mc,id AS idx FROM main_categories) AS t3 ON t3.idx = t2.main_category";
        logger.info(sql);
        List<LeaveTypes> listLeaveTypes = jdbcTemplate.query(sql,new RowMapper<LeaveTypes>(){
            @Override
            public LeaveTypes mapRow(ResultSet rs,int ind) throws SQLException{
                LeaveTypes leaveTypes = new LeaveTypes();
                leaveTypes.setId(rs.getInt("id"));
                leaveTypes.setLeavetype(rs.getString("leave_type"));
                leaveTypes.setStatus(rs.getString("status"));
                leaveTypes.setLeaveDetails(rs.getString("details"));
                leaveTypes.setColor(rs.getString("color"));
                leaveTypes.setIcon(rs.getString("icon"));
                leaveTypes.setMaxCount(rs.getString("max_count"));
                leaveTypes.setAllowedCount(rs.getString("allowed_count"));
                leaveTypes.setCategory(rs.getString("cat"));
                leaveTypes.setMainCategory(rs.getString("mc"));
                leaveTypes.setAllowAfter(rs.getString("allow_after"));
                leaveTypes.setAddedBy(rs.getString("added_by"));
                leaveTypes.setAddedOn(rs.getString("added_on"));
                leaveTypes.setLastupdatedBy(rs.getString("lastupdated_by"));
                leaveTypes.setLastupdatedOn(rs.getString("lastupdated_on"));
                leaveTypes.setDeduct(rs.getString("deduct"));
                leaveTypes.setCanDisable(rs.getString("emps"));
                return leaveTypes;
            }
        });
        return listLeaveTypes;
    }
    @Override
    public LeaveTypes editLeaveTypes(int id) {
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "SELECT *,(SELECT id FROM main_categories WHERE main_categories.id=(SELECT main_category FROM category WHERE id=leave_types.category)) AS mcs FROM leave_types WHERE id="+id+" ORDER BY added_on DESC LIMIT 1";
        logger.info(sql);
        List<LeaveTypes> listLeaveTypes = jdbcTemplate.query(sql,new RowMapper<LeaveTypes>(){
            @Override
            public LeaveTypes mapRow(ResultSet rs,int ind) throws SQLException{
                LeaveTypes leaveTypes = new LeaveTypes();
                leaveTypes.setId(rs.getInt("id"));
                leaveTypes.setLeavetype(rs.getString("leave_type"));
                leaveTypes.setStatus(rs.getString("status"));
                leaveTypes.setLeaveDetails(rs.getString("details"));
                leaveTypes.setColor(rs.getString("color"));
                leaveTypes.setIcon(rs.getString("icon"));
                leaveTypes.setMaxCount(rs.getString("max_count"));
                leaveTypes.setAllowedCount(rs.getString("allowed_count"));
                leaveTypes.setCategory(rs.getString("category"));
                leaveTypes.setAllowAfter(rs.getString("allow_after"));
                leaveTypes.setAddedBy(rs.getString("added_by"));
                leaveTypes.setAddedOn(rs.getString("added_on"));
                leaveTypes.setLastupdatedBy(rs.getString("lastupdated_by"));
                leaveTypes.setLastupdatedOn(rs.getString("mcs"));
                leaveTypes.setDeduct(rs.getString("deduct"));
                return leaveTypes;
            }
        });
        return listLeaveTypes.get(0);
    }

    @Override
    public String[] deleteLeaveTypes(int id,String status) {
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        if(status.equals("true")){
           status = "0";
        }else{
            status = "1";
        }
        String sql = "UPDATE leave_types SET status='"+status+"' WHERE id="+id;
        logger.info(sql);
        String[] msg = {"",""};
        try{
           jdbcTemplate.execute(sql);
           msg[0] = "Leave type status changed successfully!";
           msg[1] = "1";
        }catch(Exception e){
           msg[0] = "Some error occured, please try again !"; 
           msg[1] = "0";
        }
        return msg;
    }
    @Override
    public List<LeaveTypes> listAllLeaveTypeReport(String isAdmin,String username,String admin,String dateFrom,String dateTo,String category) {
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String subQuery = "";
        if(isAdmin.equals("A")){
        	subQuery += " AND t2.main_category = (SELECT main_category FROM user_details WHERE zid='"+username+"')";
        }
        if(admin.equals("1")){
            subQuery = " AND added_by = '"+username+"'";
        }
        if(!category.equals("-1")){
            subQuery += " AND category='"+category+"'";
        }
        if(dateFrom.length() > 0){
            subQuery += " AND added_on >= STR_TO_DATE('"+dateFrom+"','%Y-%m-%d')";
        }
        if(dateTo.length() > 0){
            subQuery += " AND added_on <= STR_TO_DATE('"+dateTo+"','%Y-%m-%d')";
        }
        String sql = "SELECT t1.*,DATE_FORMAT(added_on,'%d-%m-%Y') AS addeddate,cats,(SELECT main_category FROM main_categories WHERE main_categories.id=(SELECT main_category AS mct FROM category WHERE category.id=t1.category) ) AS mc FROM leave_types AS t1 LEFT JOIN (SELECT id AS ids,category AS cats,main_category  FROM category) AS t2 ON t1.category = t2.ids WHERE id != -1 "+subQuery+";";
        logger.info(sql);
        List<LeaveTypes> listLeaveTypes = jdbcTemplate.query(sql,new RowMapper<LeaveTypes>(){
            @Override
            public LeaveTypes mapRow(ResultSet rs,int ind) throws SQLException{
                LeaveTypes leaveTypes = new LeaveTypes();
                leaveTypes.setId(rs.getInt("id"));
                leaveTypes.setLeavetype(rs.getString("leave_type"));
                leaveTypes.setStatus(rs.getString("status"));
                leaveTypes.setLeaveDetails(rs.getString("details"));
                leaveTypes.setMaxCount(rs.getString("max_count"));
                leaveTypes.setAllowedCount(rs.getString("allowed_count"));
                leaveTypes.setCategory(rs.getString("cats"));
                leaveTypes.setAllowAfter(rs.getString("allow_after"));
                leaveTypes.setAddedBy(rs.getString("added_by"));
                leaveTypes.setAddedOn(rs.getString("addeddate"));
                leaveTypes.setLastupdatedBy(rs.getString("lastupdated_by"));
                leaveTypes.setLastupdatedOn(rs.getString("lastupdated_on"));
                leaveTypes.setDeduct(rs.getString("deduct"));
                leaveTypes.setColor(rs.getString("mc"));
                return leaveTypes;
            }
        });
        return listLeaveTypes;
    }
    
    @Override
    public PdfPTable LeaveTypePdfDownload(String isAdmin,String username,String admin,String dateFrom,String dateTo,String category) {
    	JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String subQuery = "";
        if(isAdmin.equals("A")){
        	subQuery += " AND t2.main_category = (SELECT main_category FROM user_details WHERE zid='"+username+"')";
        }
        if(admin.equals("1")){
            subQuery = " AND added_by = '"+username+"'";
        }
        if(!category.equals("-1")){
            subQuery += " AND category='"+category+"'";
        }
        if(dateFrom.length() > 0){
            subQuery += " AND added_on >= STR_TO_DATE('"+dateFrom+"','%Y-%m-%d')";
        }
        if(dateTo.length() > 0){
            subQuery += " AND added_on <= STR_TO_DATE('"+dateTo+"','%Y-%m-%d')";
        }
        String sql = "SELECT t1.*,DATE_FORMAT(added_on,'%d-%m-%Y') AS addeddate,cats FROM leave_types AS t1 LEFT JOIN (SELECT id AS ids,category AS cats,main_category  FROM category) AS t2 ON t1.category = t2.ids WHERE id != -1 "+subQuery+";";
        logger.info(sql);
        List<LeaveTypes> listLeaveTypes = jdbcTemplate.query(sql,new RowMapper<LeaveTypes>(){
            @Override
            public LeaveTypes mapRow(ResultSet rs,int ind) throws SQLException{
                LeaveTypes leaveTypes = new LeaveTypes();
                leaveTypes.setId(rs.getInt("id"));
                leaveTypes.setLeavetype(rs.getString("leave_type"));
                leaveTypes.setStatus(rs.getString("status"));
                leaveTypes.setLeaveDetails(rs.getString("details"));
                leaveTypes.setMaxCount(rs.getString("max_count"));
                leaveTypes.setAllowedCount(rs.getString("allowed_count"));
                leaveTypes.setCategory(rs.getString("cats"));
                leaveTypes.setAllowAfter(rs.getString("allow_after"));
                leaveTypes.setAddedBy(rs.getString("added_by"));
                leaveTypes.setAddedOn(rs.getString("addeddate"));
                leaveTypes.setLastupdatedBy(rs.getString("lastupdated_by"));
                leaveTypes.setLastupdatedOn(rs.getString("lastupdated_on"));
                leaveTypes.setDeduct(rs.getString("deduct"));
                return leaveTypes;
            }
        });
        PdfPTable table = new PdfPTable(3);
        table.setWidthPercentage(100); //Width 100%
        table.setSpacingBefore(0f); //Space before table
        table.setSpacingAfter(0f); //Space after table

        //Set Column widths
        float[] columnWidths = {1f, 1f, 1f};
        try {
 			table.setWidths(columnWidths);
 		} catch (DocumentException e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		}
        PdfPCell cell4 = new PdfPCell(new Paragraph("Leave Type"));
        cell4.setPaddingLeft(10);
        cell4.setVerticalAlignment(Element.ALIGN_MIDDLE);
        PdfPCell cell5 = new PdfPCell(new Paragraph("Max Count"));
        cell5.setPaddingLeft(10);
        cell5.setVerticalAlignment(Element.ALIGN_MIDDLE);
        PdfPCell cell6 = new PdfPCell(new Paragraph("Allowed Count"));
        cell6.setPaddingLeft(10);
        cell6.setVerticalAlignment(Element.ALIGN_MIDDLE);
        table.addCell(cell4);
        table.addCell(cell5);
        table.addCell(cell6);
        if(listLeaveTypes.size() > 0){
     	   for(int i =0; i< listLeaveTypes.size();i++){
 	    	   PdfPCell cell1 = new PdfPCell(new Paragraph(listLeaveTypes.get(0).getLeavetype()));
 	           /*cell1.setBorderColor(BaseColor.BLUE);*/
 	           cell1.setPaddingLeft(10);
 	           /*cell1.setHorizontalAlignment(Element.ALIGN_CENTER);*/
 	           cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);
 	    
 	           PdfPCell cell2 = new PdfPCell(new Paragraph(listLeaveTypes.get(0).getMaxCount()));
 	           /*cell2.setBorderColor(BaseColor.GREEN);*/
 	           cell2.setPaddingLeft(10);
 	           /*cell2.setHorizontalAlignment(Element.ALIGN_CENTER);*/
 	           cell2.setVerticalAlignment(Element.ALIGN_MIDDLE);
 	    
 	           PdfPCell cell3 = new PdfPCell(new Paragraph(listLeaveTypes.get(0).getAllowedCount()));
 	           /*cell3.setBorderColor(BaseColor.RED);*/
 	           cell3.setPaddingLeft(10);
 	           /*cell3.setHorizontalAlignment(Element.ALIGN_CENTER);*/
 	           cell3.setVerticalAlignment(Element.ALIGN_MIDDLE);
 	    
 	           //To avoid having the cell border and the content overlap, if you are having thick cell borders
 	           cell1.setUseBorderPadding(true);
 	           cell2.setUseBorderPadding(true);
 	           cell3.setUseBorderPadding(true);
 	    
 	           table.addCell(cell1);
 	           table.addCell(cell2);
 	           table.addCell(cell3);
     	   }
        }
        return table;
    }
    /*************************Holidays*****************************/
    @Override
    public String[] saveHoliday(Holidays holidays,String username){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql;String AddORUpdate;
        if(holidays.getId()== -1){
            sql = "INSERT INTO holidays(holiday_name,holiday_date,holiday_description,holiday_status,added_by,added_on,last_updated_by,last_updated_on,category) VALUES (?,?,?,?,'"+username+"',NOW(),'"+username+"',NOW(),(SELECT main_category from user_details WHERE zid='"+username+"'));";
            AddORUpdate = "Sav";
        }else{
            sql = "UPDATE holidays SET holiday_name=?,holiday_date=?,holiday_description=?,holiday_status=?,last_updated_by='"+username+"',last_updated_on=NOW() WHERE id="+holidays.getId();
            AddORUpdate = "Updat";
        }
        logger.info(sql);
        String msg[] = {"",""};
        try {
            jdbcTemplate.update(sql,holidays.getHolidayName(),holidays.getHolidayDate(),holidays.getHolidayDescription(),holidays.getStatus());
            msg[0] = "Holiday Successfully  "+AddORUpdate+"ed";
            msg[1] = "1";
        } catch (Exception e) {
            msg[0] = "Some error occured while "+AddORUpdate+"ing Holiday , please try again!";
            msg[1] = "0";
            logger.info(e);
        }
        return msg;
    }
    @Override
    public String[] isExistHoliday(String holidaydate,String id){
    	JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "SELECT COUNT(id) FROM holidays WHERE STR_TO_DATE(holiday_date,'%Y-%m-%d')= STR_TO_DATE('"+holidaydate+"','%Y-%m-%d')  AND id !="+Integer.parseInt(id);
        logger.info(sql);
        String[] msg = {"",""};
        int counts = jdbcTemplate.queryForInt(sql);
        if(counts > 0){
    		msg[0] = "0";
    		msg[1] = "Already exist!";
    	}else{
    		msg[0] = "1";
    		msg[1] = "";
    	}
        return msg;
    	
    }
    @Override
    public List<Holidays> listAllHolidays(String adminstatus,String username){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String subQuery = "";
        if(adminstatus.equals("0")){
        	subQuery = "AND category=(SELECT main_category FROM user_details WHERE zid='"+username+"')";
        }
        String sql = "SELECT * FROM holidays WHERE YEAR(holiday_date) > (YEAR(NOW())-1) "+subQuery+" ORDER BY holiday_date DESC";
        logger.info(sql);
        List<Holidays> listHolidays = jdbcTemplate.query(sql,new RowMapper<Holidays>(){
            @Override
            public Holidays mapRow(ResultSet rs,int ind) throws SQLException{
                Holidays holidays = new Holidays();
                holidays.setId(rs.getInt("id"));
                holidays.setHolidayName(rs.getString("holiday_name"));
                holidays.setHolidayDate(rs.getString("holiday_date"));
                holidays.setHolidayDescription(rs.getString("holiday_description"));
                holidays.setStatus(rs.getString("holiday_status"));
                holidays.setAddedBy(rs.getString("added_by"));
                holidays.setAddedOn(rs.getString("added_on"));
                holidays.setLastUpdatedBy(rs.getString("last_updated_by"));
                holidays.setLastUpdatedOn(rs.getString("last_updated_on"));
                return holidays;
            }
        });
        return listHolidays;
    }
    @Override
    public List<Holidays> listAllHolidaysUsers(String username){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "SELECT * FROM holidays WHERE YEAR(holiday_date) > (YEAR(NOW())-1) AND category=(SELECT main_category FROM user_details WHERE zid='"+username+"') ORDER BY holiday_date DESC";
        logger.info(sql);
        List<Holidays> listHolidays = jdbcTemplate.query(sql,new RowMapper<Holidays>(){
            @Override
            public Holidays mapRow(ResultSet rs,int ind) throws SQLException{
                Holidays holidays = new Holidays();
                holidays.setId(rs.getInt("id"));
                holidays.setHolidayName(rs.getString("holiday_name"));
                holidays.setHolidayDate(rs.getString("holiday_date"));
                holidays.setHolidayDescription(rs.getString("holiday_description"));
                holidays.setStatus(rs.getString("holiday_status"));
                holidays.setAddedBy(rs.getString("added_by"));
                holidays.setAddedOn(rs.getString("added_on"));
                holidays.setLastUpdatedBy(rs.getString("last_updated_by"));
                holidays.setLastUpdatedOn(rs.getString("last_updated_on"));
                return holidays;
            }
        });
        return listHolidays;
    }
    @Override
    public Holidays editHoliday(int id){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "SELECT * FROM holidays WHERE id="+id+" ORDER BY holiday_date DESC";
        logger.info(sql);
        List<Holidays> listHolidays = jdbcTemplate.query(sql,new RowMapper<Holidays>(){
            @Override
            public Holidays mapRow(ResultSet rs,int ind) throws SQLException{
                Holidays holidays = new Holidays();
                holidays.setId(rs.getInt("id"));
                holidays.setHolidayName(rs.getString("holiday_name"));
                holidays.setHolidayDate(rs.getString("holiday_date"));
                holidays.setHolidayDescription(rs.getString("holiday_description"));
                holidays.setStatus(rs.getString("holiday_status"));
                holidays.setAddedBy(rs.getString("added_by"));
                holidays.setAddedOn(rs.getString("added_on"));
                holidays.setLastUpdatedBy(rs.getString("last_updated_by"));
                holidays.setLastUpdatedOn(rs.getString("last_updated_on"));
                return holidays;
            }
        });
        return listHolidays.get(0);
    }
    @Override
    public String[] deleteHoliday(int id){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "DELETE FROM holidays WHERE id="+id;
        logger.info(sql);
        String[] msg = {"",""};
        try{
           jdbcTemplate.execute(sql);
           msg[0] = "Holiday Deleted Successfully!";
           msg[1] = "1";
        }catch(Exception e){
           msg[0] = "some error occured while deleting Holiday, please try again !"; 
           msg[1] = "0";
        }
        return msg;
    }
    /***********************User Leave*************************/
    @Override
    public List<LeaveTypes> listAllLeaveTypes(String username){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "SELECT t1.leave_type,t1.id,t1.category,t2.category FROM leave_types as t1 inner join (select category from user_details where zid='"+username+"') as t2 on t1.category = t2.category group by t1.id";
        logger.info(sql);
        List<LeaveTypes> listAllLeaveTypes = jdbcTemplate.query(sql,new RowMapper<LeaveTypes>(){
            @Override
            public LeaveTypes mapRow(ResultSet rs,int ind) throws SQLException{
                LeaveTypes leaveTypes = new LeaveTypes();
                leaveTypes.setId(rs.getInt("id"));
                leaveTypes.setLeavetype(rs.getString("leave_type"));
                return leaveTypes;
            }
        });
        return listAllLeaveTypes;
    }
    
    @Override
    public String[] saveLeave(ApplyLeave applyLeave,String username) {
       JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql;String AddORUpdate;
        if(applyLeave.getId() == -1){
            sql = "INSERT INTO leave_maintenance(emp_zid,leave_type,leave_count,leave_from,leave_to,reason_for_leave,applied_on,leave_approval_status) VALUES (?,?,?,?,?,?,NOW(),"+applyLeave.getStatus()+");";
            AddORUpdate = "Saved";
        }else{
            sql = "UPDATE leave_maintenance SET emp_zid=?,leave_type=?,leave_count=?,leave_from=?,leave_to=?,reason_for_leave=? WHERE leave_id='"+applyLeave.getId()+"';";
            AddORUpdate = "Updated";
        }
        logger.info(sql);
        String msg[] = {"",""};
        try {
            jdbcTemplate.update(sql,username,applyLeave.getLeaveType(),applyLeave.getLeaveCount(),applyLeave.getLeaveFrom(),applyLeave.getLeaveTo(),applyLeave.getLeaveReason());
            int getid = jdbcTemplate.queryForInt("SELECT LAST_INSERT_ID()");
            applyLeave.setId(getid);
            String sql1 = "SELECT first_name,last_name,email,picture,zid,approval_manager_email,(SELECT leave_type FROM leave_types WHERE id="+applyLeave.getLeaveType()+") as lt,(SELECT leave_id FROM leave_maintenance WHERE emp_zid='"+username+"' ORDER BY leave_id DESC LIMIT 1) as ids FROM user_details WHERE zid='"+username+"'";
            List<Expatriate> ExpatriateDetails = jdbcTemplate.query(sql1,new RowMapper<Expatriate>(){
                @Override
                public Expatriate mapRow(ResultSet rs,int ind) throws SQLException{
             	   Expatriate expatriate = new Expatriate();
             	   expatriate.setFirstName(rs.getString("first_name"));
             	   expatriate.setLastName(rs.getString("last_name"));
             	   expatriate.setEmail(rs.getString("email"));
             	   expatriate.setCategory(rs.getString("lt"));
             	   expatriate.setAssignementDuration(rs.getString("ids"));
             	   expatriate.setPicture(rs.getString("picture"));
             	   expatriate.setUsername(rs.getString("zid"));
             	   expatriate.setApprovalManagerEmail(rs.getString("approval_manager_email"));
                    return expatriate;
                }
            });
            Expatriate expatriate = ExpatriateDetails.get(0);
            
            msg = this.sendMailApplyLeave(expatriate, applyLeave);
            msg[0] += "Successfully "+AddORUpdate;
            msg[1] = "1";
        } catch (Exception e) {
            msg[0] = "Some error occured, please try again!";
            msg[1] = "0";
        }
        return msg;
    }
    
    @Override
    public List<ApplyLeave> listAllLeaves(String username){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "SELECT t1.*,(t2.leave_type) AS lt,IFNULL(ts,0) as ts FROM leave_maintenance AS t1 LEFT JOIN (SELECT leave_type,id FROM leave_types ) AS t2 ON t1.leave_type = t2.id LEFT JOIN (SELECT 1 AS ts,leave_id AS lid FROM leave_maintenance WHERE str_to_date(leave_from,'%Y-%m-%d') < str_to_date(NOW(),'%Y-%m-%d') AND emp_zid = '"+username+"' ) AS t3 ON t1.leave_id= t3.lid WHERE t1.emp_zid = '"+username+"';";
        logger.info(sql);
        List<ApplyLeave> listApplyLeave = jdbcTemplate.query(sql,new RowMapper<ApplyLeave>(){
            @Override
            public ApplyLeave mapRow(ResultSet rs,int ind) throws SQLException{
                ApplyLeave applyLeave = new ApplyLeave();
                applyLeave.setId(rs.getInt("leave_id"));
                applyLeave.setUsername(rs.getString("emp_zid"));
                applyLeave.setLeaveFrom(rs.getString("leave_from"));
                applyLeave.setLeaveTo(rs.getString("leave_to"));
                applyLeave.setLeaveReason(rs.getString("reason_for_leave"));
                applyLeave.setLeaveType(rs.getString("lt"));
                applyLeave.setLeaveCount(rs.getString("leave_count"));
                applyLeave.setAppliedOn(rs.getString("applied_on"));
                applyLeave.setStatus(rs.getString("leave_approval_status"));
                applyLeave.setApprovedBy(rs.getString("approved_by"));
                applyLeave.setIsPrior(rs.getString("ts"));
                return applyLeave;
            }
        });
        return listApplyLeave;
    }
    
    @Override
    public ApplyLeave editLeave(int id) {
	    JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
	    String sql = "SELECT * FROM leave_maintenance WHERE leave_id='"+id+"'";
	    logger.info(sql);
	    List<ApplyLeave> listApplyLeave = jdbcTemplate.query(sql,new RowMapper<ApplyLeave>(){
	        @Override
	        public ApplyLeave mapRow(ResultSet rs,int ind) throws SQLException{
	            ApplyLeave applyLeave = new ApplyLeave();
	            applyLeave.setId(rs.getInt("leave_id"));
	            applyLeave.setLeaveType(rs.getString("leave_type"));
	            applyLeave.setLeaveFrom(rs.getString("leave_from"));
	            applyLeave.setLeaveTo(rs.getString("leave_to"));
	            applyLeave.setLeaveReason(rs.getString("reason_for_leave"));
	            return applyLeave;
	        }
	    });
	    return listApplyLeave.get(0);
    }

    @Override
    public String[] cancelLeave(int id) {
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "UPDATE leave_maintenance SET leave_approval_status=3 WHERE leave_id="+id;
        logger.info(sql);
        String[] msg = {"",""};
        try{
           jdbcTemplate.execute(sql);
           msg[0] = "Leave Cancelled Successfully!";
           msg[1] = "1";
        }catch(Exception e){
           msg[0] = "Some error occured, please try again !"; 
           msg[1] = "0";
        }
        return msg;
    }
    @Override
    public String[] rejectleave(int id){
    	JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "UPDATE leave_maintenance SET leave_approval_status=2 WHERE leave_id="+id;
        logger.info(sql);
        String[] msg = {"",""};
        try{
           jdbcTemplate.execute(sql);
           msg[0] = "Leave Rejected Successfully!";
           msg[1] = "1";
        }catch(Exception e){
           msg[0] = "Some error occured, please try again !"; 
           msg[1] = "0";
        }
        return msg;
    	
    }
    @Override
    public String[] approveleave(int id){
    	JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "UPDATE leave_maintenance SET leave_approval_status=1 WHERE leave_id="+id;
        logger.info(sql);
        String[] msg = {"",""};
        try{
           jdbcTemplate.execute(sql);
           msg[0] = "Leave Approved Successfully!";
           msg[1] = "1";
        }catch(Exception e){
           msg[0] = "Some error occured, please try again !"; 
           msg[1] = "0";
        }
        return msg;
    	
    }
    @Override
    public List<ApplyLeave> listLeavesReport(String username,int leaveType,String status,String leaveFrom,String leaveTo){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String subQuery = "";
        if(leaveType != -1){
            subQuery += " AND t1.leave_type = '"+leaveType+"' ";
        }
        if(!status.equals("-1")){
            subQuery += " AND t1.leave_approval_status ='"+status+"'";
        }
        if(leaveFrom.length() > 0){
            subQuery += " AND t1.leave_from > '"+leaveFrom+"' ";
        }
        if(leaveTo.length() > 0){
            subQuery += " AND t1.leave_to < '"+leaveTo+"'";
        }
        String sql = "SELECT t1.*,(t2.leave_type) AS lt FROM leave_maintenance AS t1 LEFT JOIN (SELECT leave_type,id FROM leave_types ) AS t2 ON t1.leave_type = t2.id WHERE t1.emp_zid='"+username+"' "+subQuery+";";
        logger.info(sql);
        List<ApplyLeave> listApplyLeave = jdbcTemplate.query(sql,new RowMapper<ApplyLeave>(){
            @Override
            public ApplyLeave mapRow(ResultSet rs,int ind) throws SQLException{
                ApplyLeave applyLeave = new ApplyLeave();
                applyLeave.setId(rs.getInt("leave_id"));
                applyLeave.setUsername(rs.getString("emp_zid"));
                applyLeave.setLeaveFrom(rs.getString("leave_from"));
                applyLeave.setLeaveTo(rs.getString("leave_to"));
                applyLeave.setLeaveReason(rs.getString("reason_for_leave"));
                applyLeave.setLeaveType(rs.getString("lt"));
                applyLeave.setLeaveCount(rs.getString("leave_count"));
                applyLeave.setAppliedOn(rs.getString("applied_on"));
                applyLeave.setStatus(rs.getString("leave_approval_status"));
                applyLeave.setApprovedBy(rs.getString("approved_by"));
                return applyLeave;
            }
        });
        return listApplyLeave;
    }
    /**************************Monitor leave***************************/
    @Override
    public List<ApplyLeave> listAllLeavesAdmin(String username,String isAdmin){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String subQuery = "";
        if(isAdmin.equals("A")){
        	subQuery = "WHERE main_category = (SELECT main_category FROM user_details WHERE zid='"+username+"')";
        }
        String sql = "SELECT IFNULL(cats,'nulls') AS cats,t1.*,(t2.leave_type) AS lt FROM leave_maintenance AS t1 LEFT JOIN (SELECT leave_type,id,category as cat FROM leave_types ) AS t2 ON t1.leave_type = t2.id LEFT JOIN (SELECT category AS cats,id AS ids FROM category "+subQuery+") AS t3 ON t2.cat = t3.ids WHERE cats != 'nulls';";
        logger.info(sql);
        List<ApplyLeave> listApplyLeave = jdbcTemplate.query(sql,new RowMapper<ApplyLeave>(){
            @Override
            public ApplyLeave mapRow(ResultSet rs,int ind) throws SQLException{
                ApplyLeave applyLeave = new ApplyLeave();
                applyLeave.setId(rs.getInt("leave_id"));
                applyLeave.setUsername(rs.getString("emp_zid"));
                applyLeave.setLeaveFrom(rs.getString("leave_from"));
                applyLeave.setLeaveTo(rs.getString("leave_to"));
                applyLeave.setLeaveReason(rs.getString("reason_for_leave"));
                applyLeave.setLeaveType(rs.getString("lt"));
                applyLeave.setLeaveCount(rs.getString("leave_count"));
                applyLeave.setAppliedOn(rs.getString("applied_on"));
                applyLeave.setStatus(rs.getString("leave_approval_status"));
                applyLeave.setApprovedBy(rs.getString("approved_by"));
                return applyLeave;
            }
        });
        return listApplyLeave;
    }
    @Override
    public List<LeaveTypes> listAllLeaveTypesBasedOnCategory(String category){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "select id,leave_type from leave_types where category='"+category+"'";
        logger.info(sql);
        List<LeaveTypes> listAllLeaveTypes = jdbcTemplate.query(sql,new RowMapper<LeaveTypes>(){
            @Override
            public LeaveTypes mapRow(ResultSet rs,int ind) throws SQLException{
                LeaveTypes leaveTypes = new LeaveTypes();
                leaveTypes.setId(rs.getInt("id"));
                leaveTypes.setLeavetype(rs.getString("leave_type"));
                return leaveTypes;
            }
        });
        return listAllLeaveTypes;
    }
    @Override
    public List<ApplyLeave> listAllLeavesAdminReport(String category,int leaveType,String status,String leaveFrom,String leaveTo){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String subQuery = "";
        if(!category.equals("-1")){
            subQuery += " AND t2.category ='"+category+"'";
        }
        if(leaveType != -1){
            subQuery += " AND t1.leave_type = '"+leaveType+"' ";
        }
        if(!status.equals("-1")){
            subQuery += " AND t1.leave_approval_status ='"+status+"'";
        }
        if(leaveFrom.length() > 0 && leaveTo.length() > 0){
        	subQuery += "(STR_TO_DATE(t1.leave_from,'%Y-%m-%d') >= STR_TO_DATE('"+leaveFrom+"','%Y-%m-%d')  AND STR_TO_DATE(t1.leave_to,'%Y-%m-%d') <= STR_TO_DATE('"+leaveTo+"','%Y-%m-%d')) OR (STR_TO_DATE(t1.leave_to,'%Y-%m-%d') > STR_TO_DATE('"+leaveFrom+"','%Y-%m-%d') AND STR_TO_DATE(t1.leave_from,'%Y-%m-%d') <= STR_TO_DATE('"+leaveTo+"','%Y-%m-%d')) ";
        }else{
        	if(leaveFrom.length() > 0){
                subQuery += " AND (STR_TO_DATE(t1.leave_from,'%Y-%m-%d') >= STR_TO_DATE('"+leaveFrom+"','%Y-%m-%d') OR (STR_TO_DATE(t1.leave_to,'%Y-%m-%d') > STR_TO_DATE('"+leaveFrom+"','%Y-%m-%d') AND STR_TO_DATE(t1.leave_from,'%Y-%m-%d') <= STR_TO_DATE('"+leaveFrom+"','%Y-%m-%d')))";
            }
            if(leaveTo.length() > 0){
                subQuery += " AND (STR_TO_DATE(t1.leave_to,'%Y-%m-%d') <= STR_TO_DATE('"+leaveTo+"','%Y-%m-%d') OR (STR_TO_DATE(t1.leave_from,'%Y-%m-%d') < STR_TO_DATE('"+leaveTo+"','%Y-%m-%d') AND STR_TO_DATE(t1.leave_to,'%Y-%m-%d') > STR_TO_DATE('"+leaveTo+"','%Y-%m-%d') ))";
            }
        }
        
        String sql = "SELECT t1.*,(t2.leave_type) AS lt,(t2.category) AS category FROM leave_maintenance AS t1 LEFT JOIN (SELECT leave_type,id,category FROM leave_types ) AS t2 ON t1.leave_type = t2.id WHERE t1.leave_id != -1 "+subQuery+" ORDER BY t1.leave_from DESC;";
        logger.info(sql);
        List<ApplyLeave> listApplyLeave = jdbcTemplate.query(sql,new RowMapper<ApplyLeave>(){
            @Override
            public ApplyLeave mapRow(ResultSet rs,int ind) throws SQLException{
                ApplyLeave applyLeave = new ApplyLeave();
                applyLeave.setId(rs.getInt("leave_id"));
                applyLeave.setUsername(rs.getString("emp_zid"));
                applyLeave.setLeaveFrom(rs.getString("leave_from"));
                applyLeave.setLeaveTo(rs.getString("leave_to"));
                applyLeave.setLeaveReason(rs.getString("reason_for_leave"));
                applyLeave.setLeaveType(rs.getString("lt"));
                applyLeave.setLeaveCount(rs.getString("leave_count"));
                applyLeave.setAppliedOn(rs.getString("applied_on"));
                applyLeave.setStatus(rs.getString("leave_approval_status"));
                applyLeave.setApprovedBy(rs.getString("approved_by"));
                return applyLeave;
            }
        });
        return listApplyLeave;
    }
    /*************************Login & Password**************************/
    @Override
    public String[] forgotPassword(String username){
    	JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String selectQuery = "SELECT password,email,first_name,last_name FROM users  AS t1 LEFT JOIN (SELECT email,first_name,last_name,zid FROM user_details) AS t2 ON t1.username= t2.zid WHERE username='"+username+"' LIMIT 1";
        logger.info(selectQuery);
        List<String[]> getPassword = jdbcTemplate.query(selectQuery, new RowMapper<String[]>() {
            @Override
            public String[] mapRow(ResultSet rs, int i) throws SQLException {
                String[] passwordcheck = {rs.getString("password"),rs.getString("email"),rs.getString("first_name"),rs.getString("last_name")};
                return passwordcheck;
            }
        });
        String msg[] = {"",""};
        if(getPassword.size() != 0){
        	try{
        		String str[] = getPassword.get(0);
        		String name = str[2]+" "+str[3];
        		msg = this.sendMailForgotpassword(str[1],str[2],str[0],name);
        	}catch (Exception e) {
                msg[0] = "Some error occured, please try again!";
                msg[1] = "0";
            }
        }else{
        	msg[0] = "Username not found!";
            msg[1] = "0";
        }
        return msg;
    }
    @Override
    public String[] changePassword(String username,String password,String newpassword){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String selectQuery = "SELECT password FROM users WHERE username='"+username+"' LIMIT 1";
        logger.info(selectQuery);
        List<String> listRoles = jdbcTemplate.query(selectQuery, new RowMapper<String>() {
            @Override
            public String mapRow(ResultSet rs, int i) throws SQLException {
                String passwordcheck = rs.getString("password");
                return passwordcheck;
            }
        });
        String verify = listRoles.get(0);
        String[] msg = {"",""};
        if(verify.equals(password)){
            String sqlUpdatePassword = "UPDATE users SET password=? WHERE username=?";
            logger.info(sqlUpdatePassword);
            try {
                jdbcTemplate.update(sqlUpdatePassword,newpassword,username);
                msg[0] = "Password Changed Successfully";
                msg[1] = "1";
            } catch (Exception e) {
                msg[0] = "Some error occured, please try again!";
                msg[1] = "0";
            }
        }else{
            msg[1] = "Current password is incorrect.";
            msg[1] = "0";
        }
        return msg;
    }
    @Override
    public void lastLogin(String username){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String saveLastLogin = "UPDATE user_details SET last_login=NOW() WHERE zid='"+username+"'";
        logger.info(saveLastLogin);
        jdbcTemplate.update(saveLastLogin);
    }
    /*************************Helper Methods**************************/
    @Override
    public String getPrincipals(Principal user){
        String username = "";
        if(user != null){
            username = user.getName();
        }
        return username;
    }
    @Override
    public String[] getUserIcon(Principal user){
        String[] result = {"","","","",""};
        String usericon = "";
        if(user != null){
            usericon = user.getName();
            JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
            String sql = "SELECT picture,first_name,last_name,main_category,category FROM user_details WHERE zid='"+usericon+"';";
            logger.info(sql);
            List<String[]> listExpatriate = jdbcTemplate.query(sql,new RowMapper<String[]>(){
                @Override
                public String[] mapRow(ResultSet rs,int ind) throws SQLException{
                    String[] str = {rs.getString("picture"),rs.getString("first_name"),rs.getString("last_name"),rs.getString("main_category"),rs.getString("category")};
                    return str;
                }
            });
            result = listExpatriate.get(0);
        }
        return result;
    }
    @Override
    public String[] sendMail(String mailto,String empid,String password,String username){
        String mailFrom = "expatriates.admin@rntbci.com";
        //Get the session object  
        Properties props = new Properties();  
        props.put("mail.smtp.host", "wsmtp.mc2.renault.fr");  
        props.put("mail.smtp.socketFactory.port", "25");  
        props.put("mail.smtp.socketFactory.class",  
                  "javax.net.ssl.SSLSocketFactory");  
          
        props.put("mail.smtp.port", "25");  
        Session session = Session.getInstance(props);  
        String str[] = {"",""};
        //compose message  
        try {  
         MimeMessage message = new MimeMessage(session);  
         message.setFrom(new InternetAddress(mailFrom));//change accordingly  
         message.addRecipient(Message.RecipientType.TO,new InternetAddress(mailto));  
         message.setSubject("Welcome to elms"); 
         message.setContent("<div style='width:100%;box-sizing:border-box;background:#ccc;'>"
                 + "<h2 style='width:100%;padding-left:10px; padding-top: 10px; padding-right:10px; padding-bottom:10px;margin:0px;background:#0099ff;color:#fff;box-sizing:border-box;'>Welcome "+username+"</h2>"
                 + "<p style='width:100%;padding-left:10px; padding-top: 10px; padding-right:10px; padding-bottom:10px;font-weight:bold;box-sizing:border-box;'>You are successfully added to elms Domain and you can now login to our network website and now you can apply and monitor your leave in this portal by using these credentials</p>"
                 + "<span style='width:100%;padding-left:10px; padding-top: 10px; padding-right:10px; padding-bottom:10px;font-weight:bold;box-sizing:border-box;'>Username : "+empid+"</span>"
                 + "<br/><span style='width:100%;padding-left:10px; padding-top: 10px; padding-right:10px; padding-bottom:10px;font-weight:bold;box-sizing:border-box;'>Password : "+password+"</span><p>Please do change your password in your first login!</p>"
                 + "<hr/><p style='width:100%;padding-left:10px; padding-top: 10px; padding-right:10px; padding-bottom:10px;font-weight:bold;box-sizing:border-box;'>Thanks & Regards,</p>"
                 + "<span style='width:100%;padding-left:10px; padding-top: 10px; padding-right:10px; padding-bottom:10px;font-weight:bold;box-sizing:border-box;'><i>Support team elms</i></span><br/></div>","text/html;charset=utf-8");

         //send message  
            try {
                Transport.send(message);
                str[0] = "Mail sent successfully!";
    	    	str[1] = "1";
                logger.info("message sent successfully");
            } catch (Exception e) {
            	str[0] = "Error while sending mail!";
    	    	str[1] = "0";
                logger.info(e);
            }
        } catch (MessagingException e) {
        	str[0] = "Error while sending mail!";
	    	str[1] = "0";
	    	throw new RuntimeException(e);
	    	}  
        return str;
       }
    @Override
    public String[] sendMailAdminAddOJF(String mailto,String password){
    	String mailFrom = "expatriates.admin@rntbci.com";
        //Get the session object  
        Properties props = new Properties();  
        props.put("mail.smtp.host", "wsmtp.mc2.renault.fr");  
        props.put("mail.smtp.socketFactory.port", "25");  
        props.put("mail.smtp.socketFactory.class",  
                  "javax.net.ssl.SSLSocketFactory");  
          
        props.put("mail.smtp.port", "25");  
        Session session = Session.getInstance(props);  
        String str[] = {"",""};
        //compose message  
        try {  
         MimeMessage message = new MimeMessage(session);  
         message.setFrom(new InternetAddress(mailFrom));//change accordingly  
         message.addRecipient(Message.RecipientType.TO,new InternetAddress(mailto));  
         message.setSubject("Kindly fill your basic details in our portal"); 
         message.setContent("<div style='width:100%;box-sizing:border-box;background:#ccc;'>"
                 + "<h2 style='width:100%;padding-left:10px; padding-top: 10px; padding-right:10px; padding-bottom:10px;margin:0px;background:#0099ff;color:#fff;box-sizing:border-box;'>Welcome Expatriate</h2>"
                 + "<p style='width:100%;padding-left:10px; padding-top: 10px; padding-right:10px; padding-bottom:10px;font-weight:bold;box-sizing:border-box;'>You are successfully added to our online joining formalities members list, kindly fill your details in our portal and avoid filling number of forms with same details. our portal avails you a easy print option to take printouts with filled form with details</p>"
                 + "<span style='width:100%;padding-left:10px; padding-top: 10px; padding-right:10px; padding-bottom:10px;font-weight:bold;box-sizing:border-box;'>Username : "+mailto+"</span>"
                 + "<br/><span style='width:100%;padding-left:10px; padding-top: 10px; padding-right:10px; padding-bottom:10px;font-weight:bold;box-sizing:border-box;'>Password : "+password+"</span><p>Please do change your password in your first login!</p>"
                 + "<hr/><p style='width:100%;padding-left:10px; padding-top: 10px; padding-right:10px; padding-bottom:10px;font-weight:bold;box-sizing:border-box;'>Thanks & Regards,</p>"
                 + "<span style='width:100%;padding-left:10px; padding-top: 10px; padding-right:10px; padding-bottom:10px;font-weight:bold;box-sizing:border-box;'><i>Support team elms</i></span><br/></div>","text/html;charset=utf-8");

         //send message  
            try {
                Transport.send(message);
                str[0] = "OJF Member Successfully saved!";
    	    	str[1] = "1";
                logger.info("message sent successfully");
            } catch (Exception e) {
            	str[0] = "OJF Member Successfully saved but some error occured while sending email.";
    	    	str[1] = "0";
                logger.info(e);
            }
         

           

        } catch (MessagingException e) {
        	str[0] = "OJF Member Successfully saved but some error occured while sending email.";
	    	str[1] = "0";
	    	throw new RuntimeException(e);
	    	}  
        return str;
    }
    @Override
    public String[] sendMailForgotpassword(String mailto,String empid,String password,String username){
        String mailFrom = "expatriates.admin@rntbci.com";
        //Get the session object  
        Properties props = new Properties();  
        props.put("mail.smtp.host", "wsmtp.mc2.renault.fr");  
        props.put("mail.smtp.socketFactory.port", "25");  
        props.put("mail.smtp.socketFactory.class",  
                  "javax.net.ssl.SSLSocketFactory");  
          
        props.put("mail.smtp.port", "25");  
        Session session = Session.getInstance(props);  

        //compose message
        String[] str = {"",""};
        try {  
         MimeMessage message = new MimeMessage(session);  
         message.setFrom(new InternetAddress(mailFrom));//change accordingly  
         message.addRecipient(Message.RecipientType.TO,new InternetAddress(mailto));  
         message.setSubject("Forgot password request triggered"); 
         message.setContent("<div style='width:100%;box-sizing:border-box;background:#ccc;'>"
                 + "<h2 style='width:100%;padding-left:10px; padding-top: 10px; padding-right:10px; padding-bottom:10px;margin:0px;background:#0099ff;color:#fff;box-sizing:border-box;'>Hi "+username+"</h2>"
                 + "<br/><span style='width:100%;padding-left:10px; padding-top: 10px; padding-right:10px; padding-bottom:10px;font-weight:bold;box-sizing:border-box;'>Password : "+password+"</span><p>Please do change your password in your first login!</p>"
                 + "<hr/><p style='width:100%;padding-left:10px; padding-top: 10px; padding-right:10px; padding-bottom:10px;font-weight:bold;box-sizing:border-box;'>Thanks & Regards,</p>"
                 + "<span style='width:100%;padding-left:10px; padding-top: 10px; padding-right:10px; padding-bottom:10px;font-weight:bold;box-sizing:border-box;'><i>Support team elms</i></span><br/></div>","text/html;charset=utf-8");
         
         //send message  
            try {
                Transport.send(message);
                str[0] = "Mail sent successfully!";
                str[1] = "1";
                logger.info("message sent successfully");
            } catch (Exception e) {
            	str[0] = "Error while sending mail!";
            	str[1] = "0";
                logger.info(e);
            }
         

           

        } catch (MessagingException e) {
        	str[0] = "Error while sending mail!";
	    	str[1] = "0";
        	throw new RuntimeException(e);
        }  
        return str;
   }
    @Override
    public String[] sendMailApplyLeave(Expatriate expatriate,ApplyLeave applyLeave){
        String mailFrom = "leave.application@elms.com";
        //Get the session object  
        Properties props = new Properties();  
        props.put("mail.smtp.host", "wsmtp.mc2.renault.fr");  
        props.put("mail.smtp.socketFactory.port", "25");  
        props.put("mail.smtp.socketFactory.class",  
                  "javax.net.ssl.SSLSocketFactory");  
          
        props.put("mail.smtp.port", "25");  
        Session session = Session.getInstance(props);  
        String[] str = {"",""};
        //compose message  
        try {  
         MimeMessage message = new MimeMessage(session);  
         message.setFrom(new InternetAddress(mailFrom));//change accordingly  
         message.addRecipient(Message.RecipientType.TO,new InternetAddress(expatriate.getApprovalManagerEmail()));  
         message.setSubject("Leave Application"); 
         message.setContent("<div style='width:100%;box-sizing:border-box;background:#ccc;'>"
                 + "<h2 style='width:100%;padding-left:10px; padding-top: 10px; padding-right:10px; padding-bottom:10px;margin:0px;background:#0099ff;color:#fff;box-sizing:border-box;'>&nbsp;&nbsp;An application for leave</h2>"
                 + "<p style='width:100%;padding-left:10px; padding-top: 10px; padding-right:10px; padding-bottom:10px;font-weight:bold;box-sizing:border-box;'>&nbsp;&nbsp;Mr/Mrs/Ms . "+expatriate.getFirstName() +" "+expatriate.getLastName()+" ("+expatriate.getUsername()+") Has applied for leave .</p>"
                 + "<span style='width:100%;padding-left:10px; padding-top: 10px; padding-right:10px; padding-bottom:10px;font-weight:bold;box-sizing:border-box;'>&nbsp;&nbsp;Leave Type : "+expatriate.getCategory()+"</span>"
                 + "<br/><span style='width:100%;padding-left:10px; padding-top: 10px; padding-right:10px; padding-bottom:10px;font-weight:bold;box-sizing:border-box;'>&nbsp;&nbsp;Leave From : "+applyLeave.getLeaveFrom()+"</span>"
                 + "<br/><span style='width:100%;padding-left:10px; padding-top: 10px; padding-right:10px; padding-bottom:10px;font-weight:bold;box-sizing:border-box;'>&nbsp;&nbsp;Leave Till : "+applyLeave.getLeaveTo()+"</span>"
                 + "<br/><span style='width:100%;padding-left:10px; padding-top: 10px; padding-right:10px; padding-bottom:10px;font-weight:bold;box-sizing:border-box;'>&nbsp;&nbsp;No.of Days : "+applyLeave.getLeaveCount()+"</span>"
                 + "<br/><span style='width:100%;padding-left:10px; padding-top: 10px; padding-right:10px; padding-bottom:10px;font-weight:bold;box-sizing:border-box;'>&nbsp;&nbsp;Leave reason : "+applyLeave.getLeaveReason()+"</span>"
                 + "<hr/><p style='width:100%;padding-left:10px; padding-top: 10px; padding-right:10px; padding-bottom:10px;font-weight:bold;box-sizing:border-box;'><a href='http://10.244.13.135:7070/elms/rejectleave?id="+expatriate.getAssignementDuration()+"' style='background:red;width:100px;height:40px;text-align:center;line-height:40px;color:#ffffff;text-decoration:none;'>&nbsp;&nbsp;Reject&nbsp;&nbsp;</a>&nbsp;&nbsp;<a href='http://10.244.13.135:7070/elms/approveleave?id="+expatriate.getAssignementDuration()+"' style='background:green;width:100px;height:40px;text-align:center;line-height:40px;color:#ffffff;text-decoration:none;'>&nbsp;&nbsp;Approve&nbsp;&nbsp;</a></p><br/></div>","text/html;charset=utf-8");

         //send message  
            try {
                Transport.send(message);  
                str[0] = "Mail sent successfully!";
    	    	str[1] = "0";
    	    	logger.info("message sent successfully");
            } catch (Exception e) {
            	str[0] = "Error while sending mail!";
    	    	str[1] = "0";
                logger.info(e);
            }
         
        } catch (MessagingException e) {
        	str[0] = "Error while sending mail!";
	    	str[1] = "0";
        	throw new RuntimeException(e);
        	
    	}  
        return str;
       }  
    public String[] readExcel(MultipartFile file,String username) {
        String msg[] = {"",""};
        if (!file.isEmpty()) {
                try {
                    byte[] bytes = file.getBytes();
                    BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(new File(username)));
                    stream.write(bytes);
                    stream.close();
                    msg[0] = "File Uploaded Successfully , but there is some issue in column values!";
                    msg[1] = "0";
                    try {

                        FileInputStream file1 = new FileInputStream(new File(username));
                        XSSFWorkbook workbook = new XSSFWorkbook(file1);
                        XSSFSheet sheet = workbook.getSheetAt(0);
                        Iterator<Row> rowIterator = sheet.iterator();
                        rowIterator.next();
                        while(rowIterator.hasNext()){
                            Row row = rowIterator.next();
                            Iterator<Cell> cellIterator = row.cellIterator();
                            int cellcounter = 0;
                            Expatriate expatriate =  new Expatriate();
                            expatriate.setId(-1);
                            expatriate.setPicture("resources/images/avatar.jpg");
                            while(cellIterator.hasNext()){
                                cellcounter++;
                                Cell cell = cellIterator.next();
                                String membervalue = "";
                                cell.setCellType(1);
                                switch(cell.getCellType()) {
                                    case Cell.CELL_TYPE_BOOLEAN:
                                        membervalue += cell.getBooleanCellValue();
                                    break;
                                    case Cell.CELL_TYPE_NUMERIC:
                                        membervalue += cell.getNumericCellValue();
                                    break;
                                    case Cell.CELL_TYPE_STRING:
                                        membervalue += cell.getStringCellValue();
                                    break;
                                }
                                if(cellcounter == 1){
                                    if(membervalue.equals("")){
                                        break;
                                    }
                                }
                                if(cellcounter == 1){expatriate.setUsername(membervalue);}
                                if(cellcounter == 2){expatriate.setEmail(membervalue);}
                                if(cellcounter == 3){expatriate.setFirstName(membervalue);}
                                if(cellcounter == 4){expatriate.setLastName(membervalue);}
                                if(cellcounter == 5){expatriate.setCategory(membervalue);}
                                if(cellcounter == 6){expatriate.setDesignation(membervalue);}
                                if(cellcounter == 7){expatriate.setDepartment(membervalue);}
                                if(cellcounter == 8){expatriate.setApprovalManager(membervalue);}
                                if(cellcounter == 9){expatriate.setApprovalManagerEmail(membervalue);}
                                if(cellcounter == 10){membervalue = membervalue.replace(".", "-");expatriate.setAssignmentFrom(membervalue);}
                                if(cellcounter == 11){membervalue = membervalue.replace(".", "-");expatriate.setAssignmentTo(membervalue);}
                                if(cellcounter == 12){expatriate.setRnNumber(membervalue);}
                                if(cellcounter == 13){expatriate.setHomeCountry(membervalue);}
                                if(cellcounter == 14){expatriate.setEnabled(membervalue);}
                                if(cellcounter == 15){expatriate.setLeaveCount(membervalue);}
                                if(cellcounter == 15){
                                    msg = saveExpatriates(expatriate,username);
                                    break;
                                }
                            }
                        }
                        //file.close();
                    } catch (FileNotFoundException e) {
                    } catch (IOException e) {
                    }
                } catch (Exception e) {
                    msg[0] = "Some error occured in file upload!";
                    msg[1] = "0";
                }
            } else {
                    msg[0] = "Some error occured in file upload,file is empty!";
                    msg[1] = "0";
            }
        logger.info("EXCEL File Read over");
        return msg;
    }    
    
    /**********************************OJF********************************/
    @Override
    public String[] saveOJFByExpat(OJFGeneral ojfGeneral,String username,int issubmit){
    	JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql,sql2,sql1,AddORUpdate;
        int index = username.indexOf("@");
        if(index < 0){
        	String getIdsql = "SELECT COUNT(id) FROM user_details WHERE zid = (SELECT expatid FROM ojf_general_details WHERE id="+ojfGeneral.getId()+") ";
        	logger.info(getIdsql);
        	int ids = jdbcTemplate.queryForInt(getIdsql) ;
        	logger.info(ids);
        	if(ids == 0){
        		logger.info("Empty::: No Expatriate Found");
        	}else{
        		String getIdsqldata = "SELECT id FROM user_details WHERE zid = (SELECT expatid FROM ojf_general_details WHERE id="+ojfGeneral.getId()+") ";
            	logger.info(getIdsql);
            	ids = jdbcTemplate.queryForInt(getIdsqldata) ;
        		logger.info("Not Empty::: Expatriate Found");
        		sql2 = "UPDATE user_details SET email='"+ojfGeneral.getEmail()+"',first_name='"+ojfGeneral.getFirstName()+"',last_name='"+ojfGeneral.getLastName()+"',designation='"+ojfGeneral.getDesignation()+"',picture='"+ojfGeneral.getPhoto()+"',department='"+ojfGeneral.getDepartment()+"',approval_manager='"+ojfGeneral.getSuperiorHomeName()+"',assignment_from='"+ojfGeneral.getAssignmentFrom()+"',assignment_to='"+ojfGeneral.getAssignmentTo()+"',last_updated_by='"+username+"',last_updated_date=NOW() WHERE id="+ids;
        		logger.info(sql2);
            	jdbcTemplate.update(sql2);
        	}
        	
        }
        logger.info(index);
        AddORUpdate = "Updat";
        String msg[] = {"",""};
        try {
        	sql = "UPDATE ojf_general_details SET first_name = ? , last_name = ? ,gender_status = ? , guardian_name = ? , id_number = ? , photo = ? , designation = ? , department = ? , email = ? , contact_number = ? , gender = ? , blood_group = ? , height = ? , weight = ? , dob = ? , home_country_address = ? , host_country_address = ? , emergency_relation = ? , emergency_contact_person = ? , emergency_contact_number = ? , emergency_one = ? , emergency_two = ? , emergency_three = ? , emergency_four = ? , superior_home_company_name = ? , superior_home_company_dept = ? , superior_home_company_designation = ? , superior_host_company_name = ? , superior_host_company_dept = ? , superior_host_company_designation = ? , arrival_date = ? , depature_date = ? , offer_date = ? , join_date = ? , assignment_from = ? , assignment_to = ? , expat_nationality = ? , expat_visa_type = ? , expat_visa_expiry = ? , expat_passport_number = ? , expat_place_of_issue = ? , expat_passport_expiry_date = ? , expat_family_one = ? , expat_family_two = ? , expat_family_three = ? , expat_family_four = ? , expat_medication = ? , expat_others = ? , lastupdated = NOW(),submission = '"+issubmit+"',userid=? WHERE id = "+ojfGeneral.getId();
            sql1 ="UPDATE user_details SET first_name = ? , last_name = ? , picture = ? , designation = ? , department = ? ,email = ? ,approval_manager = ? WHERE zid='"+ojfGeneral.getExpatId()+"'";
            logger.info(sql);
            logger.info(sql1);
            jdbcTemplate.update(sql,ojfGeneral.getFirstName(),ojfGeneral.getLastName(),ojfGeneral.getGenderStatus(),ojfGeneral.getGuardianName(),ojfGeneral.getiDNumber(),ojfGeneral.getPhoto(),ojfGeneral.getDesignation(),ojfGeneral.getDepartment(),ojfGeneral.getEmail(),ojfGeneral.getPhone(),ojfGeneral.getGender(),ojfGeneral.getBlood(),ojfGeneral.getHeight(),ojfGeneral.getWeight(),ojfGeneral.getDob(),ojfGeneral.getHomeAddress(),ojfGeneral.getHostAddress(),ojfGeneral.getEmergencyPrimaryRelation(),ojfGeneral.getEmergencyPrimaryPerson(),ojfGeneral.getEmergencyPrimaryNumber(),ojfGeneral.getEmergencyOne(),ojfGeneral.getEmergencyTwo(),ojfGeneral.getEmergencyThree(),ojfGeneral.getEmergencyFour(),ojfGeneral.getSuperiorHomeName(),ojfGeneral.getSuperiorHomeDept(),ojfGeneral.getSuperiorHomeDes(),ojfGeneral.getSuperiorHostName(),ojfGeneral.getSuperiorHostDept(),ojfGeneral.getSuperiorHostDes(),ojfGeneral.getArrivalDate(),ojfGeneral.getDepatureDate(),ojfGeneral.getOfferDate(),ojfGeneral.getJoiningDate(),ojfGeneral.getAssignmentFrom(),ojfGeneral.getAssignmentTo(),ojfGeneral.getExpatNationality(),ojfGeneral.getExpatVISAType(),ojfGeneral.getExpatVISAExpiry(),ojfGeneral.getExpatPassportNumber(),ojfGeneral.getExpatPlaceOfIssue(),ojfGeneral.getExpatPassportExpiry(),ojfGeneral.getExpatFamilyVISAOne(),ojfGeneral.getExpatFamilyVISATwo(),ojfGeneral.getExpatFamilyVISThree(),ojfGeneral.getExpatFamilyVISAFour(),ojfGeneral.getExpatMedication(),ojfGeneral.getExpatOthers(),ojfGeneral.getEmail());
            jdbcTemplate.update(sql1,ojfGeneral.getFirstName(),ojfGeneral.getLastName(),ojfGeneral.getPhoto(),ojfGeneral.getDesignation(),ojfGeneral.getDepartment(),ojfGeneral.getEmail(),ojfGeneral.getSuperiorHostName());
            msg[0] = "General Details Successfully "+AddORUpdate+"ed";
            msg[1] = "1";
        } catch (Exception e) {
            msg[0] = "Some error occured in "+AddORUpdate+"ing general Details , please try again!";
            msg[1] = "0";
            logger.info(e);
        }
        return msg;
    }
    @Override
    public OJFGeneral expatSpecificDetails(String username){
        JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "SELECT * FROM ojf_general_details WHERE (userid='"+username+"' OR expatid='"+username+"') LIMIT 1";
        logger.info(sql);
        List<OJFGeneral> listOJFGeneral = jdbcTemplate.query(sql,new RowMapper<OJFGeneral>(){
            @Override
            public OJFGeneral mapRow(ResultSet rs,int ind) throws SQLException{
            	OJFGeneral oJFGeneral = new OJFGeneral();
            	oJFGeneral.setId(rs.getInt("id"));
            	oJFGeneral.setFirstName(rs.getString("first_name"));
            	oJFGeneral.setLastName(rs.getString("last_name"));
            	oJFGeneral.setGenderStatus(rs.getString("gender_status"));
            	oJFGeneral.setGuardianName(rs.getString("guardian_name"));            	
            	oJFGeneral.setiDNumber(rs.getString("id_number"));
            	oJFGeneral.setPhoto(rs.getString("photo"));
            	oJFGeneral.setDesignation(rs.getString("designation"));
            	oJFGeneral.setDepartment(rs.getString("department"));
            	oJFGeneral.setEmail(rs.getString("email"));
            	oJFGeneral.setGender(rs.getString("gender"));
            	oJFGeneral.setPhone(rs.getString("contact_number"));
            	oJFGeneral.setBlood(rs.getString("blood_group"));
            	oJFGeneral.setHeight(rs.getString("height"));
            	oJFGeneral.setWeight(rs.getString("weight"));
            	oJFGeneral.setDob(rs.getString("dob"));
            	oJFGeneral.setHomeAddress(rs.getString("home_country_address"));
            	oJFGeneral.setHostAddress(rs.getString("host_country_address"));
            	oJFGeneral.setEmergencyPrimaryPerson(rs.getString("emergency_contact_person"));
            	oJFGeneral.setEmergencyPrimaryNumber(rs.getString("emergency_contact_number"));
            	oJFGeneral.setEmergencyPrimaryRelation(rs.getString("emergency_relation"));
            	oJFGeneral.setEmergencyOne(rs.getString("emergency_one"));
            	oJFGeneral.setEmergencyTwo(rs.getString("emergency_two"));
            	oJFGeneral.setEmergencyThree(rs.getString("emergency_three"));
            	oJFGeneral.setEmergencyFour(rs.getString("emergency_four"));
            	oJFGeneral.setSuperiorHomeName(rs.getString("superior_home_company_name"));
            	oJFGeneral.setSuperiorHomeDes(rs.getString("superior_home_company_designation"));
            	oJFGeneral.setSuperiorHomeDept(rs.getString("superior_home_company_dept"));
            	oJFGeneral.setSuperiorHostName(rs.getString("superior_host_company_name"));
            	oJFGeneral.setSuperiorHostDes(rs.getString("superior_host_company_designation"));
            	oJFGeneral.setSuperiorHostDept(rs.getString("superior_host_company_dept"));
            	oJFGeneral.setArrivalDate(rs.getString("arrival_date"));
            	oJFGeneral.setDepatureDate(rs.getString("depature_date"));
            	oJFGeneral.setOfferDate(rs.getString("offer_date"));
            	oJFGeneral.setJoiningDate(rs.getString("join_date"));
            	oJFGeneral.setAssignmentFrom(rs.getString("assignment_from"));
            	oJFGeneral.setAssignmentTo(rs.getString("assignment_to"));
            	oJFGeneral.setExpatNationality(rs.getString("expat_nationality"));
            	oJFGeneral.setExpatVISAType(rs.getString("expat_visa_type"));
            	oJFGeneral.setExpatVISAExpiry(rs.getString("expat_visa_expiry"));
            	oJFGeneral.setExpatPassportNumber(rs.getString("expat_passport_number"));
            	oJFGeneral.setExpatPlaceOfIssue(rs.getString("expat_place_of_issue"));
            	oJFGeneral.setExpatPassportExpiry(rs.getString("expat_passport_expiry_date"));
            	oJFGeneral.setExpatFamilyVISAOne(rs.getString("expat_family_one"));
            	oJFGeneral.setExpatFamilyVISATwo(rs.getString("expat_family_two"));
            	oJFGeneral.setExpatFamilyVISThree(rs.getString("expat_family_three"));
            	oJFGeneral.setExpatFamilyVISAFour(rs.getString("expat_family_four"));
            	oJFGeneral.setExpatMedication(rs.getString("expat_medication"));
            	oJFGeneral.setExpatOthers(rs.getString("expat_others"));
            	oJFGeneral.setUserID(rs.getString("userid"));
            	oJFGeneral.setExpatId(rs.getString("expatid"));
            	
                return oJFGeneral;
            }
        });
        
        return listOJFGeneral.get(0);
    }
}