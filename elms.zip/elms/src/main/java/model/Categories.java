
package model;

/**
 *
 * @author z015675
 */
public class Categories {
    private int id;
    private String mainCategory;
    private String category;
    private String mainCategoryDetails;
    private String mainCategoryLocation;
    private String addedBy;
    private String addedOn;
    private String lastupdatedOn;
    private String lastupdatedBy;
    private String status;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMainCategory() {
        return mainCategory;
    }

    public void setMainCategory(String mainCategory) {
        this.mainCategory = mainCategory;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getMainCategoryDetails() {
        return mainCategoryDetails;
    }

    public void setMainCategoryDetails(String mainCategoryDetails) {
        this.mainCategoryDetails = mainCategoryDetails;
    }

    public String getMainCategoryLocation() {
        return mainCategoryLocation;
    }

    public void setMainCategoryLocation(String mainCategoryLocation) {
        this.mainCategoryLocation = mainCategoryLocation;
    }

    public String getAddedBy() {
        return addedBy;
    }

    public void setAddedBy(String addedBy) {
        this.addedBy = addedBy;
    }

    public String getAddedOn() {
        return addedOn;
    }

    public void setAddedOn(String addedOn) {
        this.addedOn = addedOn;
    }

    public String getLastupdatedOn() {
        return lastupdatedOn;
    }

    public void setLastupdatedOn(String lastupdatedOn) {
        this.lastupdatedOn = lastupdatedOn;
    }

    public String getLastupdatedBy() {
        return lastupdatedBy;
    }

    public void setLastupdatedBy(String lastupdatedBy) {
        this.lastupdatedBy = lastupdatedBy;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
