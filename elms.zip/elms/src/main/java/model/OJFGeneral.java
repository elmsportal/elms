package model;

public class OJFGeneral {
	public int id;
	public String firstName;
	public String lastName;
	public String genderStatus;
	public String guardianName;
	public String iDNumber;
	public String photo;
	public String designation;
	public String department;
	public String email;
	public String phone;
	public String gender;
	public String blood;
	public String height;
	public String weight;
	public String dob;
	public String homeAddress;
	public String hostAddress;
	public String emergencyPrimaryRelation;
	public String emergencyPrimaryPerson;
	public String emergencyPrimaryNumber;
	public String emergencyOne;
	public String emergencyTwo;
	public String emergencyThree;
	public String emergencyFour;
	public String superiorHomeName;
	public String superiorHomeDes;
	public String superiorHomeDept;
	public String superiorHostName;
	public String superiorHostDes;
	public String superiorHostDept;
	public String arrivalDate;
	public String depatureDate;
	public String offerDate;
	public String joiningDate;
	public String assignmentFrom;
	public String assignmentTo;
	public String expatNationality;
	public String expatVISAType;
	public String expatVISAExpiry;
	public String expatPassportNumber;
	public String expatPlaceOfIssue;
	public String expatPassportExpiry;
	public String expatFamilyVISAOne;
	public String expatFamilyVISATwo;
	public String expatFamilyVISThree;
	public String expatFamilyVISAFour;
	public String expatMedication;
	public String expatOthers;
	public String lastupdated;
	public String userID;
	public String expatId;
	
	/**
	 * @return the expatId
	 */
	public String getExpatId() {
		return expatId;
	}
	/**
	 * @param expatId the expatId to set
	 */
	public void setExpatId(String expatId) {
		this.expatId = expatId;
	}
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}
	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}
	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	/**
	 * @return the iDNumber
	 */
	public String getiDNumber() {
		return iDNumber;
	}
	/**
	 * @param iDNumber the iDNumber to set
	 */
	public void setiDNumber(String iDNumber) {
		this.iDNumber = iDNumber;
	}
	/**
	 * @return the photo
	 */
	public String getPhoto() {
		return photo;
	}
	/**
	 * @param photo the photo to set
	 */
	public void setPhoto(String photo) {
		this.photo = photo;
	}
	/**
	 * @return the designation
	 */
	public String getDesignation() {
		return designation;
	}
	/**
	 * @param designation the designation to set
	 */
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	/**
	 * @return the department
	 */
	public String getDepartment() {
		return department;
	}
	/**
	 * @param department the department to set
	 */
	public void setDepartment(String department) {
		this.department = department;
	}
	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	/**
	 * @return the phone
	 */
	public String getPhone() {
		return phone;
	}
	/**
	 * @param phone the phone to set
	 */
	public void setPhone(String phone) {
		this.phone = phone;
	}
	/**
	 * @return the gender
	 */
	public String getGender() {
		return gender;
	}
	/**
	 * @param gender the gender to set
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}
	/**
	 * @return the blood
	 */
	public String getBlood() {
		return blood;
	}
	/**
	 * @param blood the blood to set
	 */
	public void setBlood(String blood) {
		this.blood = blood;
	}
	/**
	 * @return the height
	 */
	public String getHeight() {
		return height;
	}
	/**
	 * @param height the height to set
	 */
	public void setHeight(String height) {
		this.height = height;
	}
	/**
	 * @return the weight
	 */
	public String getWeight() {
		return weight;
	}
	/**
	 * @param weight the weight to set
	 */
	public void setWeight(String weight) {
		this.weight = weight;
	}
	/**
	 * @return the dob
	 */
	public String getDob() {
		return dob;
	}
	/**
	 * @param dob the dob to set
	 */
	public void setDob(String dob) {
		this.dob = dob;
	}
	/**
	 * @return the homeAddress
	 */
	public String getHomeAddress() {
		return homeAddress;
	}
	/**
	 * @param homeAddress the homeAddress to set
	 */
	public void setHomeAddress(String homeAddress) {
		this.homeAddress = homeAddress;
	}
	/**
	 * @return the hostAddress
	 */
	public String getHostAddress() {
		return hostAddress;
	}
	/**
	 * @param hostAddress the hostAddress to set
	 */
	public void setHostAddress(String hostAddress) {
		this.hostAddress = hostAddress;
	}
	/**
	 * @return the emergencyPrimaryPerson
	 */
	public String getEmergencyPrimaryPerson() {
		return emergencyPrimaryPerson;
	}
	/**
	 * @param emergencyPrimaryPerson the emergencyPrimaryPerson to set
	 */
	public void setEmergencyPrimaryPerson(String emergencyPrimaryPerson) {
		this.emergencyPrimaryPerson = emergencyPrimaryPerson;
	}
	/**
	 * @return the emergencyPrimaryNumber
	 */
	public String getEmergencyPrimaryNumber() {
		return emergencyPrimaryNumber;
	}
	/**
	 * @param emergencyPrimaryNumber the emergencyPrimaryNumber to set
	 */
	public void setEmergencyPrimaryNumber(String emergencyPrimaryNumber) {
		this.emergencyPrimaryNumber = emergencyPrimaryNumber;
	}
	/**
	 * @return the emergencyOne
	 */
	public String getEmergencyOne() {
		return emergencyOne;
	}
	/**
	 * @param emergencyOne the emergencyOne to set
	 */
	public void setEmergencyOne(String emergencyOne) {
		this.emergencyOne = emergencyOne;
	}
	/**
	 * @return the emergencyTwo
	 */
	public String getEmergencyTwo() {
		return emergencyTwo;
	}
	/**
	 * @param emergencyTwo the emergencyTwo to set
	 */
	public void setEmergencyTwo(String emergencyTwo) {
		this.emergencyTwo = emergencyTwo;
	}
	/**
	 * @return the emergencyThree
	 */
	public String getEmergencyThree() {
		return emergencyThree;
	}
	/**
	 * @param emergencyThree the emergencyThree to set
	 */
	public void setEmergencyThree(String emergencyThree) {
		this.emergencyThree = emergencyThree;
	}
	/**
	 * @return the emergencyFour
	 */
	public String getEmergencyFour() {
		return emergencyFour;
	}
	/**
	 * @param emergencyFour the emergencyFour to set
	 */
	public void setEmergencyFour(String emergencyFour) {
		this.emergencyFour = emergencyFour;
	}
	/**
	 * @return the superiorHomeName
	 */
	public String getSuperiorHomeName() {
		return superiorHomeName;
	}
	/**
	 * @param superiorHomeName the superiorHomeName to set
	 */
	public void setSuperiorHomeName(String superiorHomeName) {
		this.superiorHomeName = superiorHomeName;
	}
	/**
	 * @return the superiorHomeDes
	 */
	public String getSuperiorHomeDes() {
		return superiorHomeDes;
	}
	/**
	 * @param superiorHomeDes the superiorHomeDes to set
	 */
	public void setSuperiorHomeDes(String superiorHomeDes) {
		this.superiorHomeDes = superiorHomeDes;
	}
	/**
	 * @return the superiorHomeDept
	 */
	public String getSuperiorHomeDept() {
		return superiorHomeDept;
	}
	/**
	 * @param superiorHomeDept the superiorHomeDept to set
	 */
	public void setSuperiorHomeDept(String superiorHomeDept) {
		this.superiorHomeDept = superiorHomeDept;
	}
	/**
	 * @return the superiorHostName
	 */
	public String getSuperiorHostName() {
		return superiorHostName;
	}
	/**
	 * @param superiorHostName the superiorHostName to set
	 */
	public void setSuperiorHostName(String superiorHostName) {
		this.superiorHostName = superiorHostName;
	}
	/**
	 * @return the superiorHostDes
	 */
	public String getSuperiorHostDes() {
		return superiorHostDes;
	}
	/**
	 * @param superiorHostDes the superiorHostDes to set
	 */
	public void setSuperiorHostDes(String superiorHostDes) {
		this.superiorHostDes = superiorHostDes;
	}
	/**
	 * @return the superiorHostDept
	 */
	public String getSuperiorHostDept() {
		return superiorHostDept;
	}
	/**
	 * @param superiorHostDept the superiorHostDept to set
	 */
	public void setSuperiorHostDept(String superiorHostDept) {
		this.superiorHostDept = superiorHostDept;
	}
	/**
	 * @return the arrivalDate
	 */
	public String getArrivalDate() {
		return arrivalDate;
	}
	/**
	 * @param arrivalDate the arrivalDate to set
	 */
	public void setArrivalDate(String arrivalDate) {
		this.arrivalDate = arrivalDate;
	}
	/**
	 * @return the depatureDate
	 */
	public String getDepatureDate() {
		return depatureDate;
	}
	/**
	 * @param depatureDate the depatureDate to set
	 */
	public void setDepatureDate(String depatureDate) {
		this.depatureDate = depatureDate;
	}
	/**
	 * @return the expatNationality
	 */
	public String getExpatNationality() {
		return expatNationality;
	}
	/**
	 * @param expatNationality the expatNationality to set
	 */
	public void setExpatNationality(String expatNationality) {
		this.expatNationality = expatNationality;
	}
	/**
	 * @return the expatVISAType
	 */
	public String getExpatVISAType() {
		return expatVISAType;
	}
	/**
	 * @param expatVISAType the expatVISAType to set
	 */
	public void setExpatVISAType(String expatVISAType) {
		this.expatVISAType = expatVISAType;
	}
	/**
	 * @return the expatVISAExpiry
	 */
	public String getExpatVISAExpiry() {
		return expatVISAExpiry;
	}
	/**
	 * @param expatVISAExpiry the expatVISAExpiry to set
	 */
	public void setExpatVISAExpiry(String expatVISAExpiry) {
		this.expatVISAExpiry = expatVISAExpiry;
	}
	/**
	 * @return the expatPassportNumber
	 */
	public String getExpatPassportNumber() {
		return expatPassportNumber;
	}
	/**
	 * @param expatPassportNumber the expatPassportNumber to set
	 */
	public void setExpatPassportNumber(String expatPassportNumber) {
		this.expatPassportNumber = expatPassportNumber;
	}
	/**
	 * @return the expatPlaceOfIssue
	 */
	public String getExpatPlaceOfIssue() {
		return expatPlaceOfIssue;
	}
	/**
	 * @param expatPlaceOfIssue the expatPlaceOfIssue to set
	 */
	public void setExpatPlaceOfIssue(String expatPlaceOfIssue) {
		this.expatPlaceOfIssue = expatPlaceOfIssue;
	}
	/**
	 * @return the expatPassportExpiry
	 */
	public String getExpatPassportExpiry() {
		return expatPassportExpiry;
	}
	/**
	 * @param expatPassportExpiry the expatPassportExpiry to set
	 */
	public void setExpatPassportExpiry(String expatPassportExpiry) {
		this.expatPassportExpiry = expatPassportExpiry;
	}
	/**
	 * @return the expatFamilyVISAOne
	 */
	public String getExpatFamilyVISAOne() {
		return expatFamilyVISAOne;
	}
	/**
	 * @param expatFamilyVISAOne the expatFamilyVISAOne to set
	 */
	public void setExpatFamilyVISAOne(String expatFamilyVISAOne) {
		this.expatFamilyVISAOne = expatFamilyVISAOne;
	}
	/**
	 * @return the expatFamilyVISATwo
	 */
	public String getExpatFamilyVISATwo() {
		return expatFamilyVISATwo;
	}
	/**
	 * @param expatFamilyVISATwo the expatFamilyVISATwo to set
	 */
	public void setExpatFamilyVISATwo(String expatFamilyVISATwo) {
		this.expatFamilyVISATwo = expatFamilyVISATwo;
	}
	/**
	 * @return the expatFamilyVISThree
	 */
	public String getExpatFamilyVISThree() {
		return expatFamilyVISThree;
	}
	/**
	 * @param expatFamilyVISThree the expatFamilyVISThree to set
	 */
	public void setExpatFamilyVISThree(String expatFamilyVISThree) {
		this.expatFamilyVISThree = expatFamilyVISThree;
	}
	/**
	 * @return the expatFamilyVISAFour
	 */
	public String getExpatFamilyVISAFour() {
		return expatFamilyVISAFour;
	}
	/**
	 * @param expatFamilyVISAFour the expatFamilyVISAFour to set
	 */
	public void setExpatFamilyVISAFour(String expatFamilyVISAFour) {
		this.expatFamilyVISAFour = expatFamilyVISAFour;
	}
	/**
	 * @return the expatMedication
	 */
	public String getExpatMedication() {
		return expatMedication;
	}
	/**
	 * @param expatMedication the expatMedication to set
	 */
	public void setExpatMedication(String expatMedication) {
		this.expatMedication = expatMedication;
	}
	/**
	 * @return the expatOthers
	 */
	public String getExpatOthers() {
		return expatOthers;
	}
	/**
	 * @param expatOthers the expatOthers to set
	 */
	public void setExpatOthers(String expatOthers) {
		this.expatOthers = expatOthers;
	}
	
	/**
	 * @return the lastupdated
	 */
	public String getLastupdated() {
		return lastupdated;
	}
	/**
	 * @param lastupdated the lastupdated to set
	 */
	public void setLastupdated(String lastupdated) {
		this.lastupdated = lastupdated;
	}
	/**
	 * @return the userID
	 */
	public String getUserID() {
		return userID;
	}
	/**
	 * @param userID the userID to set
	 */
	public void setUserID(String userID) {
		this.userID = userID;
	}
	/**
	 * @return the genderStatus
	 */
	public String getGenderStatus() {
		return genderStatus;
	}
	/**
	 * @param genderStatus the genderStatus to set
	 */
	public void setGenderStatus(String genderStatus) {
		this.genderStatus = genderStatus;
	}
	/**
	 * @return the guardianName
	 */
	public String getGuardianName() {
		return guardianName;
	}
	/**
	 * @param guardianName the guardianName to set
	 */
	public void setGuardianName(String guardianName) {
		this.guardianName = guardianName;
	}
	/**
	 * @return the offerDate
	 */
	public String getOfferDate() {
		return offerDate;
	}
	/**
	 * @param offerDate the offerDate to set
	 */
	public void setOfferDate(String offerDate) {
		this.offerDate = offerDate;
	}
	/**
	 * @return the joiningDate
	 */
	public String getJoiningDate() {
		return joiningDate;
	}
	/**
	 * @param joiningDate the joiningDate to set
	 */
	public void setJoiningDate(String joiningDate) {
		this.joiningDate = joiningDate;
	}
	/**
	 * @return the assignmentFrom
	 */
	public String getAssignmentFrom() {
		return assignmentFrom;
	}
	/**
	 * @param assignmentFrom the assignmentFrom to set
	 */
	public void setAssignmentFrom(String assignmentFrom) {
		this.assignmentFrom = assignmentFrom;
	}
	/**
	 * @return the assignmentTo
	 */
	public String getAssignmentTo() {
		return assignmentTo;
	}
	/**
	 * @param assignmentTo the assignmentTo to set
	 */
	public void setAssignmentTo(String assignmentTo) {
		this.assignmentTo = assignmentTo;
	}
	/**
	 * @return the emergencyPrimaryRelation
	 */
	public String getEmergencyPrimaryRelation() {
		return emergencyPrimaryRelation;
	}
	/**
	 * @param emergencyPrimaryRelation the emergencyPrimaryRelation to set
	 */
	public void setEmergencyPrimaryRelation(String emergencyPrimaryRelation) {
		this.emergencyPrimaryRelation = emergencyPrimaryRelation;
	}

}
