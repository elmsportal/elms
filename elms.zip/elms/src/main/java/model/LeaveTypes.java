/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author z015675
 */
public class LeaveTypes {
    private int id;
    private String leavetype;
    private String category;
    private String mainCategory;
    private String maxCount;
    private String allowedCount;
    private String allowAfter;
    private String leaveDetails;
    private String status;
    private String color;
    private String icon;
    private String addedBy;
    private String addedOn;
    private String lastupdatedBy;
    private String lastupdatedOn;
    private String disabledCSS;
    private String deduct;
    private String canDisable;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getLeavetype() {
        return leavetype;
    }

    public void setLeavetype(String leavetype) {
        this.leavetype = leavetype;
    }

    public String getLeaveDetails() {
        return leaveDetails;
    }

    public void setLeaveDetails(String leaveDetails) {
        this.leaveDetails = leaveDetails;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getMaxCount() {
        return maxCount;
    }

    public void setMaxCount(String maxCount) {
        this.maxCount = maxCount;
    }

    public String getAllowedCount() {
        return allowedCount;
    }

    public void setAllowedCount(String allowedCount) {
        this.allowedCount = allowedCount;
    }

    public String getAllowAfter() {
        return allowAfter;
    }

    public void setAllowAfter(String allowAfter) {
        this.allowAfter = allowAfter;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public String getAddedBy() {
        return addedBy;
    }

    public void setAddedBy(String addedBy) {
        this.addedBy = addedBy;
    }

    public String getAddedOn() {
        return addedOn;
    }

    public void setAddedOn(String addedOn) {
        this.addedOn = addedOn;
    }

    public String getLastupdatedBy() {
        return lastupdatedBy;
    }

    public void setLastupdatedBy(String lastupdatedBy) {
        this.lastupdatedBy = lastupdatedBy;
    }

    public String getLastupdatedOn() {
        return lastupdatedOn;
    }

    public void setLastupdatedOn(String lastupdatedOn) {
        this.lastupdatedOn = lastupdatedOn;
    }

    public String getDisabledCSS() {
        return disabledCSS;
    }

    public void setDisabledCSS(String disabledCSS) {
        this.disabledCSS = disabledCSS;
    }

    public String getMainCategory() {
        return mainCategory;
    }

    public void setMainCategory(String mainCategory) {
        this.mainCategory = mainCategory;
    }

    public String getDeduct() {
        return deduct;
    }

    public void setDeduct(String deduct) {
        this.deduct = deduct;
    }

	/**
	 * @return the canDisable
	 */
	public String getCanDisable() {
		return canDisable;
	}

	/**
	 * @param canDisable the canDisable to set
	 */
	public void setCanDisable(String canDisable) {
		this.canDisable = canDisable;
	}
    
}
