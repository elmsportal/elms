/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author z015675
 */
public class Expatriate {
    private int id;
    private String name;
    private String username;
    private String password;
    private String firstName;
    private String lastName;
    private String mainCategory;
    private String category;
    private String designation;
    private String department;
    private String picture;
    private String assignmentFrom;
    private String assignmentTo;
    private String assignementDuration;
    private String rnNumber;
    private String homeCountry;
    private String leaveCount;
    private String leaveBalance;
    private String email;
    private String enabled;
    private String authority;
    private String approvalManager;
    private String approvalManagerEmail;
    private String addedBy;
    private String addedDate;
    private String lastUpdatedBy;
    private String lastUpdatedDate;
    private String expatOJFid;
    private int expatBasicId;
    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEnabled() {
        return enabled;
    }

    public void setEnabled(String enabled) {
        this.enabled = enabled;
    }

    public String getAuthority() {
        return authority;
    }

    public void setAuthority(String authority) {
        this.authority = authority;
    }

    public String getApprovalManager() {
        return approvalManager;
    }

    public void setApprovalManager(String approvalManager) {
        this.approvalManager = approvalManager;
    }

    public String getAddedBy() {
        return addedBy;
    }

    public void setAddedBy(String addedBy) {
        this.addedBy = addedBy;
    }

    public String getAddedDate() {
        return addedDate;
    }

    public void setAddedDate(String addedDate) {
        this.addedDate = addedDate;
    }

    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    public String getLastUpdatedDate() {
        return lastUpdatedDate;
    }

    public void setLastUpdatedDate(String lastUpdatedDate) {
        this.lastUpdatedDate = lastUpdatedDate;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getAssignmentFrom() {
        return assignmentFrom;
    }

    public void setAssignmentFrom(String assignmentFrom) {
        this.assignmentFrom = assignmentFrom;
    }

    public String getAssignmentTo() {
        return assignmentTo;
    }

    public void setAssignmentTo(String assignmentTo) {
        this.assignmentTo = assignmentTo;
    }

    public String getAssignementDuration() {
        return assignementDuration;
    }

    public void setAssignementDuration(String assignementDuration) {
        this.assignementDuration = assignementDuration;
    }

    public String getLeaveCount() {
        return leaveCount;
    }

    public void setLeaveCount(String leaveCount) {
        this.leaveCount = leaveCount;
    }

    public String getLeaveBalance() {
        return leaveBalance;
    }

    public void setLeaveBalance(String leaveBalance) {
        this.leaveBalance = leaveBalance;
    }

    public String getRnNumber() {
        return rnNumber;
    }

    public void setRnNumber(String rnNumber) {
        this.rnNumber = rnNumber;
    }

    public String getHomeCountry() {
        return homeCountry;
    }

    public void setHomeCountry(String homeCountry) {
        this.homeCountry = homeCountry;
    }

    public String getPicture() {
        return picture;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }

    public String getApprovalManagerEmail() {
        return approvalManagerEmail;
    }

    public void setApprovalManagerEmail(String approvalManagerEmail) {
        this.approvalManagerEmail = approvalManagerEmail;
    }

    public String getMainCategory() {
        return mainCategory;
    }

    public void setMainCategory(String mainCategory) {
        this.mainCategory = mainCategory;
    }

	/**
	 * @return the expatOJFid
	 */
	public String getExpatOJFid() {
		return expatOJFid;
	}

	/**
	 * @param expatOJFid the expatOJFid to set
	 */
	public void setExpatOJFid(String expatOJFid) {
		this.expatOJFid = expatOJFid;
	}

	/**
	 * @return the expatBasicId
	 */
	public int getExpatBasicId() {
		return expatBasicId;
	}

	/**
	 * @param expatBasicId the expatBasicId to set
	 */
	public void setExpatBasicId(int expatBasicId) {
		this.expatBasicId = expatBasicId;
	}
}
